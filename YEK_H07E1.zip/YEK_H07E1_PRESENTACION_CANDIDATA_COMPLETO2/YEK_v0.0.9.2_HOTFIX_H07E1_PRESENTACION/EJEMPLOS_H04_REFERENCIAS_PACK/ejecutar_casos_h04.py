#!/usr/bin/env python3
"""Audita H04 contra el binario YEK del propio proyecto (sin modificar src/)."""
import csv
import json
import os
import subprocess
import sys
from pathlib import Path

here = Path(__file__).resolve().parent
root = here.parent
cases = json.loads((here / 'CASOS_Y_RESULTADOS.json').read_text(encoding='utf-8'))
exe = root / 'target' / 'debug' / ('yek.exe' if os.name == 'nt' else 'yek')
if not exe.is_file():
    print('No encuentro el ejecutable. Desde la raíz del proyecto, ejecuta: cargo build')
    sys.exit(2)
results = []
for record in cases:
    filename = here / record['path']
    try:
        p = subprocess.run([str(exe), 'run', str(filename)], cwd=root, capture_output=True,
                           text=True, encoding='utf-8', errors='replace', timeout=15)
        output = p.stdout.replace('\r\n','\n')
        stderr = p.stderr.replace('\r\n','\n')
        if record['kind'] == 'ok':
            passed = (p.returncode == 0 and output == record['stdout'])
        else:
            passed = (p.returncode != 0 and record['error_contains'] in stderr)
        row = {'id':record['id'], 'estado':'OK' if passed else 'FALLO',
               'esperado':record.get('stdout', record.get('error_contains','')),
               'codigo':p.returncode, 'stdout':output, 'stderr':stderr}
    except (OSError, subprocess.TimeoutExpired) as ex:
        row={'id':record['id'], 'estado':'FALLO', 'esperado':record.get('stdout',record.get('error_contains','')),
             'codigo':'TIMEOUT', 'stdout':'','stderr':str(ex)}
    results.append(row)
    print(f"{row['estado']:5s} {record['id']}")
path = here / 'RESULTADOS_H04'
path.mkdir(exist_ok=True)
with (path/'resultados.csv').open('w',encoding='utf-8-sig',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=['id','estado','esperado','codigo','stdout','stderr'])
    writer.writeheader();writer.writerows(results)
with (path/'detalles.json').open('w',encoding='utf-8') as f:
    json.dump(results,f,indent=2,ensure_ascii=False)
fail = [r for r in results if r['estado'] != 'OK']
report=[f'YEK H04: {len(results)} comprobaciones; {len(results)-len(fail)} OK; {len(fail)} FALLO.', '']
for r in fail:
    report += [r['id'], f"Código: {r['codigo']}",f"Esperado: {r['esperado']!r}",
               f"STDOUT: {r['stdout']!r}",f"STDERR: {r['stderr']!r}",'']
(path/'REPORTE_PARA_CHATGPT.txt').write_text('\n'.join(report)+'\n',encoding='utf-8')
print('\n'+'\n'.join(report[:2]))
print(f'Informe: {path / "REPORTE_PARA_CHATGPT.txt"}')
sys.exit(1 if fail else 0)
