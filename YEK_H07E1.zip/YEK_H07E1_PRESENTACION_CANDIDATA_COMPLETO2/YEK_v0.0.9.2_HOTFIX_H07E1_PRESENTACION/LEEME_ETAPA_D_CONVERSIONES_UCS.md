# YEK 0.0.9.2 — Etapa D: sistema universal de conversiones (UCS)

**Estado:** candidata de validación. Base: Etapa C NONE HOTFIX H02, que el usuario ha comprobado.

## Especificación

### Conversores nativos en minúsculas

- `array`, `pack`, `dict`, `set`: cero o un argumento, construyen **una** colección.
  Sin argumento, `s=set`, `s=set()` y `s.count!` son válidos.
- `num`, `str`, `bool`: exactamente un argumento; un escalar produce un escalar,
  una colección produce **un resultado por elemento**. Los resultados se
  distribuyen mediante la aridad existente de `~code`; no se recogen a escondidas.
- `bool.parse(texto)`: interpreta representaciones explícitas `true`, `false`,
  `1`, `0`, además de las etiquetas booleanas configuradas en el contexto.
- `Set()` se mantiene como alias anterior por compatibilidad. El render histórico
  de Set vacío `Set()` no se ha cambiado, para conservar regresiones.
- `none` es un literal independiente; no es un conversor.
- Los nombres nativos se resuelven si no hay un símbolo del usuario con ese nombre;
  el valor nativo capturado, `cv=num!`, es de primera clase y puede invocarse.

### Construcción de contenedores

```yek
~code
s=set([1,2,2,3])
p=pack([1,2,3])
a=array((1,2,3))
m=dict(["a",1,"b"])
s!
p!
a!
m!
```

Salidas esperadas:

```text
{1, 2, 3}
(1, 2, 3)
[1, 2, 3]
{"a":1, "b":none}
```

`dict` agrupa elementos consecutivos en clave/valor; si falta el último valor,
se usa `none`. También acepta una secuencia formada íntegramente por pares
`Entry`, ValuePack de dos elementos o Arrays de dos elementos. Una mezcla de
pares y escalares es error; claves duplicadas son error. `dict(m)` copia un Map.

`array(m)` y `pack(m)` generan la secuencia plana `clave,valor,clave,valor` en
orden de inserción. `array("hola")`, `pack("hola")` y `set("hola")` tratan
Text como secuencia de caracteres Unicode. Una conversión de contenedor desde
un escalar distinto de Text construye una colección unitaria (salvo `dict`,
que exige una estructura de pares).

### Escalares y resultados múltiples

```yek
~code
a,b,c=num(["1","2","3"])
a!
b!
c!
```

Resultado esperado: tres líneas (`1`, `2`, `3`). `a=num([1,2,3])` es un error de
aridad; `a,b,=num([1,2,3])` descarta una posición, siguiendo la gramática
histórica de receptores vacíos.

- `num("2.50")` usa Number exacto; `num("2/3")` también admite racionales.
- `num(true) -> 1`, `num(false) -> 0`; `num(none)` es error.
- `bool(0) -> false`; cualquier Number no cero -> `true`.
- `bool("") -> false`; cualquier Text no vacío, incluso `"false"`, -> `true`.
- `bool(none) -> false` únicamente por conversión explícita; `none != false`.
- `bool.parse("false") -> false`; también etiquetas actuales de visualización.
- `str(none) -> "none"` (Text); `str(2) -> "2"`.
- Ninguna conversión se aplica implícitamente a operaciones o guardas.

### Transformación de colecciones sin cambiar el contenedor original

```yek
~code
m={"1":"10","2":"20"}
a=m.convert_values(num!)
b=m.convert_keys(num!)
a!
b!
m!
```

Resultado esperado:

```text
{"1":10, "2":20}
{1:"10", 2:"20"}
{"1":"10", "2":"20"}
```

- `.convert(conversor!)` conserva el tipo Array, ValuePack o Set; en Map equivale
  a `.convert_values(conversor!)`.
- `.convert_keys(conversor!)` cambia claves de Map; comprueba validez y detecta
  colisiones **antes** de devolver el resultado.
- `.convert_values(conversor!)` transforma los valores de Map, no sus claves.
- `.convert(num!,deep=true)` y `.convert_values(num!,deep=true)` conservan la
  forma de contenedores anidados; sin `deep=true` un contenedor anidado no
  convertible al escalar genera error. Máximo 64 niveles explícitos.
- Como en toda conversión, Set deduplica valores resultantes que sean iguales.
- Las conversiones del UCS admitidas como argumentos de `.convert*` son
  `num!`, `str!`, `bool!`, `bool.parse!` o alias capturados de ellas.
- No se han incorporado aún conversores Code definidos por el usuario como
  callbacks arbitrarios; requieren revisar pureza, efectos y aridad.

### Copias y referencias

- `array(a)` produce un Array independiente de `a`.
- `array(a!)` produce una **vista viva** de las celdas de Array `a`.
- `array(m.values)` produce Array independiente, mientras que
  `array(m.values!)` o `array(v!)` con `v=m.values!` produce vista viva.
- `pack` y `set` nunca transportan elementos mutables referenciados: copian
  valores y respetan la unicidad / inmutabilidad.
- La conversión de claves de Map siempre es por valor, nunca por referencia.
- Al retornar colecciones de `~code`, se copian valores al ámbito del llamador,
  pero una View o referencia explícita no puede escapar de celdas locales.

### Limitaciones conscientes

- La creación de conversiones es atómica **respecto a asignaciones visibles**:
  ante un elemento inválido, la operación completa falla sin escribir valores
  convertidos en las variables de destino.
- No se transforma un error en `none` silenciosamente.
- Los Sets vacíos siguen mostrándose con formato histórico `Set()`.
- El módulo nativo `str` preexistente (`~import str`) mantiene sus exportaciones.
- Los métodos `.convert*` producen copias independientes; no alteran el origen.
- Los objetos privados no se aplanan automáticamente por conversión.
- `~try`, `~catch`, `Result` y `~attempt` **no forman parte** de esta entrega.

## Verificación

```powershell
cargo check --all-targets
cargo test --test universal_conversion_v0092_tests -- --test-threads=1 --nocapture
cargo test --test none_tipo_universal_v0092_tests -- --test-threads=1 --nocapture
cargo test --test colecciones_universales_v0092_etapa_b_map_set_tests -- --test-threads=1 --nocapture
cargo test --all-targets
```

No se ha podido compilar con Rust/Cargo dentro del entorno de preparación.
Todos los resultados `.esperado.txt` y las aserciones de la suite son objetivos
para validar en el equipo del usuario, no registros de ejecución real.
