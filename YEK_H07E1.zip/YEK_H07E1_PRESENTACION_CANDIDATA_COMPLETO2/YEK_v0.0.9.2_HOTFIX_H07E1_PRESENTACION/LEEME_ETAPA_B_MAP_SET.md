# YEK v0.0.9.2 — Etapa B (CANDIDATA)

Proyecto íntegro derivado del HOTFIX H01 de Etapa A.

## Reglas de este candidato
- `{}` es Map vacío; `Set()` representa Set vacío. Un Set no vacío es `{1,2,3}`.
- Map conserva el orden de inserción. `m[0]` obtiene una `Entry` completa; `m["clave"]` obtiene el valor. Para claves numéricas usar `m.get(0)` y `m.set(0, valor)`.
- `.keys`, `.values`, `.entries` producen Arrays independientes. `.values!` devuelve una vista viva de celdas de valores existentes; no permite `append` ni cambia tamaño automáticamente con inserciones nuevas.
- Al eliminar una entrada con `.remove` o `.clear`, las referencias antiguas a su celda se invalidan y deben producir error controlado al usarlas.
- Los elementos de Set y las claves de Map no pueden mutarse directamente por referencia. Set conserva el orden de primera inserción.
- Los cortes son por valor y conservan Map/Set como tipos propios. `[::-1]` invierte el orden, no intercambia claves y valores.
- Map admite `.get`, `.set`, `.remove`, `.clear`, `.contains`, `.invert`, `.reverse`, `.count`, `.len` y vistas.
- Set admite `.add`, `.remove`, `.clear`, `.contains`, `.union`, `.intersection`, `.difference`, `.reverse`, `.count`, `.len`.
- `for` sobre Map produce `Entry`, con `.key`, `.value` y patrones `(clave, valor)`. Set produce valores ordenados.

## Pruebas
Hay 83 casos nuevos (61 positivos y 22 negativos) y sus archivos `.yek` correspondientes.

En PowerShell, desde la carpeta `Cargo.toml`:
```
cargo check --all-targets
cargo test --test colecciones_universales_v0092_etapa_b_map_set_tests -- --test-threads=1 --nocapture
cargo test --test colecciones_universales_v0092_etapa_a_tests -- --test-threads=1 --nocapture
cargo test --all-targets
```

**IMPORTANTE:** No se dispone de Rust/Cargo en el entorno de creación, por lo que son resultados esperados, no ejecuciones verificadas. Mantener la versión H01 de Etapa A como estable hasta pasar todas las pruebas.
