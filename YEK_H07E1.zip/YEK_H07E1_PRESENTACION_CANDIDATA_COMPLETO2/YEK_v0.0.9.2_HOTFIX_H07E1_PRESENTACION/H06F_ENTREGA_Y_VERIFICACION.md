# YEK H06F — Rangos Unicode universales

Base: H06E aprobado en Windows según el reporte del usuario.

## Funcionalidad implementada
- `a..d` equivale al intervalo Unicode literal entre las letras `a` y `d`.
- `("a".."d")` también admite intervalos de caracteres.
- `(a)..(d)` sigue evaluando los valores de las variables.
- `a!..d!` y `(a!)..(d!)` siguen siendo referencias explícitas; su extremo vivo se vuelve a consultar dentro de `for`.
- Los rangos numéricos (`0..5`, `0..(x)`, `0..x!`) conservan la misma semántica.
- Los rangos de caracteres producen Text al expandirse: ValuePack, Array, bucles, productores y pasos numéricos enteros.
- Orden definido por valor escalar Unicode, no colación lingüística. Los caracteres Unicode de múltiples escalares (emoji compuestos, secuencias ZWJ) no son extremos únicos.
- Solo se permiten extremos homogéneos; rango de Text sin extremo final es error.
- Expansión limitada a 200.000 posiciones de código; saltan escalares Unicode inválidos.
- `~in(str=a..z)` se mantiene sin cambios.

## Verificación en Windows

Desde la raíz (junto a Cargo.toml):

```powershell
cargo build
cargo test --test etapa6_h06f_rangos_unicode_tests
cargo test --test etapa6_h06_migracion_unificada_tests
cargo test --test etapa6_h06a_rangos_explicitos_tests
cargo test
py -3 EJEMPLOS_H06F_RANGOS_UNICODE\ejecutar_h06f.py --auditar
py -3 EJEMPLOS_H06F_RANGOS_UNICODE\ejecutar_h06f.py
```

También se ofrece `VERIFICAR_H06F.cmd`.

## VS Code

`EXTENSION_VS_CODE_H06/YEK_Lenguaje_v1.3.1_H06F_Rangos_Unicode.vsix` añade coloreado de los intervalos Unicode literales. No cambia los comandos de ejecución.

## Límite de validación

En el entorno de empaquetado no se cuenta con Cargo o Rustc. **La compilación, las pruebas Rust y los resultados de los programas YEK todavía no están validados mediante ejecución real.** El proyecto anterior H06E no se ha sobrescrito.
