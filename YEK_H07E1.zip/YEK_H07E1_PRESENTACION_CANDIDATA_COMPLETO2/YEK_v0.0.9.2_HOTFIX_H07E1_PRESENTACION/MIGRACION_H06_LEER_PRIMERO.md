# YEK H06 — Migración unificada de entrada y reparación de rangos

**Base:** H05B. **Extensión incluida:** VS Code v1.3.0 (H06). **Estado:** CANDIDATO DE VALIDACIÓN, no certificado con Cargo.

## Objetivo y alcance

- La gramática ordinaria prevalece sobre la clasificación implícita de un ContractPack en un rango de variables. La gramática de H06A exige una agrupación explícita de cada extremo dinámico **por valor**: `a=(0..(x))` y `a=((x)..(y))`. Las formas `0..x`, `x..y` sin `!` se rechazan con un diagnóstico claro. Las referencias `x!` y `(x!)` continúan válidas.
- El nuevo selector `~in(...)` configura las futuras operaciones `?` dentro del mismo ámbito de ejecución.
- Las directivas antiguas `~num`, `~str`, `~bool` y `~auto` continúan funcionando **como aliases heredados** para mantener compatibilidad con programas existentes. La API oficial nueva es `~in`, y no deben usarse en programas nuevos.
- Una antigua declaración implícita de ContractPack `a=(a..z)` deja de tener preferencia sobre la gramática ordinaria: debe migrarse a `~in(str=a..z)` donde se use como filtro. Los ContractPack que contienen un indicador explícito de contrato heredado (`<...>` o especificación de longitud inequívoca) conservan la ruta de compatibilidad.

## Reglas de los rangos

```yek
~code
x=26
a=(0..(x))
a!
```

El resultado esperado es un ValuePack de los 27 enteros de 0 a 26, no `<contract-pack>`. La referencia viva en `for(i=0..x!)` conserva el comportamiento anterior. Los ValuePack materializados no se vuelven a calcular automáticamente al cambiar `x`.

Existe un límite defensivo de 200.000 elementos al materializar rangos finitos para evitar agotamiento de memoria en una sola operación.

## Formato de `~in`

```yek
~in
~in(auto)
~in(num)
~in(num.int=[1,4..6,100], len=[2,10..20], att=2, msg="incorrecto")
~in(num.float=1..10, warning="alerta", -> 1.0)
~in(str=[a..z,A..Z,0..9,"si"], len=2..5)
~in(str.char=[a..m])
~in(bool)
~in(bool.str=[true,false])
~in(bool.num=[0,1])
~in(auto=["hola",2,[2,6],true])
```

**Tipos:** `auto` infiere Number, Bool, None, Text y arreglos literales. `num`/`num.auto` acepta enteros y decimales; `num.int` exige representación sin punto decimal; `num.float` exige punto decimal aunque internamente YEK mantenga la representación numérica exacta previa. `str` es texto, `str.char` exige exactamente un escalar Unicode; `bool` admite `true,false,0,1`; `bool.str` solo las palabras; `bool.num` solo las cifras.

**Dominios:** alternativas separadas por comas dentro de `[]` son OR; los distintos parámetros son AND. Los rangos son inclusivos. Los dominios abiertos, `0..inf`, `0..`, `..0`, `0..-inf`, no se materializan: se validan mediante comparación de límites. En textos, `a..z` define una alternativa alfabética (cada carácter del texto debe pertenecer al rango); `"si"` representa la cadena completa exacta.

**Longitud:** `len` se aplica al texto de entrada original, no al valor numérico normalizado; `005` cuenta como tres caracteres. `len=[2,10..20]` significa 2 O 10–20.

**Intentos:** por defecto uno. `att=2`, `att=[3,"reintenta"]`, `att=inf` / `att=+inf`. La entrada cerrada produce error controlado incluso con intentos infinitos.

**Política final:** sin política explícita, error fatal; `error` siempre fatal; `msg` imprime texto normal y permite reserva; `warning` emite advertencia y permite reserva. No pueden coexistir políticas finales. `->` sin valor devuelve `none`; `-> valor` devuelve una reserva compatible con el tipo declarado aunque quede fuera del dominio. Un contrato con `att=inf` no puede tener una política final inalcanzable (`msg/error/warning`), pero sí un mensaje por intento mediante `att=[inf,"..."]`.

**Orden:** las opciones son independientes; se pueden escribir en cualquier orden, y se comprueba la incompatibilidad del `->` solo después de resolver el tipo seleccionado.

**Variables en rangos (H06A):** `~in(num=0..(limite))` congela el valor al instalar el contrato. `~in(num=0..limite!)` y `~in(num=0..(limite!))` mantienen referencia viva hasta la adquisición mediante `?`. `~in(str=a..z)` es el alfabeto literal; `~in(str=(a)..(b))` utiliza variables de texto con un carácter. Los extremos ordinarios no agrupados se rechazan en rangos numéricos.

## Medidas de seguridad

- Los dominios infinitos se validan como predicados y nunca se enumeran.
- La entrada del usuario **nunca se evalúa como código ejecutable**. Arrays auto admiten exclusivamente literales numéricos, cadenas entrecomilladas, Bool, None y Arrays anidados. Máximo 24 niveles y 4.096 elementos por Array.
- Valores de reserva Num/Bool incompatibles son errores del contrato.
- Se detectan estáticamente contradicciones de representación y longitud para `bool` y `str.char`.
- No hay nuevo tipo IEEE Float: `num.float` valida el formato textual, pero retorna el Number exacto ya existente.

## Compatibilidad y límites de esta entrega

Este cambio es amplio y **no fue ejecutado con `cargo build` en el entorno de preparación**, que no tiene el compilador Rust. Las pruebas en `tests/etapa6_h06_migracion_unificada_tests.rs`, la nueva suite de 40 casos y el laboratorio de 57 archivos son hipótesis de comportamiento por validar con el ejecutable real. Cualquier fallo debe investigarse antes de aprobar H06 o migrar programas de producción.

Funcionalidades **no incluidas**: un tipo matemático Complex/Imaginary real; subtipos IEEE Float independientes; validación simbólica completa de toda contradicción aritmética posible; rangos de caracteres dinámicos con expresiones arbitrarias; entrada que interprete código YEK; compatibilidad absoluta de todas las formas implícitas ambiguas de ContractPack anteriores. No se debe presentar H06 como sustituto certificado de H05B hasta ejecutar la regresión.

## Verificación en Windows

```powershell
cargo build
cargo test --test etapa6_h06_migracion_unificada_tests
cargo test --test etapa6_h06a_rangos_explicitos_tests
cargo test
py -3 EJEMPLOS_H06_UNIFICADO/ejecutar_h06.py --auditar
py -3 EJEMPLOS_H06_UNIFICADO/ejecutar_h06.py
py -3 EJEMPLOS_H06A_RANGOS_EXPLICITOS/ejecutar_h06a.py
```

Si alguna orden falla, enviar el log completo y `EJEMPLOS_H06_UNIFICADO/RESULTADOS_H06/REPORTE_PARA_CHATGPT.txt`.

> **H06A:** Los ejemplos H06-001/003/004/038 y sus pruebas Rust se han migrado a la notación agrupada por valor. Los ejemplos de contratos de caracteres literales continúan sin paréntesis. Ver `MIGRACION_RANGOS_H06A.md`.
