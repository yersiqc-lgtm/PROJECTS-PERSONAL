# YEK v0.0.8.9 — Hotfix 4: reserva segura de propiedades String

## Objetivo y alcance

Este hotfix revierte **solamente** el acceso a miembros mediante una ruta
entre comillas que se había introducido provisionalmente en Hotfix 3.
**No implementa todavía propiedades, clases, registros ni métodos de String.**
Mantiene la sintaxis general del operador `.` en el AST y el parser, para poder
resolver esos miembros por el tipo real del receptor en una futura versión.

## Sintaxis soportada

```yek
~import "03_ventas_con_funciones.yek"
_03_ventas_con_funciones.total!

~import "ventas/resumen.yek" as ventas
ventas.total!

~import "03_ventas_con_funciones.yek".importe as calcular
calcular(4)!

~export _03_ventas_con_funciones.total as totalVentas
```

- `~import "archivo.yek"` **no exige `as`**: alias generado según el archivo.
- Los alias generados son estables, pero pueden colisionar si dos rutas diferentes
  se normalizan al mismo identificador. En ese caso se exige `as` explícito.
- Alias numéricos reciben `_` inicial: `"03_ventas.yek"` → `_03_ventas`.
- Directorios y símbolos inválidos se sustituyen por `_` al crear el alias.
- Las importaciones selectivas, exportación explícita/automática, alias,
  reexportaciones normales, aislamiento, caché y ciclos se conservan.

## Sintaxis retirada deliberadamente

```yek
~import "03_ventas_con_funciones.yek"
"03_ventas_con_funciones.yek".total!  ~> RETIRADO
~export "03_ventas_con_funciones.yek".total as ventas  ~> RETIRADO
```

**Motivo:** `"hola".upper` y `"archivo.yek".total` comparten el mismo AST
`Member(Text, campo)`. El significado de una expresión String no puede cambiar
por las importaciones presentes. Desde HF4, ninguna cadena literal se registra
como nombre de módulo. `Expr::Text` no se convierte en un identificador al
resolver miembros; las propiedades de String están reservadas para el futuro.

## Ejemplos ejecutables

- `examples/modulos_v0089_hotfix3_normalizados/main.yek`: nombres generados.
- `examples/modulos_v0089_hotfix3_normalizados/02_resumen.yek`: reexportación
  mediante identificador; `main.yek` usa también esta fachada para comprobarla.
  El directorio conserva su nombre histórico, aunque los accesos literales
  ya no son válidos.

## Pruebas

```powershell
cargo check
cargo test --test modulos_v0089_hotfix4_miembros_seguros_tests -- --nocapture
cargo test
```

Pruebas heredadas que afirmaban el contrato provisional de Hotfix 3 se
archivaron en `docs/CONTRATO_HF3_SUPERADO_EJEMPLOS_RETIRADOS.txt`. No se ejecutan
porque volverían a exigir características explícitamente retiradas.

## Alcance de la verificación

Cambios realizados y revisión estática en el proyecto Rust. Este entorno no
cuenta con `cargo` ni `rustc`. Se requiere la compilación y la suite completa
sobre Windows para declarar estable el Hotfix 4.
