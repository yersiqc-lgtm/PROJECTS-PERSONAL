# YEK v0.0.9.2 — Etapa C NONE — HOTFIX H01

## Base
Proyecto completo de `YEK_v0.0.9.2_ETAPA_C_NONE_CANDIDATA`.

## Errores reportados en Windows
`cargo test --test none_tipo_universal_v0092_tests -- --test-threads=1 --nocapture`: 72/74 pasaron.

1. `none_assign_reserved`: el parser ordinario aceptaba `none` como destino de `=`. En `src/parser/mod.rs`, el parser ahora rechaza los literales reservados `none`, `true`, `false`, `inf` en cualquier posición de una asignación de variables, incluyendo asignaciones múltiples. Ya existían comprobaciones para nombres en otros analizadores de declaraciones y productores.
2. `num_empty_arrow`: **era una errata en la prueba**, no una carencia del parser: el manejador `'<->'` no tiene delimitador de cierre independiente porque `->` consume su `>`. La sintaxis correcta es `<->>` (una flecha `->` seguida de `>` para cerrar el manejador). Se ha corregido la prueba original, y se ha añadido un test que valida ambas formas. También sigue siendo válido omitir `<->>` por completo para pedir el fallback implícito.

## Semántica que permanece intacta
- `none` es un valor independiente, inmutable como literal pero asignable a variables.
- `a=none`, referencias vivas, colecciones, `-> none`, retornos múltiples: sin modificaciones.
- Sin fallback explícito, los contratos fallidos devuelven `none`; fallback explícito `0`, `false`, `""` o `none` se conserva.
- `->` con cero retornos sigue siendo distinto de `-> none`.
- No se añadió todavía `~try`, `~catch`, `Result` o `~raise`.

## Comandos de validación
```powershell
cargo check --all-targets
cargo test --test none_tipo_universal_v0092_tests -- --test-threads=1 --nocapture
cargo test --test none_hotfix_h01_literal_fallback_tests -- --test-threads=1 --nocapture
cargo test --all-targets
```

Resultado objetivo: **74/74** pruebas originales y **16/16** regresiones nuevas, más 1 prueba unitaria nueva del analizador de contratos. **No están certificadas en este entorno** porque Rust/Cargo no están instalados; se requiere compilación local.
