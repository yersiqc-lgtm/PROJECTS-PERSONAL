# YEK v0.0.9.1 — Núcleo recursión HOTFIX H03

## Fallo reproducido por el usuario

En Windows, `f(n)=~code -> f(n=n+1)` agotaba la pila nativa de Rust con
`STATUS_STACK_OVERFLOW (0xc00000fd)`. H02 había corregido las ranuras de
argumentos nombrados, pero el límite H01 de **20** invocaciones se comprobaba
**después** de evaluar los argumentos y crear varios marcos adicionales Rust.
No era un problema de `parameter already bound`, ni un error de sintaxis.

## Reparación general del despachador

- Un único límite de **13 llamadas interpretadas activas**, compartido por
  `invoke_code_with_slots` y las precomprobaciones de despacho.
- La entrada a `Expr::Call` comprueba la capacidad **antes de resolver el
  receptor y los argumentos**, lo que protege llamadas con argumentos nombrados,
  anidadas y expresiones `f(n=g(n))`.
- `invoke_named_code` vuelve a comprobar el límite antes de normalizar o
  evaluar argumentos; sirve como defensa adicional para cualquier entrada
  futura que no pase por `Expr::Call`.
- El motor `invoke_code_with_slots` conserva la comprobación común, que cubre
  las llamadas implícitas, constructores y `~block`.
- Se cuentan marcos activos de Code (`call_id.is_some()`), no invocaciones
  acumuladas desde el inicio del proceso. Los marcos se retiran al finalizar.
- Se conservan sin cambios la separación H02 de argumentos de una llamada
  frente a `code.bound` permanente y las demás funciones de importación.

El nuevo presupuesto conserva la prueba histórica de 12 pasos (`f(12)` llama
hasta `f(0)`, es decir, trece marcos) y previene intentar el paso siguiente.
**No es una garantía absoluta para programas con expresiones arbitrariamente
profundas o pilas nativas especialmente pequeñas.** Para recursividad profunda
hace falta un intérprete con pila explícita/trampolín; no se recomienda aumentar
el tamaño de la pila como solución a este defecto.

## Verificar en Windows

```powershell
cargo check --all-targets
cargo test --test recursion_dispatch_stack_safety_hotfix_h03_tests -- --test-threads=1 --nocapture
cargo test --test recursion_named_arguments_hotfix_h02_tests -- --test-threads=1 --nocapture
cargo test --test recursion_stack_safety_hotfix_h01_tests -- --test-threads=1 --nocapture
cargo test --test nucleo_recursion_importacion_v0091_tests -- --test-threads=1 --nocapture
cargo test --all-targets
```

Si algún comando devuelve `STATUS_STACK_OVERFLOW`, el fallo sigue abierto:
no se debe declarar el proyecto estable. **Cargo/rustc no están disponibles en
el entorno donde se preparó el ZIP, por lo que las pruebas no han sido
compiladas ni ejecutadas allí.**
