# YEK v0.0.9.1 — ENTREGA 2 / Sintaxis universal (candidata)

## Propósito
La entrega de modificadores avanzados (~class(...), ~struct(...), ~code(...), etc.) queda pospuesta a **Entrega 3**. Esta entrega se centra en mecanismos globales de sintaxis, iteración y resolución de miembros.

## Implementado en el código (pendiente de validación Cargo)

1. Aplicación parcial con nombres al crear BoundCode: `f(b=10,)!`, `f(b=10)!`. Se conservan los huecos posicionales y `f(10,)!`.
2. `for` sobre ValuePack: una instantánea por valor, con binder simple, patrón de índice y destructuración, además de iteraciones sincronizadas con Arrays/ValuePacks; no se escribe de vuelta al Pack original.
3. Continuación de firmas en `()` para `~code`, `~struct`, `~class`, `~block` usando scanner de delimitadores sin depender de la indentación interna.
4. Cabeceras `if`, `orif`, `for`, `~block nombre(...)` multilínea, con soporte de cuerpo de instrucciones en la misma línea (según la gramática del cuerpo).
5. Control de indentación uniforme para **hijos directos** de cuerpos indentados Code y controles. Sin impacto intencional en código global `~code`, contenido `~text`, expresiones delimitadas o fuentes declarativas.
6. Resolución de miembros para receptores temporales y expresiones anidadas, por ejemplo `Cuenta(20).ver!`.
7. Vistas explícitas `Struct.values`, `Struct.fields`, `Struct.entries` y `Class.values`, `Class.fields`, `Class.entries`. Las vistas de Class usan el orden declarado de sus campos (no métodos). Las vistas son snapshots de los valores actuales. Los campos/métodos con esos nombres tienen prioridad.
8. No se ha cambiado la semántica de las referencias a celdas (`!`), copia por valor de Struct, identidad compartida de Class, ni las reglas especiales de captura de Code.

## Exclusiones conscientes

- No se permite iteración implícita sobre `~struct` ni `~class`; utiliza `.values`, `.fields`, `.entries`.
- No hay mutación automática de ValuePack por referencias de iteración.
- No se incluyen modificadores avanzados `~struct(...)`/`~class(...)`, transacciones ni clases con herencia; serán parte de Entrega 3.
- No se reinterpreta internamente `~logic` y `~math` como `~code`.
- No se garantiza que métodos con nombre idéntico a una función nativa modifiquen sus reglas históricas.

## Validación en Windows / PowerShell

Situarse en esta carpeta, con Cargo.toml:

```
cargo check --all-targets
cargo test --test sintaxis_universal_entrega2_tests -- --nocapture
cargo test --test objetos_firmas_etapa1_tests -- --nocapture
cargo test --all-targets
```

Alternativa: `VERIFICAR_ENTREGA2_SINTAXIS_UNIVERSAL.cmd`

El entorno donde se generó esta candidata no tiene instalado Rust/Cargo. Se hizo auditoría estática y verificación ZIP, pero **NO** se ejecutó compilación ni pruebas Rust aquí. Solo se puede considerar estable después de obtener `cargo test --all-targets` satisfactoriamente en Windows.

## Sobre incompatibilidades intencionales

La indentación excesiva sin apertura de un nuevo ámbito, que antes se aceptaba accidentalmente en algunos Code, ahora produce un error explícito. Si un caso histórico dependía de esa tolerancia, habrá que revisarlo con cuidado: no debe arreglarse relajando indiscriminadamente la nueva regla.
