# H06C — Verificación de dominios Auto

17 casos nuevos (15 válidos, 2 rechazos esperados), más los 57 casos originales de H06.

Ejecutar desde la raíz del proyecto:

```powershell
cargo build
cargo test --test etapa6_h06_migracion_unificada_tests
cargo test --test etapa6_h06a_rangos_explicitos_tests
cargo test
py -3 EJEMPLOS_H06C_DOMINIOS_AUTO\ejecutar_h06c.py
```

H06C no modifica la semántica de rangos ni `~in(num/str/bool)`; modifica únicamente la preservación del tipo de literales dentro del dominio de `~in(auto=...)`.
