# YEK H07C — Correccion de 14 resultados esperados (Etapa 7)

Base: YEK H07B. No se modifica el parser, el interprete, el compilador ni las pruebas Rust.

## Por que fallaban
H07 definio que las expresiones separadas por coma despues de `->` se producen todas
**por cada iteracion** de un productor situado dentro de Array o ValuePack.
Los archivos `qa_exhaustiva/esperados` aun conservaban la regla anterior en 14 casos.

Ejemplos:
```
a=[for(0)->7,42]        # []
a=[for(1)->7,42]        # [7, 42]
a=[for(2)->7,42]        # [7, 42, 7, 42]
a=[for(x=1..3)->(x,x*x),99]
# [(1, 1), 99, (2, 4), 99, (3, 9), 99]
```

## Archivos ajustados
- `qa_exhaustiva/esperados/produccion_cero_y_multivalor_00.txt`
- `qa_exhaustiva/esperados/produccion_cero_y_multivalor_02.txt` al `_13.txt`
- `qa_exhaustiva/esperados/cruzadas_productor_con_coma_exterior.txt`

El caso `_01` no se modifica: su resultado `[7, 42]` ya es valido.

## Verificacion en Windows (PowerShell, desde Cargo.toml)
```
cargo build
cargo test --test qa_exhaustiva_fixtures_tests
cargo test --test arrow_break_nested_regression_tests
cargo test --test etapa7_h07_universal_tests
cargo test
```

**Nota**: Comprobamos integridad del ZIP y consistencia de los 14 oraculos de forma
estatica; Cargo no esta disponible en el entorno de empaquetado. Es necesario
verificar la ejecucion real en Windows.
