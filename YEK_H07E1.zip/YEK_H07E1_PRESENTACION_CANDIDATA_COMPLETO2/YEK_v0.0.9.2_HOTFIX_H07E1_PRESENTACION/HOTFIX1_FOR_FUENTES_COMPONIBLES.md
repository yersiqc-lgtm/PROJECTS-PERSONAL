# YEK v0.0.9.0 — Hotfix 1: fuentes de `for` componibles

Se corrige `clean_control_line` para que reconozca `for` y `if` **anidados dentro de expresiones**, reutilizando el mismo escáner de código que ya preserva productores en asignaciones. Un encabezado de control no puede tratar indiscriminadamente cualquier `~` posterior como comentario.

Ejemplo válido:

```yek
for(x in [for(y in 1..3),[for(z in 1..2)],4])
    x!
```

El mismo valor de la fuente debe comportarse igual si se asigna primero a una variable. Se conserva `for(x=...)` temporalmente como sintaxis de compatibilidad.

## Verificación en Windows

Desde la carpeta de `Cargo.toml`:

```powershell
cargo check
cargo test --test for_fuentes_componibles_v0090_hotfix1_tests -- --nocapture
cargo test
```

La extensión 0.3.7 destaca `in` con exactamente el mismo estilo que `as`.
