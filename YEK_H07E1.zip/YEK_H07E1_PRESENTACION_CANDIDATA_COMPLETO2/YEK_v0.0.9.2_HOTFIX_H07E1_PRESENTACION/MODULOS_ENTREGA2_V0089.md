# YEK v0.0.8.9 — Entrega 2/2: Herramientas de módulos

Base: **v0.0.8.8 Entrega 1 Hotfix 1**. Conserva `~import`, `~export`, alias, reexportaciones, caché, privacidad y sintaxis de listas.

## Lo implementado

### 1. Inspección de interfaz pública

```powershell
yek inspect stdlib/math.yek
yek inspect math
yek inspect str
yek inspect examples/modulos_v0088_etapa1/fachada.yek
```

Muestra exportaciones reales, nombres públicos, origen interno, firmas de funciones cuando están disponibles y dependencias directas. **No ejecuta ningún programa `.yek`.** Es posible inspeccionar bibliotecas `.yek` que contengan `~export` al nivel superior.

### 2. Árbol de dependencias

```powershell
yek deps examples/modulos_v0088_etapa1/main.yek
```

Utiliza el mismo cargador para resolver rutas, importar módulos de la biblioteca estándar, detectar ciclos y comprobar símbolos selectivos. Indica cuándo un módulo ya apareció en el árbol (`cached`). El árbol es descriptivo: la caché real del intérprete no se altera.

### 3. Documentación automática

```powershell
yek docs examples/modulos_v0088_etapa1/operaciones.yek
yek docs examples/modulos_v0088_etapa1/operaciones.yek --out API.md
```

Genera Markdown con el nombre público y su fuente, firmas conocidas y dependencias directas. La salida de la herramienta no ejecuta instrucciones de nivel superior.

### 4. Diagnósticos sugeridos, sin autocorrección

```yek
~import math.squre
```

Da un error con candidatos como `square` cuando la similitud sea suficiente y un listado de exportaciones disponibles. También reconoce nombres de miembros accesibles en la expresión `math.squre(...)`. No modifica el programa ni habilita símbolos privados.

### 5. Extensión VS Code 0.3.4

- Ctrl+clic en una ruta entrecomillada `.yek` o `.txt` dentro de una importación abre el archivo correspondiente.
- Comandos de paleta: **YEK: Inspeccionar módulo**, **Mostrar dependencias**, **Generar documentación (vista previa)**.
- Conserva los colores, la ejecución y la verificación de la v0.3.3.
- Necesita el `Cargo.toml` de la nueva versión configurado en `yek.manifestPath` o un ejecutable `yek` actualizado en `yek.executablePath`.

## Importación `except` y `lazy`: contrato evaluado, no implementado

**`except`**: se recomienda limitarlo inicialmente a un *namespace* explícito (por ejemplo `~import math except(square)`), sin introducir símbolos invisibles en el ámbito global; deben definirse interacciones con la importación selectiva y las reexportaciones antes de implementarlo.

**`lazy`**: se recomienda crear un estado de inicialización `Unloaded / Initializing / Ready / Failed` y resolver la primera lectura de un símbolo con protección contra ciclos. Mientras no exista ese mecanismo, aceptar `lazy` silenciosamente sería incorrecto. Por eso esta entrega **rechaza** `lazy` como sintaxis desconocida, en lugar de simular una carga diferida.

## Verificación en Windows

Abre PowerShell en la raíz del proyecto y ejecuta:

```powershell
cargo test --test modulos_v0089_etapa2_tests -- --nocapture
cargo test
cargo check
cargo run -- inspect math
cargo run -- deps examples/modulos_v0088_etapa1/main.yek
cargo run -- docs examples/modulos_v0088_etapa1/operaciones.yek --out API.md
```

El nombre del ejecutable y del paquete es `yek`. Las pruebas de Rust **no se pudieron ejecutar en el entorno de preparación**; requieren confirmación en Windows. La extensión JavaScript sí superó 47 pruebas.

## Restricciones y seguridad

- `inspect`, `deps` y `docs` analizan archivos locales que el propio proyecto importa, sin ejecutar YEK.
- El cargador sigue rechazando ciclos, archivos faltantes y exportaciones desconocidas.
- Importar un módulo mediante `yek run` **sí ejecuta** su inicialización; utilizar únicamente bibliotecas de confianza.
- Los módulos nativos `str` y `math` pueden consultarse por nombre; los módulos creados por usuarios se indican mediante su ruta `.yek`.
- Esta entrega no incorpora un intérprete de archivos `.py`, paquetes remotos ni un gestor de dependencias de terceros.
