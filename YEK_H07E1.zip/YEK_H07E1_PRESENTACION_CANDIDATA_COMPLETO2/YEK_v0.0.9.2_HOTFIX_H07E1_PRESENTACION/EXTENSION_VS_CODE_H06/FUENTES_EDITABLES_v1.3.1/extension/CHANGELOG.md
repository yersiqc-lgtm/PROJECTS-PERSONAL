## 1.3.1 (H06F)
- Distingue visualmente los extremos literales Unicode `a..d`, conservando los operadores y las variables agrupadas.
- Motor de VS Code y comandos Cargo idénticos a 1.3.0.

## 1.3.0 — Migración H06
- Coloreado de ~in y subtipos de entrada.
- Nuevas plantillas para entrada estricta, Bool y reserva.
- Se preservan ejecución Cargo, modos texto/invalid y cadenas activas.

# YEK VSIX — Historial

## 1.2.0 — H05B, resaltado contextual
- Modos raw `~invalid` y `~text` hasta la siguiente directiva de modo global reconocida, con colores de comentario/texto.
- Expresiones activas completas dentro de cadenas: operadores `!` y `?` idénticos a fuera de comillas; miembros, índices, aritmética y paréntesis con resaltado YEK.
- Sintaxis inline completa `if/orif/else`, `.vlen`, ayuda y snippets H04–H05.
- Preserva iconos, comandos, ejecución vía Cargo, compatibilidad con Windows y configuración 1.1.1.

# Historial de cambios

## 1.1.1 — corrección de ejecución desde VS Code
- El valor predeterminado de `yek.executablePath` ahora es `auto`.
- Ejecutar y Verificar detectan `Cargo.toml` en directorios ascendentes y utilizan Cargo automáticamente.
- `cargo run --quiet --manifest-path ... -- run/check archivo.yek` recompila el motor cuando hay cambios.
- Se respeta una ruta personalizada `yek.exe` y los comandos instalados en PATH, sin buscar `yek` como archivo del proyecto.
- Rutas con espacios se pasan como argumentos separados de VS Code.
- Nueva batería de pruebas del planificador de ejecución para archivos anidados y rutas con espacios.

## 1.1.0
- Asociaciones oficiales solo `.yek`, id `yek`, comando `yek`, iconos aprobados.
- Gramática actualizada con palabras reservadas del lexer/source/input/interpreter.
- `for / if / orif / else` sin tilde; variantes antiguas marcadas obsoletas.
- Categorías y paleta diferenciadas para `none`, conversiones UCS, directivas de entrada, métodos y operadores.
- Snippets corregidos y ampliados; hover/autocompletado, lenguaje y documentación renovados.
- Iconos nuevos para YEK, más tema de iconos opcional.

## Nota
- El paquete VSIX se verificó estáticamente, sin ejecutar pruebas integradas dentro de VS Code.
