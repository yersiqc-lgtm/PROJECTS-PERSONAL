# YEK VSIX 1.3.1 (H06F)
Actualización visual de rangos de caracteres; sustituye 1.3.0. Los comandos Cargo, ejemplos y el código de ejecución se conservan.
La gramática TextMate colorea rangos alfabéticos unitarios como `a..d`; la validez de expresiones es responsabilidad del parser Rust, no de esta gramática.
