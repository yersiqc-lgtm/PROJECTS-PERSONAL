require 'json'
require 'pathname'
require 'test/unit/assertions'
include Test::Unit::Assertions
root=Pathname.new(__dir__).parent
repo=JSON.parse((root/'extension/syntaxes/yek.tmLanguage.json').read)['repository']
checks=[]
def walk(o,path,checks)
  case o
  when Hash
    o.each do |k,v|
      if %w[match begin end while].include?(k) && v.is_a?(String)
        begin
          Regexp.new(v)
          checks << path+'/'+k
        rescue Exception=>e
          raise "Regex inválida en #{path}/#{k}: #{e} :: #{v}"
        end
      else
        walk(v,"#{path}/#{k}",checks)
      end
    end
  when Array
    o.each_with_index{|v,i|walk(v,"#{path}/#{i}",checks)}
  end
end
walk(repo,'repository',checks)
pattern = ->(section,ix,key='match'){Regexp.new(repo[section]['patterns'][ix][key])}
invalid_start=pattern.call('raw-invalid-mode',0,'begin')
text_start=pattern.call('raw-text-mode',0,'begin')
mode_end=pattern.call('raw-invalid-mode',0,'end')
paren_start=pattern.call('active-embedded-expression',0,'begin')
contiguous_start=pattern.call('active-embedded-expression',1,'begin')
output=pattern.call('strings',0,'match') rescue nil
assert(invalid_start.match?('~invalid  unparsed content!'))
assert(invalid_start.match?("    ~invalid  contenido"))
assert(!invalid_start.match?('"~invalid"'))
assert(!invalid_start.match?('~invalidado'))
assert(!invalid_start.match?('x=~invalid'))
assert(text_start.match?('~text'))
assert(!text_start.match?('~texto'))
assert(!mode_end.match?("texto ordinario\nnot a mode"))
assert(mode_end.match?("~code 5!"))
assert(mode_end.match?("  ~text"))
assert(!mode_end.match?('~codeX'))
assert(!mode_end.match?('  ~ unknown'))
assert(paren_start.match?('(2 + 5)!'))
assert(paren_start.match?('(~math 2+5)!'))
assert(paren_start.match?('(true and false)!'))
assert(paren_start.match?('((2 + 5)*2)!'))
assert(paren_start.match?('(f(x)+1)!'))
assert(!paren_start.match?('(a + 2) text'))
assert(contiguous_start.match?('i+1!'))
assert(contiguous_start.match?('c.value!'))
assert(contiguous_start.match?('a[1][0]-4!'))
assert(contiguous_start.match?('f(3)+1!'))
assert(contiguous_start.match?('x>=4!'))
assert(contiguous_start.match?('nombre?'))
assert(!contiguous_start.match?('valor sin signo'))
assert(!contiguous_start.match?('\\!'))
assert(!contiguous_start.match?('literal \\variable!'))
str=repo['strings']['patterns'][0]
str_esc=Regexp.new(str['patterns'][0]['match']); str_out=Regexp.new(str['patterns'][2]['match']); str_in=Regexp.new(str['patterns'][3]['match']);
assert(str_out.match?('x!'))
assert(!str_out.match?('\\!'))
assert(str_in.match?('a?'))
assert(!str_in.match?('\\?'))
assert(str_esc.match?('\\!'))
assert(str_esc.match?('\\?'))
assert(str_esc.match?('\\033'))
assert(str_esc.match?('\\u{1F600}'))
puts "OK: #{checks.size} patrones TextMate compilados por Oniguruma (Ruby); 33+ comprobaciones de fronteras de modos y operadores activos"
closing = Regexp.new(str['end'])
assert(closing.match?('"'))
assert(!closing.match?('\\"'))
assert(closing.match?('\\\\"'))
assert(!closing.match?('\\\\\\"'))
assert(closing.match?('\\\\\\\\"'))
puts 'OK: cierre de comillas con escapes pares/impares validado'
