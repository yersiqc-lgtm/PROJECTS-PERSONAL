"use strict";
const assert = require("assert");
const fs = require("fs");
const os = require("os");
const path = require("path");
const vm = require("vm");
const {planExecution,findProjectRoot,isYekManifest} = require("../extension/runner");

async function main() {
 const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'YEK project with spaces '));
 try {
  const root=path.join(temp,'YEK_v0.0.9.2');
  const nested=path.join(root,'EJEMPLOS_NONE');
  fs.mkdirSync(nested,{recursive:true});
  fs.writeFileSync(path.join(root,'Cargo.toml'),'[package]\nname = "yek"\nversion = "0.0.9"\n');
  const source=path.join(nested,'01_valor_y_comparaciones.yek');
  fs.writeFileSync(source,'~code\nnone!\n');
  assert.strictEqual(findProjectRoot(nested),root);
  assert.ok(isYekManifest(path.join(root,'Cargo.toml')));
  let plan=planExecution({sourceFile:source,workspaceFolder:root,executableSetting:'auto',mode:'run'});
  assert.equal(plan.kind,'shell'); assert.equal(plan.command,'cargo');
  assert.deepEqual(plan.args,['run','--quiet','--manifest-path',path.join(root,'Cargo.toml'),'--','run',source]);
  assert.equal(plan.cwd,root);
  plan=planExecution({sourceFile:source,workspaceFolder:root,executableSetting:'yek',mode:'check'});
  assert.equal(plan.command,'cargo'); assert.equal(plan.args[5],'check');
  const manual=path.join(root,'target','debug','yek.exe');
  fs.mkdirSync(path.dirname(manual),{recursive:true});fs.writeFileSync(manual,'');
  plan=planExecution({sourceFile:source,executableSetting:manual,mode:'run'});
  assert.equal(plan.kind,'process');assert.equal(plan.command,manual);
  plan=planExecution({sourceFile:source,executableSetting:'target/debug/yek.exe',mode:'run'});
  assert.equal(plan.kind,'process');assert.equal(plan.command,manual);
  plan=planExecution({sourceFile:source,executableSetting:'Z:/not-real/yek.exe',mode:'run'});
  assert.equal(plan.kind,'error');
  plan=planExecution({sourceFile:source,executableSetting:'yek-custom',mode:'run'});
  assert.equal(plan.kind,'shell');assert.equal(plan.command,'yek-custom');
  plan=planExecution({sourceFile:source,executableSetting:'auto',mode:'tokens'});
  assert.equal(plan.kind,'error');
  const orphan=path.join(temp,'outside','file.yek');
  fs.mkdirSync(path.dirname(orphan),{recursive:true});fs.writeFileSync(orphan,'~code\n');
  plan=planExecution({sourceFile:orphan,executableSetting:'auto',mode:'run'});
  assert.equal(plan.kind,'shell'); assert.equal(plan.command,'yek');

  // Test VS Code command registration + task launch through a fake host.
  const handlers=new Map(); const tasks=[];
  const vscode={
    window:{activeTextEditor:{document:{languageId:'yek',uri:{fsPath:source},isUntitled:false,isDirty:false}},showWarningMessage:(x)=>{throw Error(x)},showErrorMessage:(x)=>{throw Error(x)}},
    workspace:{getConfiguration:()=>({get:(k,d)=>k==='executablePath'?'auto':d}),getWorkspaceFolder:()=>({uri:{fsPath:root}})},
    commands:{registerCommand:(name,fn)=>{handlers.set(name,fn);return {dispose(){}};}},
    languages:{registerHoverProvider:()=>({dispose(){}}),registerCompletionItemProvider:()=>({dispose(){}}),registerDocumentSymbolProvider:()=>({dispose(){}})},
    ShellExecution:class {constructor(command,args,options){this.command=command;this.args=args;this.options=options;}},
    ProcessExecution:class {constructor(command,args,options){this.command=command;this.args=args;this.options=options;}},
    Task:class {constructor(definition,scope,name,source,execution){Object.assign(this,{definition,scope,name,source,execution});}},
    tasks:{executeTask:async task=>{tasks.push(task)}},
    TaskScope:{Workspace:'workspace'},TaskRevealKind:{Always:1},TaskPanelKind:{Shared:1}
  };
  const modPath=path.resolve(__dirname,'../extension/extension.js');
  const text=fs.readFileSync(modPath,'utf8');
  const extensionModule={exports:{}};
  vm.runInNewContext(`(function(require,module,exports){${text}\n})`,{}, {filename:modPath})(n=>n==='vscode'?vscode:n==='./runner'?require('../extension/runner'):require(n),extensionModule,extensionModule.exports);
  extensionModule.exports.activate({subscriptions:[]});
  await handlers.get('yek.run')();
  await handlers.get('yek.check')();
  assert.equal(tasks.length,2);
  assert.equal(tasks[0].execution.command,'cargo');
  assert.equal(tasks[0].execution.args[5],'run');
  assert.equal(tasks[1].execution.args[5],'check');
  console.log('OK: 14 comprobaciones de planificador YEK y ejecución VS Code simulada');
 } finally {fs.rmSync(temp,{recursive:true,force:true});}
}
main().catch(e=>{console.error(e);process.exitCode=1});
