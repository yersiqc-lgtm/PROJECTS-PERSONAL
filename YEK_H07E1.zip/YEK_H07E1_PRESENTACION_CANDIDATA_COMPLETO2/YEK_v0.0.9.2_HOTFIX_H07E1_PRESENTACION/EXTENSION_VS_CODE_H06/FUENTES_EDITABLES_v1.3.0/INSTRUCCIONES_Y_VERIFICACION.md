# YEK — extensión VS Code 1.2.0 (motor H05B)

## Instalación

1. VS Code → **Extensiones** → menú `...` → **Instalar desde VSIX**.
2. Seleccionar `YEK_Lenguaje_v1.2.0_H05B_Resaltado_Contextual.vsix`.
3. Si VS Code propone reemplazar 1.1.1, aceptarlo; **Recargar ventana**.
4. Abrir `PRUEBA_VISUAL_H05B.yek` y comprobar la asociación **YEK** en la barra inferior.

## Comprobaciones visuales

- `~invalid` aparece como directiva y las siguientes líneas quedan **gris/cursiva**, incluso caracteres de sintaxis incorrecta. La siguiente directiva reconocida devuelve el coloreado normal.
- `~text` aparece como directiva y las siguientes líneas quedan en color **texto**, sin colorear operadores internos ni palabras clave.
- En una cadena ordinaria, `!` y `?` aparecen en el mismo color que fuera de comillas, incluyendo `x+1!`, `c.value!`, `(2 + 5)!` y `(~math 2+5)!`.
- `\!` / `\?` se mantienen como escapes, no como operadores activos.
- `if`, `orif`, `else` se distinguen también en un mismo renglón.
- `.vlen`, `none="nada"` y `f(x!)` tienen actualización de color, ayuda o fragmentos de código.

## Lo que no cambia

- Los comandos **YEK: Ejecutar archivo actual** y **YEK: Verificar archivo actual**, incluida la detección de `Cargo.toml` y la compilación automática.
- Iconos, logo, identidad de la extensión y extensión `.yek`.
- El motor Rust **no se incluye ni se modifica**.

## Limitaciones verificadas

TextMate realiza **coloreado aproximado** y no sustituye el parser YEK. Detecta las expresiones contiguas frecuentes y expresiones agrupadas hasta tres niveles de paréntesis, pero las expresiones profundamente anidadas o una captura `x=~text` con límite de indentación pueden diferir de la semántica real: son ámbitos que pueden requerir un analizador semántico en una versión futura.

## Pruebas técnicas automatizadas de las fuentes

Desde la carpeta de fuentes, con Node.js y Ruby:

```powershell
node --check extension/extension.js
node --check extension/runner.js
node tests/runner.test.js
ruby tests/grammar_regex.test.rb
```

La verificación del empaquetado, comprobación de regex Oniguruma y pruebas simuladas de Run/Check **se ejecutaron**. No se ha realizado prueba dentro de VS Code de Windows en este entorno; esa validación visual debe hacerse después de instalar la extensión.
