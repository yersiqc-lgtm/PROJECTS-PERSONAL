"use strict";
const vscode = require("vscode");
const {planExecution} = require("./runner");
const HELP = Object.freeze({
  "~code": "Modo ejecutable y funciones Code. Ejemplo: f(x)=~code -> x.",
  "~text": "Modo texto raw: todo el contenido, hasta la siguiente directiva oficial de modo, se trata como texto literal sin ejecutar operadores.",
  "~invalid": "Descarta el contenido hasta la siguiente directiva oficial de modo: se representa en gris como comentario, aunque el texto sea sintácticamente inválido.",
  "~block": "Bloque operativo y bloque con nombre, admite opciones como once, when, atomic y trace.",
  "~struct": "Tipo Struct por valor con .with, .snapshot, .validate y .rows.",
  "~class": "Tipo Class con identidad, métodos, campos, privacidad y guardas.",
  "~logic": "Lenguaje declarativo lógico; relaciones con operador <-.",
  "~math": "Modo matemático; números y expresiones simbólicas.",
  "~import": "Importación de módulos .yek y exportaciones públicas con alias y filtros.",
  "~export": "Define símbolos expuestos del módulo o de un tipo.",
  "~auto": "Entrada automática para ?.",
  "~num": "Contexto de entrada numérica; contratos, intentos y fallback.",
  "~str": "Contexto de entrada de texto; restricciones de caracteres/longitud.",
  "~bool": "Contexto de entrada booleana, acepta contratos.",
  "for": "Control de iteración y generador YEK; sin prefijo ~.",
  "if": "Condicional YEK estricto (Bool), sin ~. Desde H05B admite if(cond) acción else alternativa en una sola línea, sin anidamientos inline ambiguos.",
  "orif": "Rama condicional alternativa; desde H05B también puede compartir renglón con if y else.",
  "else": "Rama final de if/orif; admite forma multilínea o en el mismo renglón que las otras ramas.",
  "break": "Interrumpe un ciclo.",
  "continue": "Salta al siguiente elemento del ciclo.",
  "go": "Palabra de control usada por el intérprete.",
  "block": "Forma de bloque reconocida por el lexer.",
  "in": "Operador de vinculación/iteración.",
  "and": "Conjunción lógica.",
  "or": "Disyunción lógica.",
  "not": "Negación lógica.",
  "true": "Literal booleano verdadero.",
  "false": "Literal booleano falso.",
  "none": "Valor de ausencia distinto de 0 y false. none=\"nada\" personaliza únicamente su representación visible.",
  "inf": "Marcador de infinitud contextual, principalmente en contratos de entrada.",
  "self": "Receptor actual de un método de Class.",
  "pure": "Declara ejecución Code sin efectos externos.",
  "cache": "Memoización; exige pure.",
  "trace": "Traza de ejecución.",
  "once": "Ejecuta un Block una vez con éxito.",
  "atomic": "Intenta revertir cambios internos en error.",
  "private": "Campos privados.",
  "when": "Precondición de Block; when=...",
  "guard": "Invariante en Struct/Class; guard=...",
  "as": "Alias en importaciones.",
  "without": "Exclusión en ~import/~export.",
  "num": "Conversión nativa a número exacto; num(\"42\") o referencia num!. Distinta de ~num.",
  "str": "Conversión nativa a texto; str(valor) o str!. Distinta de ~str.",
  "bool": "Conversión nativa a Bool; bool(valor), bool.parse(...) o bool!. Distinta de ~bool.",
  "array": "Construye/convierte Array; también puede conservar una vista al recibir referencia.",
  "pack": "Construye/convierte ValuePack.",
  "set": "Construye/convierte Set.",
  "dict": "Construye/convierte Map.",
  "Set": "Alias de constructor Set en expresiones.",
  "convert": "Convierte elementos de una colección, usando por ejemplo num!.",
  "convert_keys": "Convierte las claves de Map con convertidor capturado.",
  "convert_values": "Convierte valores de Map con convertidor capturado.",
  "parse": "bool.parse: convertidor de cadenas con reglas propias.",
  "keys": "Claves de Map.",
  "values": "Valores de Map; .values! produce vista viva.",
  "entries": "Entradas de Map.",
  "contains": "Comprueba pertenencia en Map/Set.",
  "union": "Unión de conjuntos.",
  "intersection": "Intersección de conjuntos.",
  "difference": "Diferencia de conjuntos.",
  "invert": "Intercambia claves y valores de Map cuando es posible.",
  "snapshot": "Captura estado de Struct/Class.",
  "validate": "Valida la guarda de Struct/Class.",
  "type": "Opción de contrato de entrada: type=...",
  "attempts": "Opción de reintentos en contratos.",
  "deep": "Opción deep=true en conversiones UCS.",
  "vlen": "Longitud visible en grafemas Unicode: texto.vlen o str.vlen(texto). No reemplaza a .len.",
  "!": "Operador activo de salida/referencia. En cadenas evalúa operandos adyacentes, por ejemplo x+1! o (x + 1)!. También puede exigirse en f(x!).",
  "?": "Operador activo de entrada. En cadenas sigue las reglas de destino modificable y adyacencia del lenguaje."
});
const DIRECTIVES = ["~code", "~text", "~invalid", "~block", "~struct", "~class", "~logic", "~math", "~import", "~export", "~auto", "~num", "~str", "~bool"];
const KEYWORDS = ["for", "if", "orif", "else", "break", "continue", "go", "block", "in", "and", "or", "not", "as", "without", "pure", "cache", "trace", "once", "atomic", "private", "when", "guard", "true", "false", "none", "inf", "self"];
const CONVERTERS = ["num", "str", "bool", "array", "pack", "dict", "set", "Set"];
async function invokeCLI(mode) {
  const editor = vscode.window.activeTextEditor;
  if (!editor || editor.document.languageId !== "yek") {
    vscode.window.showWarningMessage("Abre primero un archivo .yek de YEK."); return;
  }
  const doc = editor.document;
  if (doc.isUntitled) {
    vscode.window.showWarningMessage("Guarda el archivo .yek antes de ejecutarlo."); return;
  }
  const cfg = vscode.workspace.getConfiguration("yek", doc.uri);
  if (cfg.get("saveBeforeRun", true) && doc.isDirty && !(await doc.save())) return;

  const folder = vscode.workspace.getWorkspaceFolder(doc.uri);
  const launch = planExecution({
    sourceFile: doc.uri.fsPath,
    workspaceFolder: folder ? folder.uri.fsPath : undefined,
    executableSetting: cfg.get("executablePath", "auto"),
    mode
  });
  if (launch.kind === "error") {
    vscode.window.showErrorMessage(launch.message); return;
  }
  const execution = launch.kind === "process"
    ? new vscode.ProcessExecution(launch.command, launch.args, {cwd: launch.cwd})
    : new vscode.ShellExecution(launch.command, launch.args, {cwd: launch.cwd});
  const task = new vscode.Task(
    {type: "yek", task: mode}, folder || vscode.TaskScope.Workspace,
    `YEK: ${mode} (${launch.description})`, "YEK", execution
  );
  task.presentationOptions = {reveal: vscode.TaskRevealKind.Always, panel: vscode.TaskPanelKind.Shared};
  try { await vscode.tasks.executeTask(task); }
  catch (error) {
    vscode.window.showErrorMessage(
      "No se pudo iniciar YEK: " + String(error) +
      ". Si usas Cargo, ejecuta «cargo --version» en la terminal de VS Code y verifica Cargo.toml."
    );
  }
}
function activate(context) {
  context.subscriptions.push(vscode.commands.registerCommand("yek.run",()=>invokeCLI("run")));
  context.subscriptions.push(vscode.commands.registerCommand("yek.check",()=>invokeCLI("check")));
  context.subscriptions.push(vscode.languages.registerHoverProvider("yek",{
    provideHover(document,position) {
      const range=document.getWordRangeAtPosition(position,/~?[A-Za-z_][A-Za-z0-9_]*/);
      if (!range) return;
      const word=document.getText(range);
      const description=HELP[word];
      if (!description) return;
      const markdown=new vscode.MarkdownString(`**${word}**\n\n${description}`);
      markdown.isTrusted=false;
      return new vscode.Hover(markdown,range);
    }
  }));
  context.subscriptions.push(vscode.languages.registerCompletionItemProvider("yek",{
    provideCompletionItems(document,position) {
      return [...DIRECTIVES,...KEYWORDS,...CONVERTERS].map(word=>{
        const isConverter=CONVERTERS.includes(word);
        const item=new vscode.CompletionItem(word,isConverter?vscode.CompletionItemKind.Function:vscode.CompletionItemKind.Keyword);
        item.detail="YEK — núcleo 0.0.9.2";
        item.documentation=HELP[word]||"";
        return item;
      });
    }
  },"~","."));
  context.subscriptions.push(vscode.languages.registerDocumentSymbolProvider("yek",{
    provideDocumentSymbols(document) {
      const symbols=[];
      for(let i=0;i<document.lineCount;i++) {
        const line=document.lineAt(i);
        const match=/^\s*([\p{L}_][\p{L}\p{N}_]*)\s*(?:\([^\n]*\))?\s*=\s*~(code|block|class|struct|logic|math)\b/u.exec(line.text);
        if(!match)continue;
        const kind=(match[2]==="class"||match[2]==="struct")?vscode.SymbolKind.Class:vscode.SymbolKind.Function;
        const begin=line.text.indexOf(match[1]);
        symbols.push(new vscode.DocumentSymbol(match[1],match[2],kind,line.range,new vscode.Range(i,begin,i,begin+match[1].length)));
      }
      return symbols;
    }
  }));
}
function deactivate(){}
module.exports={activate,deactivate};
