"use strict";
const fs = require("fs");
const path = require("path");

function isYekManifest(filename) {
  try {
    const manifest = fs.readFileSync(filename, "utf8");
    return /^\s*name\s*=\s*["']yek["']\s*(?:#.*)?$/m.test(manifest);
  } catch (_error) { return false; }
}

// Find the YEK Cargo project even when a file is opened from a nested folder.
function findProjectRoot(start) {
  if (!start) return null;
  let current = path.resolve(start);
  while (true) {
    if (isYekManifest(path.join(current, "Cargo.toml"))) return current;
    const parent = path.dirname(current);
    if (parent === current) return null;
    current = parent;
  }
}

function compiledBinary(root) {
  if (!root) return null;
  const binary = process.platform === "win32" ? "yek.exe" : "yek";
  for (const profile of ["debug", "release"]) {
    const candidate = path.join(root, "target", profile, binary);
    if (fs.existsSync(candidate)) return candidate;
  }
  return null;
}

function isAutomaticSetting(value) {
  return !value || value.toLowerCase() === "auto" || value.toLowerCase() === "yek";
}

// A pure, independently testable launch planner. No VS Code runtime required.
// Auto: use cargo run when Cargo.toml is present so a changed Rust engine
// is rebuilt before every YEK Run/Check. Do not run a bare relative executable
// using ProcessExecution: Windows resolves it against cwd, not necessarily PATH.
function planExecution({sourceFile, workspaceFolder, executableSetting = "auto", mode}) {
  if (mode !== "run" && mode !== "check") {
    return {kind: "error", message: "Comando YEK no reconocido: " + mode};
  }
  const directory = path.dirname(sourceFile);
  const root = findProjectRoot(directory) || findProjectRoot(workspaceFolder);
  const cwd = root || workspaceFolder || directory;
  const setting = String(executableSetting ?? "auto").trim();

  if (!isAutomaticSetting(setting)) {
    // Explicit path (absolute or relative to Cargo root/workspace) -> process.
    // Bare executable name -> shell, so the OS resolves it through PATH.
    const appearsToBePath = path.isAbsolute(setting) || /[\\/]/.test(setting);
    if (!appearsToBePath) {
      return {kind: "shell", command: setting, args: [mode, sourceFile], cwd, description: "PATH"};
    }
    const candidate = path.isAbsolute(setting) ? setting : path.resolve(cwd, setting);
    if (!fs.existsSync(candidate)) {
      return {kind: "error", message: `No existe el ejecutable configurado: ${candidate}. Comprueba yek.executablePath o usa «auto».`};
    }
    return {kind: "process", command: candidate, args: [mode, sourceFile], cwd, description: "binario configurado"};
  }

  // Prefer Cargo to always compile the updated language before Run/Check.
  if (root) {
    return {
      kind: "shell", command: "cargo",
      args: ["run", "--quiet", "--manifest-path", path.join(root, "Cargo.toml"), "--", mode, sourceFile],
      cwd: root, description: "cargo run (compilación incremental automática)"
    };
  }
  // A standalone distribution might have no Cargo.toml but contain the binary.
  const local = compiledBinary(workspaceFolder) || compiledBinary(directory);
  if (local) return {kind: "process", command: local, args: [mode, sourceFile], cwd, description: "binario local"};

  // Last resort: shell PATH (never ProcessExecution("yek") on Windows).
  return {kind: "shell", command: "yek", args: [mode, sourceFile], cwd, description: "yek en PATH"};
}

module.exports = {planExecution, findProjectRoot, isYekManifest, isAutomaticSetting, compiledBinary};
