# YEK — extensión oficial de desarrollo (VS Code)

**Extensión del paquete:** 1.2.0 · **Núcleo de referencia:** YEK 0.0.9.2 · **Archivos:** `.yek` exclusivamente.

## Funciones

- Resaltado TextMate organizado por categorías, en lugar de colorear todas las palabras igual.
- Colores YEK definidos por scopes específicos: control, directivas, conversores, literales, operadores, métodos, tipos, cadenas y comentarios. Se pueden sobrescribir desde el tema/configuración personal.
- Snippets `yek-*`, autocompletado, ayuda contextual y símbolos de funciones/tipos.
- Comandos **YEK: Ejecutar archivo actual** y **YEK: Verificar archivo actual**.
- Logo aprobado de YEK y un icono cuadrado adaptado para `.yek`.

## Colores de sintaxis

| Categoría | Ejemplos | Color predeterminado |
|---|---|---|
| Control | `for`, `if`, `orif`, `else`, `break`, `continue`, `go`, `in`, `block` | Rosa |
| Modos | `~code`, `~text`, `~logic`, `~math`, `~struct`, `~class`, `~block` | Lila |
| Módulos | `~import`, `~export` | Lila |
| Directivas de entrada | `~auto`, `~num`, `~str`, `~bool` | Cian |
| Conversiones | `num()`, `str()`, `bool()`, `array()`, `pack()`, `dict()`, `set()` | Verde |
| Literales | `none`, `true`, `false`, `inf` | Ámbar/Rosa |
| Modificadores | `pure`, `cache`, `trace`, `once`, `atomic`, `private`, `when`, `guard` | Dorado |
| Funciones/miembros | `.convert`, `.convert_keys`, `.convert_values`, `.keys`, `.values`, `.union`, `.with` | Azul |
| Lógicos | `and`, `or`, `not` | Naranja |
| Sintaxis vieja | `~for`, `~if`, `~orif`, `~else` | Rojo (obsoleta) |

**Importante:** `~num(...)` y `num(...)` son dos construcciones distintas. El `~` significa directiva de contrato de entrada, y la llamada sin `~` es el conversor UCS. Del mismo modo, `none` es un literal inmutable, no una función.

## Instalar

1. Desactiva o desinstala la extensión antigua para evitar asociaciones de lenguaje duplicadas.
2. VS Code → Extensiones → `...` → **Instalar desde VSIX...**.
3. Selecciona `YEK_Lenguaje_v1.2.0_H05B_Resaltado_Contextual.vsix` y recarga VS Code.
4. Abre un archivo `.yek`: VS Code debe mostrar **YEK** como lenguaje.
5. Si el explorador no presenta el icono con tu pack de iconos actual, usa **Preferences: File Icon Theme** → **YEK — iconos de archivos** (opcional; puede sustituir los iconos de otras extensiones por los genéricos).

### Ejecutar y verificar (arreglado en 1.1.1)

El botón **Ejecutar** y **Verificar** detecta el `Cargo.toml` del proyecto YEK desde cualquier subcarpeta del archivo `.yek`. El modo predeterminado `auto` utiliza `cargo run --quiet --manifest-path ... -- run/check archivo.yek` para **compilar el intérprete si es necesario** y ejecutar el archivo abierto. En Windows ya no intenta abrir un ejecutable inexistente llamado `yek` en la raíz del proyecto.

Requisitos: Cargo/Rust instalado y accesible desde la terminal de VS Code (`cargo --version`). Si ejecutas archivos fuera del proyecto YEK, puedes configurar la ruta absoluta del ejecutable generado. Si el ejecutable `yek` está instalado en el `PATH`, también se admite automáticamente fuera de un proyecto Cargo.

Opcional en `settings.json` para elegir un binario concreto:

```json
{ "yek.executablePath": "C:\\Proyecto\\target\\debug\\yek.exe" }
```

## Ejemplo

```yek
~code
valor = num("42")
ausente = none
if(valor > 40)
    "mayor que 40"!
orif(valor == 40)
    "igual"!
else
    "menor"!
for(i in 1..3)
    i!
~num(1..10)
entrada?
```


## Coloreado contextual nuevo (1.2.0, motor H05B)

- `~invalid` al comienzo de una línea inicia un **modo de descarte**: su cuerpo queda gris/cursiva como un comentario hasta la siguiente directiva oficial de modo (`~code`, `~text`, `~invalid`, `~math`, `~logic`). También se aplica al contenido inline después de `~invalid`. La directiva sigue morada.
- `~text` al comienzo de una línea inicia **texto raw**: el contenido se ve como texto (`#F2CF95`), sin reconocer `!`/`?` ni palabras clave, hasta la próxima directiva oficial de modo. La directiva sigue morada.
- En cadenas `"..."` **`!` y `?` usan exactamente los scopes** `keyword.operator.output.yek` y `keyword.operator.input.yek` que ya usaban fuera. Los fragmentos contiguos `x+1!`, `obj.campo!`, `a[0]+2!` y los agrupados `(x + 1)!`, `(~math 2+5)!` colorean sus partes con las categorías YEK. El operador escapado `\!`/`\?` es texto, no activo.
- `if(cond) "A" orif(cond) "B" else "C"` tiene coloreado de todas las ramas, con la misma regla que la forma multilínea.
- Añadido `.vlen`, ayuda para `none="nada"`, parámetros `f(x!)`, ejemplos y snippets para las nuevas construcciones.
- **Advertencia técnica:** TextMate es un coloreador estático; **no ejecuta el parser real**. La validación de expresiones, la precedencia y las restricciones de anidamiento siguen a cargo de YEK. Los modos raw siguen fronteras de directivas globales; las capturas raw con alcance basado en indentación pueden requerir refinamientos para colorear exactamente sus límites.

## Limitaciones

Esta extensión no compila el lenguaje, no incluye el ejecutable YEK ni implementa un servidor de lenguaje (LSP). El resaltado está basado en patrones TextMate; identifica vocabulario sintáctico, pero no puede garantizar semánticamente que cada método y palabra esté en un contexto válido. Los colores exactos pueden variar al sobrescribir ajustes o por otros temas. **No se han ejecutado tests de integración con la aplicación VS Code en este entorno.**

> En la configuración predeterminada no necesitas fijar `yek.executablePath`: su valor es `auto`. Si habías escrito una ruta incorrecta, elimínala o cámbiala a `auto`.


## H06 — Contratos de entrada unificados

```yek
~in(num.int=[1,4..6,100], len=1..5, att=2)
numero?
~in(str=[a..z,"si"], len=2..5)
nombre?
~in(bool.num)
activo?
```

El coloreado ahora incluye `~in`, selectores, `len`, `att`, `msg`, `warning`, `error` y la flecha de reserva `->`. Las directivas antiguas se siguen coloreando por compatibilidad, pero se recomienda usar `~in`.
