# YEK v0.0.8.8 — Hotfix 1: expectativas de exportaciones duplicadas

## Causa
La prueba histórica `duplicate_exports_and_aliases_are_rejected` esperaba la subcadena `duplicate export` pero el contrato v0.0.8.8 emite `duplicate public export`. La detección del error es correcta: se rechazó el mismo nombre público dos veces.

## Corrección
Archivo `tests/modulos_v0086_tests.rs`: actualizar el texto esperado a `duplicate public export` y adjuntar el diagnóstico real en caso de fallo. No se cambia el lexer, parser, módulos, intérprete, biblioteca estándar ni la semántica de YEK.

## Verificación en Windows
```powershell
cargo test --test modulos_v0086_tests -- --nocapture
cargo test --test modulos_v0088_etapa1_tests -- --nocapture
cargo test
cargo check
```

Si surge otro fallo, compartir la primera sección `failures:` completa: cada prueba se analizará según el contrato v0.0.8.8 antes de modificar el motor.

Esta entrega está verificada estáticamente, pero no compilada en este entorno (no hay Cargo instalado).
