# YEK v0.0.9.2 · H05 — if / orif / else inline

Base: H04C completo, sin modificar la semántica de Bool ni el intérprete.

## Nueva regla

Una instrucción por rama inline, con palabras clave estructurales separadas por espacios.

```yek
~code
if(false) "NO" else "SI"
if(false) "A" orif(true) "B" else "C"
x=5
if(x>3) x+10! else x!
```

Se reconocen `orif` y `else` únicamente al nivel superior (no dentro de comillas ni de `()`, `[]` o `{}`). Los comentarios al final de línea se mantienen. Se requiere una condición Bool. Cada rama inline completa contiene exactamente una instrucción; no se permiten continuaciones indentadas ni controles anidados sin delimitación por indentación.

### Compatibilidad

La sintaxis multilínea existente y la forma antigua `if(true) "SI"` permanecen intactas. Si necesitas condicionales anidados, escribe cada uno en su bloque indentado. Los cuerpos de varias instrucciones también usan indentación.

## Pruebas añadidas

- 45 pruebas Rust de éxito y 19 negativas (64 en total).
- 64 ejemplos `.yek` con manifiesto, checklist y ejecutor en `EJEMPLOS_H05_IF_INLINE`.

```powershell
cargo build
cargo test --test etapa5_h05_inline_if_orif_else_tests
cargo test
py -3 EJEMPLOS_H05_IF_INLINE\ejecutar_h05.py
```

El script no modifica archivos originales de motor. Guarda los resultados en `EJEMPLOS_H05_IF_INLINE/RESULTADOS_H05`.

## Validación

La integridad del ZIP, las diferencias de fuentes y la sintaxis de Python se han comprobado estáticamente. **Cargo no está instalado en el entorno de preparación**, así que es imprescindible ejecutar las pruebas en Windows antes de aprobar H05. No se garantiza que todas las pruebas pasen sin esa validación.
