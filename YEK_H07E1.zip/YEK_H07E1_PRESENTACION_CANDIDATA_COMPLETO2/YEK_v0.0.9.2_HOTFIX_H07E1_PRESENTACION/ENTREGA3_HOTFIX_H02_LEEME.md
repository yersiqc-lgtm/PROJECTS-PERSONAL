# YEK v0.0.9.1 — Entrega 3 HOTFIX H02

Base: **Entrega 3 HOTFIX H01 (E0382)**. Este hotfix corrige exclusivamente tres fallos confirmados de la batería `objetos_avanzados_entrega3_tests`.

## Cambios funcionales

1. `Struct.validate` y `Struct.rows` (sin y con `()`) se despachan mediante el mecanismo ya existente de métodos de receptor. El acceso a campos y métodos con igual nombre conserva prioridad. Se mantiene la protección de `~struct(private)` para `rows`.
2. `copia = tarea`, cuando `tarea` es un bloque operativo `~block`, copia el valor invocable sin ejecutarlo. Conserva el identificador de acción (`uid`), de manera que `~block(once)` ejecuta el cuerpo una sola vez también a través de las copias. Las funciones ordinarias `~code`, así como `tarea!` y el sistema histórico de referencias, no se han redefinido.
3. Se agregan diez pruebas de regresión en `tests/objetos_avanzados_hotfix_h02_tests.rs`.

## Validar en PowerShell dentro de la carpeta de Cargo.toml

```powershell
cargo check --all-targets
cargo test --test objetos_avanzados_hotfix_h02_tests -- --nocapture
cargo test --test objetos_avanzados_entrega3_tests -- --nocapture
cargo test --all-targets
```

Resultado objetivo para la suite original de Entrega 3: **48 passed; 0 failed; 2 ignored**. Las 10 pruebas nuevas deben pasar. La compilación y la ejecución **no** se han podido confirmar aquí: Rust/Cargo no están disponibles en este entorno.

## Compatibilidad

No se han cambiado el análisis léxico, el parser, los módulos, Logic, Math, Array o ValuePack. Este ZIP se mantiene como **candidato** hasta validar todas las suites en tu equipo.
