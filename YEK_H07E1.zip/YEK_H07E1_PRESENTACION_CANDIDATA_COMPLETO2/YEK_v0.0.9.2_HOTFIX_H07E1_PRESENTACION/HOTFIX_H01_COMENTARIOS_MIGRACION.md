# YEK — Hotfix H01: comentarios tras migración de `~for` a `for`

## Problema reproducido por el usuario

Al ejecutar `cargo test`, la suite `arrow_break_nested_regression_tests` falló en
`comentario_que_menciona_for_no_crea_un_productor` con:

```text
1:18: standalone expressions must end with '!' or be callable statements
```

## Causa confirmada (comparación con el ZIP original)

El ejemplo original `a=42 ~for(100)->99` era **un comentario en línea**, no un generador.
La migración textual eliminó `~` y lo transformó erróneamente en
`a=42 for(100)->99`. Al conservarse como código activo, el parser genera un error.

## Cambios realizados

1. `tests/arrow_break_nested_regression_tests.rs`: sustituye la cadena migrada por
   `a=42 ~ comentario: for(100)->99`, manteniendo el resultado esperado `42`.
2. `qa_exhaustiva/casos/modos_comentario_for.yek`: corrige el mismo problema en
   el fixture de QA, manteniendo el archivo esperado `42`.
3. `INVENTARIO_ARCHIVOS_YEK_SHA256.csv`: recalcula las huellas de los dos archivos modificados.

No se modificó el motor, el parser, el lexer ni las características del lenguaje.
`for`, `if`, `orif`, `else` siguen sin `~` cuando son código real.
El prefijo `~` sigue siendo válido para introducir comentarios.

## Validación

- Confirmación de la causa por comparación entre el archivo fuente Rust original
  y la versión migrada.
- Auditoría de otros tests de comentarios después de cabeceras de control: los
  casos revisados preservan el prefijo `~`.
- Validación estructural y de referencias con `python tools/VERIFICAR_MIGRACION_YEK.py`.
- Integridad ZIP verificada.
- **Pendiente**: ejecutar el test Rust en la computadora del usuario, porque el
  entorno actual no tiene `cargo` / `rustc`.

Desde la raíz del proyecto:

```sh
cargo test --test arrow_break_nested_regression_tests
cargo test --test qa_exhaustiva_fixtures_tests caso_modos_comentario_for
cargo test
```

El VSIX YEK v1.1.0 **no necesita modificaciones** para este error.
