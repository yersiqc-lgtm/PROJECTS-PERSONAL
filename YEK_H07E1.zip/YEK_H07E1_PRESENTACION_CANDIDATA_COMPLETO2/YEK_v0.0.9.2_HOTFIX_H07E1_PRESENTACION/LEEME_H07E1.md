# H07E1 — Incremento de presentación (candidato, NO compilado)

Base: H07E0. Implementado: `.style(box="single|double|round")`, `.style(bar=true,width=...)` para **porcentajes textuales**, `.style(color="red")`, `.style(bold=true)` en salidas de literales activos.

**Limitaciones explícitas:** no es el sistema completo de `style`; no admite todavía ValuePack identificados/vivos, `out.style` global, tablas, posicionamiento, entrada avanzada ni cálculo de ancho visual Unicode. El cuadro mide escalares; por tanto, puede desalinearse con emoji o caracteres de ancho doble. Los colores ANSI son explícitos y algunos terminales/redirecciones muestran secuencias de escape. No usar sobre datos sensibles.

No se modificó la semántica de ValuePack, contratos, mapas, bucles o funciones. Estos métodos solo funcionan en sentencias de cadena `.style(...)`, no en valores arbitrarios.

## Verificación Windows
```
cargo build
cargo test --test h07e1_presentacion_tests
cargo test
```

Sin Rust/Cargo en el entorno de creación, la compilación y las regresiones requieren ejecución real en Windows. **No instalar sobre el proyecto estable sin respaldo.**
