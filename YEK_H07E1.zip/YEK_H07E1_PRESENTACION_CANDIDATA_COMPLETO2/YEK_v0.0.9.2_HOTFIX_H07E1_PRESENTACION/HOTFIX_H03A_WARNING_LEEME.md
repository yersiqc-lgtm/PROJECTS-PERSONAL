# YEK 0.0.9.2 H03A — Limpieza del warning dead_code

## Causa

En `src/source.rs`, `exact_directive` solo se utiliza desde el módulo unitario `#[cfg(test)]`. La lógica real de reconocimiento de modos usa `mode_directive_header`.

## Cambio mínimo

Se añadió `#[cfg(test)]` inmediatamente antes de `fn exact_directive(...)`.
Esto evita que se incluya en el build normal pero conserva la prueba unitaria actual. Sin cambios en la semántica de YEK.

## Verificar en Windows

```powershell
cargo build
cargo test
```

Estado: comprobación estructural del parche superada. Cargo no está disponible en este entorno, de modo que la ausencia del warning en una compilación real debe comprobarse en Windows.
