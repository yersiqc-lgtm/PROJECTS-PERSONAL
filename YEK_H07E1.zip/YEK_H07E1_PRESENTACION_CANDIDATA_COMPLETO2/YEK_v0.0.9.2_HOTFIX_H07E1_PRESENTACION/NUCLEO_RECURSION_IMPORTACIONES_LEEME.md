# YEK — Cierre de semántica avanzada (candidata)

**Base:** v0.0.9.1 Entrega 3 HOTFIX H03, con todos sus archivos y suites históricas intactos.  
**Estado:** candidato experimental; **no ha sido compilado con Cargo en el entorno de preparación**. No sustituir H03 validado sin ejecutar las pruebas.

## Mejoras incluidas

1. `a=Cuenta` construye una Class o Struct sin argumentos explícitos. Requiere parámetros predeterminados para todos los campos obligatorios; equivale a `a=Cuenta()`. Para **conservar el constructor** sin ejecutar: `f=Cuenta!`. Los datos `a=x` y `a=x!` conservan sus reglas anteriores.
2. Recursividad léxica por declaración anticipada de nombres **del mismo ámbito**, directa y mutua. Un nombre adelantado utilizado antes de su inicialización provoca error, no devuelve el marcador reservado. Los nombres de métodos también se reservan antes de cerrar sus capturas. La autorreferencia directa mantiene la identidad del Code aunque cambie la variable externa.
3. Recursividad mediante `~block`, con límite conservador de 20 llamadas Code activas y rechazo de reentrada de `~block(once)` durante su primera ejecución. `once` conserva el estado compartido entre aliases.
4. Recursividad multirresultado: las llamadas de ramas diferentes se expanden con las reglas `->` y `a,b=...` históricas; no se introduce retroceso de Prolog en `~code`.
5. `~code(pure,cache)` admite **solo autorrecursión directa verificada** y cuerpos de control `if` con retornos puros. **No** valida todavía recursividad mutua pura ni llamadas transitivas a otras funciones. La implementación de caché preexistente conserva su contrato de argumentos inmutables.
6. `~import "archivo.yek".*` selecciona todos los símbolos publicados como nombres locales; `as alias` agrupa en `alias.nombre` y `without nombre` elimina seleccionados. Acepta exclusiones por artículo dentro de `~import(...)`.
7. `~import "archivo.yek".zona.*` selecciona solamente **espacios de nombres públicos realmente exportados**. No hace reflexión arbitraria sobre funciones, clases u objetos; un prefijo sin namespace válido se rechaza.
8. `~export * without x` conserva el modo público automático exceptuando x. `~export * without Tipo.metodo` aplica un filtro de interfaz al constructor **exportado**, no altera el constructor retenido por el módulo de origen. Alias públicos al mismo constructor reciben el mismo filtro.
9. `~export * without modulo.privado` permite excluir nombres cualificados y namespaces enteros mediante `modulo.*`.
10. `~export * without campo` dentro de un tipo limita su API a los campos/métodos restantes. `without` es **contextual**, no un operador general ni una reserva global de identificadores.
11. `~import math.*` y `~import str.*` admiten la expansión pública de los módulos de biblioteca actuales.

## Límites explícitos de seguridad / estabilidad

- Un `~export * without Tipo.metodo` protege las instancias creadas por la **interfaz exportada del constructor**. No constituye un sandbox de seguridad ni impide que una función exportada por separado devuelva una instancia creada por otra ruta interna. Un control de acceso transitivo sobre objetos ya construidos requerirá una representación de vistas públicas con procedencia de módulo; no debe declararse garantizado hasta implementarlo y probarlo.
- Los alias `as` de `~import "archivo.yek".* as alias` son namespaces, no renombres automáticos de cada elemento individual. Para un símbolo concreto, mantén `~import "archivo.yek".nombre as otro`.
- `for`, Logic, Math, referencias y ValuePacks no cambian de gramática en esta candidata. No se modifica su motor para simular recursividad de Prolog.
- La profundidad se limita a 20 llamadas Code activas (contadas independientemente de marcos temporales o de módulo), porque los evaluadores anidados consumen pila nativa y las pruebas de Windows pueden desbordarse antes de 128. Este límite prudente reduce el riesgo, pero **no constituye una garantía general ante todas las entradas y plataformas**; para recursión profunda se necesitará un evaluador con pila explícita o técnicas de eliminación de llamadas de cola.
- Esta candidata incluye diagnósticos de importaciones, colisiones y nombres anticipados, pero necesita auditoría dinámica, fuzzing, pruebas en Windows y revisión de regresiones antes de estabilizarse.

## Comprobación Windows

Desde la raíz donde está `Cargo.toml`:

```powershell
cargo check --all-targets
cargo test --test nucleo_recursion_importacion_v0091_tests -- --nocapture
cargo test --all-targets
```

Automatizado:

```powershell
.\VERIFICAR_NUCLEO_RECURSION.ps1
```

Casos individuales (ejecuta desde la raíz):

```powershell
cargo run -- run EJEMPLOS_NUCLEO_RECURSION/03_factorial.yek
cargo run -- run EJEMPLOS_MODULOS_UNIVERSALES/main.yek
```

Nota: si tu CLI utiliza `yek run`, el binario se llama `yek` después de `cargo build`.

## Seguimiento

- Ejecutar **todas** las suites históricas, incluidas QA 161 activas y las 48 exploratorias.
- Revisar la seguridad de todos los caminos de instanciación/exportación profunda antes de prometer encapsulación transmodular completa.
- Tras estabilizar esta entrega, avanzar a indexación, Map/Set, None y errores recuperables.
