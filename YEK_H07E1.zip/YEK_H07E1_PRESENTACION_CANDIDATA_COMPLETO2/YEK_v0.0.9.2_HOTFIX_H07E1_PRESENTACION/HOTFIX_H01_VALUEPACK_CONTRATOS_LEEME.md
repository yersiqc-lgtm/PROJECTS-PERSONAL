# HOTFIX H01 — ValuePack / ContractPack (v0.0.9.2 Etapa A)

## Error encontrado

En `p=(1,(2,3),[4])`, el detector antiguo trataba `[4]` como una
especificación de longitud de un contrato de entrada y convertía **toda**
la asignación en `ContractPack`. Por eso `p[0]` producía el error
`indexing is not supported for contract pack`.

## Criterio de compatibilidad

- Un corchete que contenga únicamente un entero, como `[4]`, es un Array
  ordinario si no hay otra marca de contrato en el mismo conjunto.
- Las sintaxis específicamente contractuales, como `a..z`,
  `[2..4]` o `<attempts=...>`, mantienen la ruta `ContractPack`.
- Si un contrato mezcla `a..z` y `[4]`, el `[4]` se sigue interpretando
  dentro del contrato como longitud y no como elemento de Array.
- La forma aislada `rules=([4])` es ambigua con un Array normal. Se prioriza
  el código ordinario; para contratos de longitud aislada usar la
  especificación de longitud directamente en la directiva de entrada.

No se ha cambiado el motor de indexación: la solución corrige la
clasificación *antes* de evaluar, reutilizando toda la semántica
existente de Array, ValuePack y contratos de entrada.

## Verificación en Windows

Desde la carpeta que contiene `Cargo.toml`:

```powershell
cargo check --all-targets
cargo test --test colecciones_universales_v0092_etapa_a_tests -- --test-threads=1 --nocapture
cargo test --test contract_pack_disambiguation_tests -- --nocapture
cargo test --all-targets
```

El paquete conserva las pruebas anteriores y añade seis casos de
regresión de integración, además de una prueba del clasificador.

**Pendiente de validar con Cargo en Windows.**
