# YEK H06F — Rangos Unicode universales

Casos independientes de QA. Se incluye el mismo número de pruebas Rust en `tests/etapa6_h06f_rangos_unicode_tests.rs`.

Desde la raíz del proyecto:

```powershell
cargo build
cargo test --test etapa6_h06f_rangos_unicode_tests
cargo test
py -3 EJEMPLOS_H06F_RANGOS_UNICODE\ejecutar_h06f.py --auditar
py -3 EJEMPLOS_H06F_RANGOS_UNICODE\ejecutar_h06f.py
```

La sintaxis `a..d` genera literales Text Unicode; `(a)..(d)` evalúa variables y `a!..d!` usa referencias. Los límites de los rangos numéricos continúan funcionando como antes. La expansión está limitada a 200000 valores.

Las pruebas no han sido ejecutadas con Cargo en el entorno de preparación: deben validarse en Windows.
