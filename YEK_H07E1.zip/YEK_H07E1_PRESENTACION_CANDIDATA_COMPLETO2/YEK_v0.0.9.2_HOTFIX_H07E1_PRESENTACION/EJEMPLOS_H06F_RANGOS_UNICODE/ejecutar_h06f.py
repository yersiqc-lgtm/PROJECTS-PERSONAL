#!/usr/bin/env python3
"""Tests a real compiled YEK binary against H06F fixtures, never a mock."""
import argparse, hashlib, json, pathlib, subprocess, csv, sys, time
ROOT=pathlib.Path(__file__).resolve().parent
PARSER=argparse.ArgumentParser()
PARSER.add_argument('--proyecto', type=pathlib.Path)
PARSER.add_argument('--sin-build', action='store_true')
PARSER.add_argument('--auditar', action='store_true')
PARSER.add_argument('--desde', type=int, default=1)
PARSER.add_argument('--hasta', type=int, default=999)
PARSER.add_argument('--timeout', type=float, default=8.0)

def main():
 a=PARSER.parse_args()
 items=json.loads((ROOT/'MANIFIESTO.json').read_text(encoding='utf-8'))
 for case in items:
  path=ROOT/case['ruta']
  assert path.is_file(),f'Missing: {path}'
  assert hashlib.sha256(path.read_bytes()).hexdigest()==case['sha256'],f'Altered: {path}'
 print(f'Auditoria de integridad OK: {len(items)} programas')
 if a.auditar:return 0
 project=a.proyecto or ROOT.parent
 while not (project/'Cargo.toml').is_file() and project.parent!=project:
  project=project.parent
 if not (project/'Cargo.toml').is_file():
  print('No se encontro Cargo.toml; usa --proyecto RUTA_YEK',file=sys.stderr);return 2
 if not a.sin_build:
  print('Compilando YEK...')
  out=subprocess.run(['cargo','build','--quiet'],cwd=project)
  if out.returncode:return out.returncode
 binary=project/'target'/'debug'/('yek.exe' if sys.platform=='win32' else 'yek')
 if not binary.is_file():
  print(f'Falta binario: {binary}',file=sys.stderr);return 2
 rows=[]
 for case in items:
  n=int(case['id'].split('-')[-1])
  if not(a.desde<=n<=a.hasta):continue
  try:
   result=subprocess.run([str(binary),'run',str(ROOT/case['ruta'])],cwd=project,
    input=('\n'.join(case['stdin'])+'\n' if case['stdin'] else '').encode('utf-8'),
    stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=a.timeout)
   stdout=result.stdout.decode('utf-8','replace').replace('\r\n','\n').splitlines()
   stderr=result.stderr.decode('utf-8','replace')
   if case['tipo']=='OK':
    ok=result.returncode==0 and stdout==case['stdout']
    detail=f'Esperado: {case["stdout"]!r}; recibido: {stdout!r}; stderr: {stderr[:450]!r}'
   else:
    ok=result.returncode!=0 and case['error_contiene'] in stderr+ '\n' +'\n'.join(stdout)
    detail=f'Esperado error: {case["error_contiene"]!r}; rc: {result.returncode}; stderr: {stderr[:700]!r}'
   state='OK' if ok else 'FALLO'
  except subprocess.TimeoutExpired:
   state='TIMEOUT';detail='Se agoto el tiempo maximo de la prueba.'
  rows.append([case['id'],case['titulo'],case['tipo'],state,detail]); print(case['id'],state)
 output=ROOT/'RESULTADOS_H06F';output.mkdir(exist_ok=True)
 with (output/'resultados.csv').open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.writer(f);w.writerow(['id','titulo','tipo','estado','detalle']);w.writerows(rows)
 report='H06F: '+str(len(rows))+' programas\n'+str(sum(r[3]=='OK' for r in rows))+' correctos; '+str(sum(r[3]!='OK' for r in rows))+' fallos.\n\n'
 report+='\n\n'.join(f'{r[0]} {r[1]} [{r[3]}]\n{r[4]}' for r in rows if r[3]!='OK') or 'Sin fallos.'
 (output/'REPORTE_PARA_CHATGPT.txt').write_text(report,encoding='utf-8')
 print(f'Informe: {output/"REPORTE_PARA_CHATGPT.txt"}')
 return int(any(r[3]!='OK' for r in rows))
if __name__=='__main__':raise SystemExit(main())
