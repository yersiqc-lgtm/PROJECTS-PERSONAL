# YEK H07A — Diagnósticos de productores y limpieza de warning

**Base:** YEK H07 Iteración Universal.

## Motivo

`a=[for(x=1..2)->x,]` es inválido, pero la capa de compatibilidad
ForAssign descartaba el error detallado del parser y devolvía el mensaje
engañoso `'for' expects '(...)' or no header`.

H07A conserva el error específico `producer expects a result expression`
cuando el parser detecta un productor incompleto. También impide una coma
doble o un `->` sin resultado. Los productores múltiples válidos permanecen
idénticos, y un Array ordinario `[1,2,]` sigue admitiendo coma final.

Se elimina además el warning Rust `unused variable: end` de
`src/interpreter/mod.rs` sin alterar ninguna expresión de rango.

## Archivos modificados

- `src/source.rs`: no ocultar diagnósticos de productor tras el fallback legacy.
- `src/parser/mod.rs`: validar coma doble y expresión ausente tras `->`.
- `src/interpreter/mod.rs`: omitir en el patrón el extremo `end` no utilizado.
- `tests/etapa7_h07_universal_tests.rs`: 44 pruebas originales + 4 regresiones.

## Comprobación en Windows (PowerShell)

```powershell
cargo build
cargo test --test etapa7_h07_universal_tests
cargo test
```

Esperado en la suite específica: **48 aprobadas, 0 fallidas**.

El laboratorio de H07 y la extensión VS Code v1.3.2 siguen incluidos sin
cambios. El ZIP de parche se aplica sobre H07; reemplazar archivos
conservando las rutas desde la raíz del proyecto (donde está Cargo.toml).

**Nota de validación:** Se verificaron la integridad del ZIP y las diferencias
de archivos contra H07. No se pudo ejecutar Cargo en este entorno.
