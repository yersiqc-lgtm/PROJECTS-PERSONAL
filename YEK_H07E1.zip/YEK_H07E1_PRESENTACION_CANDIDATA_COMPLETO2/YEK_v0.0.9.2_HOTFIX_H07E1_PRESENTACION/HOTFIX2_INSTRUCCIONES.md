# YEK v0.0.8.4 — Hotfix 2 de pruebas QA obsoletas

## Causa del fallo reportado

El caso antiguo `E04_pack_como_numero.yek` contenía:

```yek
a=(for(x=1..3)) * 2
a!
```

Este programa **ya es válido** desde que se definió la repetición plana
para ValuePack. El intérprete devolvió correctamente:

```text
(1, 2, 3, 1, 2, 3)
```

El error se encontraba en la prueba negativa, que esperaba una excepción.
No se ha cambiado el motor, lexer, parser, AST ni los operadores.

## Correcciones en QA

- Se conserva el código anterior como `qa_realista/casos/25_pack_repeticion_plana.yek`,
  con resultado exacto en `qa_realista/esperados/25_pack_repeticion_plana.txt`.
- El caso `E04_pack_como_numero.yek` ahora prueba `3*(1,2)`, operación inversa
  NO definida en el contrato actual; debe informar `numeric operands`.
- `E09_repeticion_pack_tipo_invalido.yek` prueba que `(1,2)*[3]` genera
  `requires a nonnegative integer repetition count`.
- El archivo `tests/qa_realista_tests.rs` y el manifest reflejan ambas
  categorías sin marcar una operación válida como inválida.

## Verificación en PowerShell

Desde la carpeta que contiene `Cargo.toml`:

```powershell
cargo test --test qa_realista_tests -- --nocapture
cargo test --test operadores_polimorficos_tests -- --nocapture
cargo test
cargo check
```

La prueba de estrés ignorada continúa desactivada intencionalmente.

**Verificación:** el usuario confirmó mediante Cargo que la versión Hotfix 1
compila y que todas las demás pruebas de la suite reportada pasaron. El
Hotfix 2 no ha podido compilarse en este entorno (no dispone de cargo/rustc).
Los resultados de las dos nuevas pruebas deben confirmarse en el equipo del usuario.
