# YEK H06B — Corrección de 39 errores E0277 en tests Rust

## Causa
El archivo `tests/etapa6_h06_migracion_unificada_tests.rs` comparaba un `Vec<String>` con `&Vec<String>` en 39 aserciones. Rust rechaza esas comparaciones con `error[E0277]`.

## Reparación
Se retiró únicamente el operador de préstamo `&` de los vectores esperados en las 39 llamadas `assert_eq!(output, &[...].iter()...)`.

Antes:
```rust
assert_eq!(output, &["5"].iter().map(|x| x.to_string()).collect::<Vec<String>>());
```
Después:
```rust
assert_eq!(output, ["5"].iter().map(|x| x.to_string()).collect::<Vec<String>>());
```

No se modificó ningún archivo de `src/`, ninguna prueba fuera de este archivo ni la semántica de YEK, sus rangos, ValuePack o `~in(...)`.

## Aplicar parche
Extraer `YEK_H06B_SOLO_PRUEBA_CORREGIDA.zip` en la raíz H06A, sustituyendo `tests/etapa6_h06_migracion_unificada_tests.rs`.

## Verificar en Windows
```powershell
cargo build
cargo test --test etapa6_h06a_rangos_explicitos_tests
cargo test --test etapa6_h06_migracion_unificada_tests
cargo test
```

### Limitaciones
La integridad del ZIP, los cambios y la estructura de las aserciones fueron verificados estáticamente. En el entorno de creación no se dispone de `cargo` ni de `rustc`; no se certifica la compilación ni la ejecución de las pruebas.
