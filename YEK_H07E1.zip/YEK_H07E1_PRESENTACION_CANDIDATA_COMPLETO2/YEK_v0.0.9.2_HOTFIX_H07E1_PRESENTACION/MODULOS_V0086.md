# YEK v0.0.8.6 — Primera entrega de ~import y ~export

## Objetivo

Primera fase: módulos `.yek` con ámbito privado, rutas relativas al módulo importador, alias, exportación explícita y errores de dependencias circulares. La arquitectura usa un **grafo de módulos** cargado antes de ejecutar el programa; **no concatena el texto fuente**. Se preservan las funciones y referencias internas capturadas por Code.

## Sintaxis soportada en esta entrega

Con alias explícito:

```yek
~import "lib/utils.yek" as utils
```

O, alternativamente, con alias por defecto (el nombre de archivo `utils`):

```yek
~import "lib/utils.yek"
```

Utiliza **una de las dos variantes** para ese mismo nombre en un archivo. También se admiten rutas relativas con espacios.

En el archivo `lib/utils.yek`:

```yek
factor=2
double(x)=~code -> x*factor
private=123
~export double
```

En `main.yek`:

```yek
~import "lib/utils.yek" as util
util.double(7)!
```

Salida esperada: `14`.

Puede declarar varias exportaciones: `~export double, triple`.

## Reglas precisas

1. Los módulos utilizan **ámbitos separados**; solo se accede a nombres en `~export`.
2. Se usa `alias.nombre`; las exportaciones calificadas son **solo lectura** desde el importador.
3. Las funciones exportadas conservan sus capturas del ámbito interno.
4. Cada archivo importado se evalúa una sola vez por ejecución; un segundo alias usa la misma instancia de módulo. **La carga inicial sí ejecuta sus instrucciones de nivel superior**. Solo importes archivos `.yek` de confianza.
5. Los imports se resuelven con respecto a la ubicación del archivo que importa, no el directorio de PowerShell.
6. Las dependencias circulares se rechazan antes de ejecutar la entrada e incluyen el recorrido de archivos.
7. `~import` y `~export` se escriben al nivel superior del archivo, en modo `~code`. Dentro de `~text` y `~invalid` son contenido inerte.
8. `yek check main.yek` analiza el grafo y sus sintaxis, pero **no ejecuta inicializadores**, por lo que nombres exportados que nunca llegan a definirse se informan en tiempo de ejecución.
9. En `run_source()` sin una ruta de archivo, `~import` se rechaza con un mensaje. Usa el CLI `yek run main.yek` o la API `compile_file(path)` y luego `Interpreter::new().run(...)`.
10. Los comentarios y las advertencias del archivo principal se conservan. Esta primera implementación no agrega advertencias de módulos secundarios al listado del CLI.

## Fuera de alcance de v0.0.8.6 (errores explícitos)

- `~import math` (módulo estándar sin ruta): pendiente.
- `~import "archivo.txt"` (importación de datos): pendiente.
- `~import(math, "x.yek")` (listas de importación): pendiente.
- `~import str.len` (importación selectiva): pendiente.
- Reexportación de namespaces, inicialización cíclica o mutación desde fuera del namespace: pendientes/no admitidas.
- Resolución de paquetes de Internet: no implementada ni buscada.

## Comandos Windows

En la raíz del proyecto, que contiene `Cargo.toml`:

```powershell
cargo check
cargo test --test modulos_v0086_tests -- --nocapture
cargo test
cargo run -- check ejemplos/modulos_v0086/main.yek
cargo run -- run ejemplos/modulos_v0086/main.yek
```

Alternativamente, ejecuta `VERIFICAR_MODULOS.cmd`.

## Alcance de seguridad y limitaciones

Los imports leen archivos locales elegidos en el código y ejecutan su nivel superior al inicializarse. No son un *sandbox*; no importes código de origen desconocido. El primer backend conserva sus reglas de memoria existentes y todavía no es un sistema de paquetes compilados. No se han añadido APIs de lectura de datos externos.

## Validación

Este paquete contiene pruebas Rust de módulos y las pruebas históricas. Fue preparado con análisis estático, pero la compilación/evaluación de Rust **necesita ejecutarse en Windows con Cargo** para confirmar el candidato.
