# YEK 0.0.9.2 — Hotfix H03C · `.vlen`

## Alcance

La Etapa 3 se considera aprobada por el usuario. Este hotfix incorpora la mejora adicional de **longitud visual** sin alterar la semántica anterior de `.len`.

Se utiliza `unicode-segmentation = "1.12"`, que implementa los límites de grafemas Unicode extendidos (UAX #29). `graphemes(true).count()` cuenta unidades aproximadas a caracteres percibidos, independientemente de cuántos puntos de código las componen.

## Sintaxis

```yek
~code
a="é"
a.len!      ~ 2 puntos de código
a.vlen!     ~ 1 grafema Unicode

b="🇵🇪"
b.vlen!     ~ 1

~import str
str.vlen(b)! ~ 1
```

**Importante:** la línea de comentario `~` es solo informativa; no forma parte del código que se debe copiar dentro de cadenas.

## Compatibilidad

- `.len` y `str.len(text)` conservan el conteo previo de escalares Unicode.
- La indexación, slicing, iteración, `.count` y otras colecciones siguen con sus reglas previas.
- `.vlen` solamente se aplica a `String` (`Value::Text`). No modifica `Array`, `Set`, `Map` ni `ValuePack`.
- `.vlen` y `str.vlen(text)` devuelven un número entero no negativo.
- La importación nativa `~import str`, `~import str.vlen as visual` y `~import str.* as alias` expone el método nuevo; también aparece en el análisis estático de exportaciones.
- `.vlen` es una función nueva: **ningún archivo existente debe cambiar de resultado por su incorporación**.
- La segmentación Unicode no es igual a anchura de terminal, ni garantiza cuántos símbolos muestra una fuente o dispositivo.

## Pruebas

Desde la carpeta que contiene Cargo.toml:

```powershell
cargo build
cargo test --test vlen_unicode_graphemes_h03c_tests
cargo test
```

Se incluyen 39 regresiones Rust nuevas y 16 ejemplos `.yek` independientes con sus respectivas salidas esperadas.

## Validación y estado

Los cambios han recibido comprobación estática y el ZIP se verifica con CRC/SHA-256. El entorno de creación de este paquete **no tiene Cargo ni Rust**, por lo que no se ha compilado aquí. El cierre funcional definitivo de H03C requiere ejecutar los comandos anteriores en Windows y comprobar que todos pasan.
