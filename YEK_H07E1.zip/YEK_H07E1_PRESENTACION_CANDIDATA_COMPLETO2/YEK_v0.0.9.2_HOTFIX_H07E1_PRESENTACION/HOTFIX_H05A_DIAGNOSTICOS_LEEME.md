# YEK v0.0.9.2 — Hotfix H05A: diagnósticos de condicionales inline

## Causa de las dos pruebas fallidas

- `if(true) else "B"` no tiene cuerpo entre `if` y `else`.
  El separador de la cabecera ya había eliminado el espacio inicial de la
  parte inline, y el detector de ramas no reconocía `else` en la posición 0.
  Devolvía un error genérico del parser de expresiones. Ahora devuelve un
  error específico: `inline 'if' requires a body before 'orif' or 'else'`.
- `if(true) "A" else "B"` seguido de `else "C"` contiene un `else`
  huérfano. Antes mostraba `else does not accept a condition or arguments`,
  aunque el contenido inline es sintácticamente válido. Ahora indica
  `else must follow a matching 'if' at the same indentation`.

## Alcance exacto

- Cambiado: `src/source.rs` en dos puntos de diagnóstico.
- Actualizado: `tests/etapa5_h05_inline_if_orif_else_tests.rs`, con cuatro
  regresiones adicionales (64 → 68 pruebas específicas).
- Sin cambios: AST, intérprete, semántica Bool, ramas inline válidas,
  comentarios, módulos, colecciones y referencias.

## Validación en Windows

```powershell
cargo build
cargo test --test etapa5_h05_inline_if_orif_else_tests
cargo test
```

Las comprobaciones estáticas no sustituyen la compilación con Cargo.
