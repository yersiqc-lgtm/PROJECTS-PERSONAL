# YEK: motor de composición de productores (candidato v0.0.8.3)

## Estado verificable

Este paquete contiene cambios efectivos en `src/`, no solo ejemplos ni archivos de prueba. **No se ha ejecutado `cargo test` contra los cambios**: el entorno en el que se preparó el paquete no dispone de `rustc` ni de `cargo`, y no tiene salida a Internet para instalarlos. La única comprobación automatizada realizada aquí fue el oráculo Python de las expectativas del contrato (21 de 21 coherentes); esa comprobación **no ejecuta el motor Rust**. Antes de usar esta versión como estable, ejecutar `VERIFY_COMPOSICION.ps1` en un equipo con Rust.

## Arquitectura general implementada

1. El lexer reconoce `for` y `if` dentro de una expresión ordinaria.
2. El AST contiene `Expr::Producer { header, body, guard }`. Un productor es una expresión que produce entre cero y N valores; no se hace pasar una secuencia desnuda por un `ValuePack`.
3. El parser analiza `for(header)` recursivamente dentro de Arrays, ValuePacks, argumentos, asignaciones y otros productores. Reutiliza el analizador de encabezados `for` previo, evitando dos contratos de iteración incompatibles.
4. El ejecutor de `Expr::Producer` utiliza directamente `run_for_engine`, el mismo motor responsable de rangos, saltos, variables locales, sincronización e iteración por referencia. Construye un cuerpo de retorno por iteración, y un filtro `if` local cuando corresponde.
5. `eval_values` es la representación interna común de los valores sueltos; al entrar a un Array los inserta consecutivamente, al entrar a un Pack también, y los contenedores internos ya materializados permanecen como una única unidad.
6. Los retornos y argumentos de Code pueden recibir expresiones productoras. Las operaciones aritméticas escalares no toman silenciosamente el primer valor de una producción múltiple.
7. Para compatibilidad, los productores históricos con cuerpos de instrucciones y `-> x,y` sin encapsular conservan el parser estructural antiguo cuando la nueva expresión no es aplicable.
8. El parser limita a 128 la profundidad de expresiones. La producción limita a 200 000 elementos por productor y a 1 000 000 de celdas en el motor, evitando agotar memoria por materializaciones infinitas.

## Contrato visual

| Sintaxis | Significado |
|---|---|
| `for(y=1..3)` desnudo | Produce `1,2,3` como valores separados |
| `[for(y=1..3)]` | Un `Array` `[1,2,3]` |
| `(for(y=1..3))` | Un `ValuePack` `(1,2,3)` |
| `(for(y=1..3),9)` | Un `ValuePack` `(1,2,3,9)` |
| `([for(y=1..3)],9)` | Un `ValuePack` `([1,2,3],9)` |
| `for(y=1..0)` | Dirección implícita descendente `1,0` |
| `for(y=1..10,2)` | Extremo obligatorio: `1,3,5,7,9,10` |

## Cómo verificar

Desde PowerShell abierto en la carpeta raíz del proyecto:

```powershell
.\VERIFY_COMPOSICION.ps1
```

O bien:

```powershell
cargo test --test composicion_contrato_tests -- --nocapture
cargo test --test composicion_generativa_tests -- --nocapture
cargo test
```

En las pruebas del contrato, las 22 comprobaciones pendientes de la revisión 2 están **activadas**. La suite generativa comprueba profundidad variable, anidamientos, valores intercalados, filtros, argumentos y errores de aridad. Una prueba de estrés de generador infinito queda explícitamente ignorada para evitar sobrecargar la máquina por accidente.

## Límites conocidos y decisiones todavía abiertas

- `-> a,b` sin encapsulación puede ser ambiguo cuando se mezcla con comas del contenedor exterior. Los productores históricos conservan su interpretación; para nueva composición se recomienda agrupar `-> (a,b)` (un solo Pack) o separar los productores en el contenedor exterior. Se debe formalizar una gramática de delimitación de producciones desnudas antes de prometer una sintaxis sin ambigüedades para todas las combinaciones.
- Los cuerpos arbitrarios de varias instrucciones de un productor anidado todavía no se modelan como subprogramas completos en el AST de expresiones; las expresiones y el filtro condicional `if` están integrados. Los productores tradicionales que tienen bloques de instrucciones continúan por la ruta de compatibilidad.
- Las reglas de referencias en listas no deben cambiar sin pruebas explícitas de identidad; por eso los Arrays ordinarios mantienen copias de valores, y el productor conserva las referencias explícitas donde la semántica previa las conserva.
- La refactorización requiere compilación y verificación con Rust, una comparación detallada de los errores de compilador, pruebas de propiedades con casos aleatorios y análisis de rendimiento real antes de una declaración de estabilidad.

## Archivos tocados

- `src/ast/mod.rs`
- `src/lexer/token.rs`
- `src/lexer/lexer.rs`
- `src/parser/mod.rs`
- `src/source.rs`
- `src/interpreter/mod.rs`
- `tests/composicion_contrato_tests.rs` (activadas)
- `tests/composicion_generativa_tests.rs` (nuevas)
- `VERIFY_COMPOSICION.ps1`

Se ha conservado el resto del proyecto fuente, las pruebas históricas y los documentos anteriores.
