# YEK v0.0.7_3 internals

## Universal data value/reference rule

For ordinary data cells:

```yek
a
```

loads/copies the current value, while:

```yek
a!
```

produces a `Reference(CellID)` in expression contexts. Consumers preserve or materialize that reference according to their semantic role.

Code identity keeps its pre-v0.0.7 behavior: `code!` still captures executable Code rather than exposing a mutable data-cell reference.

## Code parameters

`f(a)` allocates a local parameter cell containing a copy. `f(a!)` binds the parameter name directly to `a`'s CellID. Therefore writes through the parameter mutate the caller until exact `x=x` performs DetachSelf.

## Stable logical addresses

`(a!)!` emits a stable YEK logical identity such as `&0x0000000000000001`. This is a CellID, not an operating-system or Rust allocation address. Aliases show the same CellID; DetachSelf creates a different CellID.

## Contract capture

When a `~str/~num/~bool` directive executes:

- bare identifiers are resolved immediately and serialized into the contract template (value snapshot),
- `identifier!` captures that variable's current CellID in the ContextFrame,
- later `?` acquisitions resolve live references through the captured CellID, not by looking up the variable name again.

Consequently `name=name` may detach the source name without invalidating existing contract references.

## String contract grammar

Loose one-character items are removed. Use quotes:

```yek
~str("a","_",a..z)
```

A quoted scalar of one Unicode scalar is an allowed character. Longer quoted strings are complete exact values. Static compact ranges remain `a..z`. Variable endpoints by value use grouping, `(low)..(high)`, while live references use `low!..high!`.

## Bool literals and labels

`true` / `false` are AST Bool literals. They do not allocate variable cells. Assigning text to the reserved assignment targets changes ContextFrame display labels only:

```yek
true="verdad"
false="falso"
```

Internal Bool identity and contract input representations stay unchanged.
