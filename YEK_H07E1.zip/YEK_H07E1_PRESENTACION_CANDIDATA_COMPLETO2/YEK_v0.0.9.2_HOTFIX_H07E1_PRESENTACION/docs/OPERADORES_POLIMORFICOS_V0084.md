# YEK 0.0.8.4 — contrato de operadores polimórficos

**Estado:** implementación candidata, pendiente de validación completa con Rust/Cargo.

El operador se selecciona por **tipo del operando izquierdo**, conservando las operaciones aritméticas numéricas previas. `Array` y `ValuePack` reciben las mismas reglas, pero conservan su tipo, profundidad de anidamiento y orden.

| Operación | Semántica sobre contenedores | Cantidad de resultados |
|---|---|---|
| `A + x` | Añade x al final; si x tiene el mismo tipo exterior que A, concatena los elementos | 1 |
| `A - x` | Elimina la primera aparición de x (igualdad profunda); si no existe, error | 1 |
| `A * n` | Repite plano los elementos n veces (n entero >= 0) | 1 |
| `A / k` | Produce k grupos equilibrados contiguos sin contenedor exterior; 1 <= k <= longitud | k |
| `A // k` | Prefijo cuya longitud es el múltiplo de k más grande <= longitud | 1 |
| `A % k` | Sufijo con longitud `longitud % k` | 1 |

`/`, `//`, `%` requieren k entero positivo. Para `//` y `%`, k puede exceder la longitud (resultado vacío y entrada íntegra, respectivamente). El resultado no muta el contenedor original; los valores Array anidados se copian profundamente al producir resultados nuevos, salvo las semánticas de referencias explícitas anteriores.

`a,b=[1,2,3]/2` asigna `[1,2]` a a y `[3]` a b. `a=[1,2,3]/2` falla por aridad. `a=[[1,2,3]/2]` produce `[[1,2],[3]]`. Los paréntesis alrededor de una división estructural recopilan sus resultados en un ValuePack; los paréntesis de división numérica siguen siendo agrupación numérica.

La división numérica `/` no cambia. La nueva `//` numérica devuelve el piso de la división racional: `-7//3 == -3`. `%` numérico mantiene la implementación previa sobre enteros (resto truncado para signos negativos), para no alterar retrocompatibilidad inadvertidamente; no debe asumirse equivalencia exacta con el módulo de Python para esos números negativos.

## Limitaciones de contrato

- No hay coerción implícita de texto, bool ni Code a número.
- El operador `^` no se aplica a contenedores.
- Repetir o concatenar una estructura muy grande puede superar el límite de materialización y generar error controlado.
- La igualdad profunda sigue las reglas existentes (`Code` no es comparable).
- Composiciones que requieren un valor único rechazan explícitamente resultados plurales, salvo que exista un contenedor receptor.

## Pruebas

`cargo test --test operadores_polimorficos_tests -- --nocapture`

`cargo test` ejecuta las pruebas históricas, las de composición y las nuevas.

No es una afirmación de que cualquier programa concebible esté cubierto; la semántica se implementa por tipos y recepción de valores para permitir composición arbitraria en contextos válidos.
