# Contrato de composicionalidad: YEK / revisión 2

**Estado: propuesta de semántica y pruebas de regresión; NO es una reparación del intérprete.**

## 1. Correcciones aceptadas

- `1..0` es una secuencia finita descendente inclusiva: `1,0`.
- Cuando no hay paso explícito, dirección por comparación de extremos: `+1` ascendente, `-1` descendente.
- La versión actual **sí fuerza el extremo** con un paso explícito que no lo alcance exactamente: `1..10,2` -> `1,3,5,7,9,10`. Esta regla está en `src/interpreter/mod.rs` y `tests/v008_1_tests.rs`. No cambiarla incidentalmente durante el refactor; cualquier cambio es decisión de lenguaje.
- P08: `[(1, [1, 0], 9), (2, [1, 0], 9)]`.
- P10: `[([(1, 2, 1, 1), (1, 2, 1, 2)], 1), ([(1, 2, 2, 1), (1, 2, 2, 2)], 2)]`.

## 2. Semántica independiente de contexto y no basada en patrones especiales

La evaluación de expresiones debe distinguir entre **un valor** y **una producción de 0..N valores**.

- `Scalar(Number/String/Bool/Array/ValuePack/...)`: ocupa un solo campo de cualquier contenedor exterior.
- `Many(items...)`: representa valores desnudos de un productor. Al entrar en un *slot* de lista de expresiones (`a,b=`, Array literal o Pack literal), sus elementos se insertan como campos consecutivos y en orden.
- `[E]` materializa el resultado a **un Array** sin aplanar Arrays ni Packs interiores.
- `(E)` cuando E produce múltiples valores materializa el resultado a **un ValuePack**; sin múltiples valores, preservar compatibilidad con las reglas existentes de Group de una sola expresión. Esto obliga a distinguir explícitamente Group y Pack en el AST.
- `(E1, E2, ...)` materializa un ValuePack tomando todos los elementos de cada `Many` desnudo; `Array` y `ValuePack` que ya sean valores se conservan intactos como un solo elemento.
- El productor `for(...)` utiliza un encabezado y cuerpo analizados recursivamente, con una frontera de producción léxica: el `->` más cercano produce en su `for`, no en un `for` contenedor.
- `-> ( ... )` produce un ValuePack por iteración; `-> a,b` a nivel del cuerpo produce dos valores desnudos. En un `for` anidado inline como `(for(y=1..3) -> y-1, x)`, la coma después de `y-1` pertenece al Pack exterior, no al `->` interior. La gramática debe formalizarlo.
- Cada subexpresión se evalúa una sola vez y de izquierda a derecha. Los binders internos no destruyen los externos, incluso con el mismo identificador.
- En operadores escalares no se selecciona automáticamente el primer elemento de `Many`; se produce un error de aridad o tipo, según el contexto.

### Ejemplo P10 por niveles

1. Para x=1, el y=1 genera el pack `(1,2,1,1)` y el y=2 genera `(1,2,1,2)`.
2. El Array interno retiene ambos Packs y se convierte en un **único campo** del Pack exterior; el otro campo es `x=1`.
3. x=2 repite con `([(1,2,2,1), (1,2,2,2)], 2)`.
4. El Array exterior retiene un elemento por x, **no** crea un producto cartesiano.

## 3. Arquitectura recomendada (Rust)

- **Lexer**: reconocer `for`, `if`, `->`, delimitadores, textos/comentarios sin romper parejas por saltos de línea.
- **Parser**: `Expr::ForProducer { header, body }`, un nodo expresión real, procesado dentro de otras expresiones en cualquier profundidad; mantener `Stmt::For` para un bucle normal. Sustituir la detección exclusiva de `parse_for_producer_assignment` en `source.rs`, sin romper `ForAssign` de compatibilidad durante transición.
- **AST y evaluador**: tipo de evaluación `Scalar(RuntimeValue) | Many(Vec<RuntimeValue>)`; NO usar un `ValuePack` como sustituto de `Many`.
- **Recogedores**: combinador común de slots para Pack, Array, asignaciones y retornos, preservando Array/Pack anidados.
- **Scopes**: frontera propia por productor; copiar/restaurar nombres de binders y estado de producción del bucle; preservar `!` y CellID.
- **Errores**: aridad, cierres faltantes, dirección de paso, rangos abiertos, valores no escalares en operaciones escalares.
- **Seguridad/recursos**: límites para materializar productores infinitos o combinaciones explosivas; no evaluar recursión arbitraria hasta agotar memoria.

No es correcto reparar solamente `(for`, `[for` o cierres con `),` mediante expresiones regulares: se repetirán los errores al cambiar profundidad, delimitadores, bloques o cadenas.

## 4. Criterio de aceptación general

1. Pasan `cargo test` y todas las verificaciones históricas.
2. Pasan los casos de `tests/composicion_contrato_tests.rs` desactivando su atributo `#[ignore]`.
3. Se añaden pruebas generativas: secuencias de profundidad 1..5, mezcla de 0..3 productores por contenedor, valores de cada tipo, espacios/saltos de línea y operadores, captura de variables, excepciones y referencias.
4. Los resultados coinciden con un oráculo semántico independiente de la sintaxis concreta.
5. El intérprete no contiene ramas de ejecución para P08, P10 o cualquier número de prueba: solo reglas composicionales aplicables por recursión.
6. Se verifica crecimiento de memoria y tiempo para productores grandes, cadenas y fallos deliberados.

## 5. Cómo usar la suite

```
cargo test --test composicion_contrato_tests
cargo test --test composicion_contrato_tests -- --ignored --nocapture
cargo test
```

El primer comando ejecuta las comprobaciones de la semántica Range actual. El segundo ejecuta los casos *pendientes* intencionalmente ignorados en ejecuciones normales. Se espera que varios fallen con el parser actual. No confundir un `cargo test` verde con que estas pruebas desactivadas se hayan aprobado.

**Limitación:** en el entorno de esta auditoría no están disponibles `cargo` ni `rustc`; las salidas son esperadas por contrato, no salidas obtenidas al ejecutar la suite Rust.
