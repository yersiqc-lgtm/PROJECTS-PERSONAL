# YEK v0.0.7_1 internals

## Split strategy

v0.0.7_1 implements the static foundation of the v0.0.7 design. v0.0.7_2 is expected to extend descriptors with dynamic expressions and Packs without replacing the acquisition state machine.

## Source layer

`SourceParser` still owns Work modes. Input directives are recognized only in Code interpretation and lower to `Stmt::SetInput`. The source layer collects an entire parenthesized contract before passing any inline remainder to the ordinary lexer.

Ordinary Code collection is now lexically string-aware across physical lines. `~` outside a string keeps its inline-comment meaning; `~` inside a multiline string is literal.

## AST

`Stmt::SetInput(InputDirective)` is the new statement-level representation. Contract structures live in `src/input.rs` and are independent of Work modes.

## Runtime ContextFrame

Each frame contains:

```text
bindings
call_id
input: InputDirective
```

Global starts at `Auto`. Every Code invocation creates a new frame with `Auto`; captured bindings are retained according to v0.0.6, while Input state is not inherited.

## Acquisition engine

The interpreter snapshots the current `InputDirective` at the start of each `?` and then runs one common retry/final-policy loop. In v0.0.7_1 all descriptor values are static, but this snapshot boundary is intentionally the point where dynamic v0.0.7_2 values will be resolved.

`none`, `warning`, and `error` are exhaustion handlers, never per-attempt handlers. `retry_message` is separate and may run after every rejected candidate.

## Number raw/value split

Number validation sees both the raw input lexeme and the exact rational `Number`. Raw length checks run on the original string; mathematical ranges/exact values run on the normalized exact number.

## Compatibility-sensitive choices

- Anonymous input/output cursor remains runtime-global as in v0.0.6; its localization is still intentionally not changed.
- Code captures and data aliases keep v0.0.6 cell semantics.
- `~auto` preserves the previous auto Number/Text inference.
- No implicit runtime evaluation of String as code is introduced.
