# v0.0.8_1 Range assignment semantics

This note supersedes the earlier draft rule that allowed `a=0..10` to store a scalar Range.

Outside a `for` header, a finite Range is a multi-value producer using only its default step (`+1` or `-1`).

```yek
a,b=0..1
```

produces two values and assigns `a=0`, `b=1`.

A single destination cannot silently store all produced values:

```yek
a=0..10
```

is an arity error because eleven values are produced for one destination.

Parentheses collect the produced sequence into a ValuePack:

```yek
a=(1..10)
```

produces:

```text
(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
```

A comma outside `for` is never interpreted as a Range step:

```yek
a,b,c=0..1,9
p=(1..3,9)
```

produce `0,1,9` and `(1,2,3,9)` respectively. Custom step syntax remains exclusive to `for(source, step)` and `for(binding=source, step)`.

Open Ranges such as `0..` cannot be expanded into ordinary assignment values because they have no finite result count; consume them with `for`.
