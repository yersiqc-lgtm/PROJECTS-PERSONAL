# YEK v0.0.7_2 internals

## Dynamic contract snapshot

`StringContract`, `NumberContract` and `BoolContract` preserve their original contract source whenever an `identifier!` reference is present. At the start of each acquisition the interpreter resolves those bindings once, expands compatible Packs, reparses the resulting static descriptor and then enters the normal retry machine. No binding is re-read between retries of the same `?`.

This preserves a single acquisition engine: static and dynamic contracts share validation, `attempts`, retry messages, final policy, fallback and diagnostics.

## Structured Packs

`Expr::Pack(Vec<Expr>)` represents ordinary runtime values. Calls flatten a ValuePack into positional arguments. BoundCode binding also accepts one ValuePack and fills the currently free signature in order.

`Expr::ContractPack(String)` retains contract grammar such as ranges, length brackets and handlers. It is never executed as YEK source. Expansion recursively feeds its structured items into the target Input family.

A ValuePack may also be expanded in a contract; each runtime value is converted to a compatible contract literal. This is useful for packs such as `(10,"5")` in `~num`.

## Source scanner and multiline packs

The Code fragment collector tracks normal-string state and parenthesis depth. A multiline ValuePack, ContractPack, call, or other parenthesized Code expression is collected as one logical fragment before the lexer/parser runs.

## Local Work modes in Code

Captured indented `~code` bodies are parsed by a nested `parse_code_scope`. That nested source scope owns its Work mode transitions (`~code`, `~math`, `~text`, `~invalid`). Switching mode inside the captured source changes only the compiled body being constructed; it never changes the caller's source/runtime context.

At runtime every Code invocation still pushes a fresh `Frame` with local bindings and `InputDirective::Auto`, while its captured cells remain readable according to the closure behavior inherited from v0.0.6.

## Compatibility constraints

- Exact `x = x` remains the only DetachSelf form.
- `x = (x)` remains a grouped expression and must not detach.
- Anonymous cursor semantics remain unchanged for compatibility.
- No arbitrary string eval is introduced by dynamic contracts.
- Predicates `#` and NamePack remain future design items.
