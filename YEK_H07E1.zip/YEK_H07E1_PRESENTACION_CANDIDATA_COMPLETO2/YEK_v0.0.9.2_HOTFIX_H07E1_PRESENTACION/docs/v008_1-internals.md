# YEK v0.0.8_1 internals

## Scope

This delivery implements the control-flow foundation defined by the v0.0.8 design document. It intentionally stops before advanced For production/reference semantics.

## Source scanner

`if`, `orif`, `else`, and `for` are structural directives recognized by `SourceParser` while Work mode is Code. They are parsed before the legacy unknown-tilde comment path.

Control bodies are indentation-delimited. A control directive requires a non-empty indented body. `orif` and `else` must immediately continue a matching `if` chain at the same indentation.

Ordinary expressions inside control headers are parsed by the regular Code lexer/parser through `Parser::parse_expression_only`, so precedence is shared with normal Code expressions.

## AST additions

Important nodes:

```text
Expr::Array
Expr::Range
Expr::Infinity
Stmt::If
Stmt::For
Stmt::Break
Stmt::Continue
ForHeader::{Infinite, Simple, SimpleStep, Binding}
```

Logical/comparison operators are regular AST operators rather than source-scanner special cases.

## Expression precedence

From loose to tight:

```text
or
and
not
comparisons
Range '..'
+ -
* / %
unary + -
postfix call / contextual !
```

`not a == 5` therefore means `not (a == 5)`.

`and` and `or` are evaluated with short-circuit semantics in the interpreter.

## Runtime values

New first-delivery internal values:

```text
Value::Array(Vec<Value>)
Value::Range { start, end }
Value::Infinity(direction)
```

`Value::Range` is an internal evaluated representation used by `for` and Range
normalization. In ordinary multi-value assignment/output contexts a finite Range
expands to its sequence rather than being stored as one scalar value. Thus
`a,b=0..1` succeeds, `a=0..10` is an arity error, and `a=(1..10)` collects the
sequence into one ValuePack. Open Ranges cannot be expanded outside `for`.
A comma outside a `for` header is never interpreted as a Range step.

Array is heterogeneous. This first delivery intentionally stores snapshot values; element Cell references and live container semantics are reserved for the advanced delivery.

## Range stepping

A finite Range is destination-inclusive. The runtime computes a direction from start/end when no explicit step is given. A caller-supplied step is never corrected silently.

Rules:

- step == 0 -> error;
- ascending destination with non-positive step -> error;
- descending destination with non-negative step -> error;
- an overshooting next step clamps to the endpoint;
- once the endpoint has executed, the loop terminates;
- Number remains exact rational arithmetic, so decimal steps do not accumulate IEEE binary error.

Open Range default direction:

- explicit step: sign of step;
- otherwise negative explicit start -> -1;
- otherwise +1.

`inf` and `-inf` carry an explicit infinite direction.

## Contextual For normalization

The interpreter distinguishes:

```text
for                  Infinite
for(Number)          Repeat exact N
for(Bool)            Conditional loop
for(Range)           Range, values discarded
for(Array)           Iterate count, values discarded
for(name=Number)     Range 0..target
for(name=Range)      Bound Range
for(name=Array)      Array value binding
for(index,value=Array) index + value binding
```

`for(source,step)` is accepted only for Range/Infinity in this delivery.

## Loop flow

Execution flow adds internal states for Break and LoopContinue. Nested loops consume their own `break` / `continue`, while function/Code boundaries reject leaked loop control.

Loop binders are implemented with temporary local cells. Previous bindings are saved and restored after the loop. Before every iteration, the binder name is rebound to the loop-owned cell so body aliases/detaches cannot corrupt the next iteration's binding identity.

## For production boundary

The final v0.0.8 design assigns `->` inside a For to For value production. Because producer/collector semantics belong to the advanced delivery, this implementation scans the loop body and rejects direct For-context `->` rather than accidentally treating it as a Code return.

Returns inside a nested captured Code value are not rejected because they belong to that Code's producer context.

Likewise, `break(value)` is parsed as an explicitly unavailable advanced form.

## ContractPack compatibility

The older ContractPack source scanner used broad `[` / `..` detection. That would steal ordinary v0.0.8 data such as:

```yek
a=(1..3,9)
a=([1,2],3)
```

The heuristic now recognizes contract-only grammar (handlers, contract length forms, static character ranges, etc.) while allowing ordinary Range/Array ValuePacks through the normal parser. In `(1..3,9)`, the Range contributes `1,2,3` and `9` is simply the next Pack item; the comma is not a step.

## Deferred semantics

The following are deliberately rejected rather than partially implemented:

```text
reference iterator binder
live-reference iterable/source
live Range endpoint/step
destructuring binder
synchronized N iterators
For -> production
Pack/Array For collectors
break(value)
~block / go
```

No user-facing diagnostic for these cases should include release/version numbers.
