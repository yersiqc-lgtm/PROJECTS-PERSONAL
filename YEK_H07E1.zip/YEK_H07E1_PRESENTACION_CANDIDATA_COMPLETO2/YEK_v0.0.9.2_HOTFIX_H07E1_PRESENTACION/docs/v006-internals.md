# YEK 0.0.6 - implementation notes

This file documents the prototype internals added after the stable 0.0.5 source layer.

## Code values

A captured `~code` is represented by a `CodeValue` with:

- original parameter names;
- parsed body (`Program`);
- lexical captures as name -> CellID;
- one binding slot per original parameter.

An unbound slot is part of the visible signature. `f(args)!` on the RHS creates a new Code value with selected slots fixed; it does not execute the body.

## Return flow

`->` becomes `Stmt::Return(Vec<Expr>)`. Execution propagates an internal `ExecFlow::Return` out of the current Code invocation. Zero values means return-void; more than one value remains ordered.

## Cells and aliases

Variables map to CellIDs. `b = a!` maps `b` directly to the same CellID as `a`; reference chains are therefore flattened by construction.

Normal assignment to an already bound name writes its current cell. The exact AST form `b = b` is intercepted before normal evaluation and creates a new cell containing the current value. Parentheses are retained in the AST so `b = (b)` is not mistaken for DetachSelf.

## Basic lifetime guard

Cells created for function parameters/locals carry the current call ID. A direct reference returned with `-> local!` is rejected when it points to a cell owned by the call that is about to finish.

## Diagnostics

Statements carry a source span. Lexer/parser/source/runtime errors preserve or add a `line:column:` prefix. The CLI renderer turns that into a source excerpt and caret. ANSI warning labels/carets use bright yellow; errors use bright red. Colors are disabled by `NO_COLOR` and can be forced with `YEK_COLOR=always`.
