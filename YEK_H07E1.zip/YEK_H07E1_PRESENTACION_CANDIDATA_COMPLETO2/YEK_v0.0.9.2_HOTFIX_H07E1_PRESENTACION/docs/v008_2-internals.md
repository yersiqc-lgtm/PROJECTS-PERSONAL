# YEK v0.0.8_2 internals

`v0.0.8_2` completes the v0.0.8 control-flow design on top of the verified `v0.0.8_1 hotfix 2` base.

## 1. Producer-aware For AST

`Stmt::ForAssign` represents a `for` with a receiving assignment. `ForCollector` records whether the produced stream remains independent return values, is collected into one ValuePack, or is collected into one Array.

```text
ForCollector::MultiValue  a,b = for(...)
ForCollector::Pack        a   = (for(...))
ForCollector::Array       a   = [for(...)]
```

A direct `Stmt::Return` (`->`) inside the nearest For body is interpreted as `LoopStep::Yield` while a producer is executing. It terminates only the current iteration. `break(values...)` becomes `LoopStep::Break(values)`.

`program_contains_for_production` establishes the production mode before execution. If a direct `->` or `break(value)` is present, implicit iterator emission is disabled for the whole For. Nested For/ForAssign and captured Code are producer boundaries and do not change the outer For mode.

## 2. Array element cells

Array storage is now logically:

```text
Value::Array(Vec<CellId>)
```

rather than `Vec<Value>`. This is required for real element references. A normal value read performs deep value-copy of an Array and allocates fresh child cells. For iteration has a specialized source resolver so it can intentionally snapshot the current element cell identities or retain a live reference to the root Array cell.

## 3. Four iterator reference modes

```text
for(n  = array)    Snapshot root membership + value element
for(n! = array)    Snapshot root membership + referenced element cell
for(n  = array!)   Live root cell + value element
for(n! = array!)   Live root cell + referenced element cell
```

Snapshot means the initial element CellIDs are retained even if the variable name is rebound later. Live means each iteration resolves the current Array stored in the referenced root cell.

## 4. ForPattern

`ForPattern` is either a named value/reference binder or an explicit destructuring pattern.

```text
Name { name, by_ref }
Destructure(Vec<ForPattern>)
```

A single Array source accepts one pattern or `index + pattern`. Parenthesized destructuring removes the ambiguity:

```yek
for(i,a = values)       ~ index + complete element
for((x,y) = points)     ~ destructure element
for(i,(x,y) = points)   ~ index + destructure element
```

Referenced destructuring components are synchronized back to the source ValuePack element after each iteration. This preserves observable source mutation while keeping the existing ValuePack representation.

## 5. Synchronized Arrays

For multiple source expressions, all sources must resolve to Arrays. N sources require N patterns, or N+1 patterns when the first is the shared plain-value index. Lengths are checked during iteration; different lengths are an error and are never silently truncated.

Live source references participate in the same per-iteration length and element resolution.

## 6. Live numeric feeds

`NumberFeed` separates snapshot numeric values from referenced cells. `RangeEndFeed` does the same for endpoints and can also retain a referenced Range root.

```yek
for(i = 0..end!, step!)
```

reads `end` and `step` again while progressing. A live step of zero or a live step moving away from a finite destination is a runtime error. No step is silently corrected.

## 7. Block CFG

`Stmt::Block` and `Stmt::Go` implement high-level basic blocks.

At each Program scope, `execute_program` builds a local block-name map. `go` first resolves in that map. If not found it bubbles through structured scopes such as If/For until the current Code execution boundary. `invoke_code` rejects any unresolved `go`, preventing cross-Code transfer.

Block parameters are jump arguments. Value arguments allocate local cells; reference arguments bind the block parameter directly to the referenced CellID. Parameter bindings are restored when the block body exits.

A Block is not Code: it does not create a call frame and does not represent recursion.

## 8. Compatibility constraints

- Outside `for`, finite `start..end` still expands as multiple values according to v0.0.8_1 hotfix 2.
- A comma outside `for` never means a Range step.
- `x=x` remains the only exact DetachSelf syntax.
- `!` keeps the universal value/reference meaning introduced in v0.0.7_3.
- `true` and `false` are Bool literals and cannot be referenced as data cells.
- User-facing diagnostics do not contain language release names.
