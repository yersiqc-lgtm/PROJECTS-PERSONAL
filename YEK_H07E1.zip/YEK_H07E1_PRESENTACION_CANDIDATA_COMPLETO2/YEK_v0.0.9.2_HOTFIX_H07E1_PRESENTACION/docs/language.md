# YEK v0.0.7_2 - comportamiento implementado

Este documento conserva debajo la referencia completa de v0.0.6. La primera mitad de v0.0.7 añade, sin reemplazar esas reglas:

- strings normales `"..."` multilínea;
- ContextFrame de Input local por invocación de Code;
- `~auto`, `~str`, `~num`, `~bool`;
- contratos estáticos, `attempts`, mensajes de retry, handlers finales y fallbacks;
- Bool como valor runtime nativo.

La base estática se documenta en `docs/v007_1-internals.md`; la capa dinámica, Packs y Work modes locales se documentan en `docs/v007_2-internals.md` y en el README.

---

# Referencia heredada de YEK 0.0.6

Este documento describe el prototipo actual. Las reglas anteriores de 0.0.3
siguen vigentes salvo donde aquí se extienden explícitamente.

## 1. Estado inicial

Todo archivo comienza en `~code` implícito.

## 2. Familia global de directivas

Directivas oficiales actuales:

```text
~code
~text
~invalid
~math
```

Deben aparecer pegadas (`~math`, no `~ math`). Se permite indentación antes de
la directiva. Una directiva global oficial ocupa su propia línea.

## 3. `~text`

`~text` es RAW. No existe interpretación interna de:

```text
" ' ? ! \\ / \n \t () [] {}
```

Solo una directiva oficial exacta puede cambiar el modo. Una línea `~unknown`
permanece texto literal en este estado.

Un `~text` global emite literalmente sus líneas. Un `x = ~text` captura las
líneas como un valor Text y elimina únicamente el newline estructural final que
separa el contenido de la directiva de cierre.

## 4. `~invalid`

Todo contenido se descarta sin pasar por el lexer normal. Una directiva oficial
exacta cambia el estado. `~invalid` no produce valor y no puede asignarse.

## 5. `~math`

Un bloque matemático representa exactamente una expresión. Los newlines y
espacios son whitespace matemático.

### 5.1 Multiplicación implícita

```text
2a             -> 2 * a
a(b)           -> a * b
2(a+b)         -> 2 * (a+b)
(a+b)(c+d)     -> (a+b) * (c+d)
```

Un identificador completo como `ab` sigue siendo una sola variable.

### 5.2 Potencia

```yek
~math
2^3^2
~code
```

se interpreta de forma asociativa a la derecha (`2^(3^2)`). En 0.0.4 el
exponente debe ser un entero.

### 5.3 Resultado

`~math` global emite el resultado sin newline automático. `x = ~math` asigna el
resultado a `x`.

Una captura matemática puede empezar en la misma línea:

```yek
x = ~math 2a + 5
~code
```

Dentro de una captura `~math`, otra asignación capturada puede cerrar la actual
y comenzar la siguiente:

```yek
a = ~math 2x
b = ~math a(3)+1
~code
```

## 6. `~code` capturado

```yek
action = ~code
"hello"
~code
```

produce un valor `Code`. El cuerpo se analiza al compilar, pero no se ejecuta
en la definición.

```yek
action!
```

activa el valor y ejecuta su cuerpo. La activación no agrega formatting ni
newlines propios. Solo las instrucciones del cuerpo producen salida.

El mismo Code puede ejecutarse repetidamente.

En 0.0.4:

- no hay parámetros todavía;
- no hay sintaxis de `return` todavía;
- no hay múltiples retornos todavía;
- las variables normales del programa son visibles cuando el bloque se ejecuta;
- los efectos de las instrucciones del bloque usan el mismo runtime global del
  prototipo (incluido el flujo anónimo).

## 7. Directivas dentro de Code capturado

Un Code capturado puede usar modos internos. Ejemplo conceptual:

```yek
action = ~code
~text
RAW ? !
~code
~code
```

El primer `~code` regresa desde Text al modo Code del cuerpo. El segundo cierra
la captura externa.

## 8. Comentarios y warnings

En Code/Math:

```yek
~ comment
~
~ code
```

son comentarios intencionales sin warning.

Una forma pegada desconocida:

```yek
~mathh
```

se comenta y produce warning en inglés. Esto ayuda a encontrar errores
ortográficos sin impedir usar `~` como comentario de línea.

En Text, el mismo contenido es literal. En Invalid, se descarta.

## 9. Núcleo preservado de 0.0.3

Se conserva:

- asignación normal;
- números y texto;
- `+ - * /` en Code;
- `?` y `!`;
- variables anónimas y cursor sticky;
- strings activos;
- strings pasivos;
- enlace estricto dentro de active strings;
- `(expression)!` dentro de active strings;
- escapes de string existentes;
- auto-tipado provisional de inputs;
- aritmética decimal exacta experimental.

## 10. Directivas capturables actuales

| Directiva | Global | Capturable | Valor |
|---|---:|---:|---|
| `~code` | sí | sí | `Code` |
| `~text` | sí | sí | `Text` |
| `~math` | sí | sí | valor matemático |
| `~invalid` | sí | no | ninguno |

## 11. Pendiente deliberadamente

No formaba parte de 0.0.4 (varios puntos ya fueron incorporados en 0.0.6):

- parámetros/retornos de Code: **implementados en 0.0.6**;
- funciones matemáticas (`sin`, `cos`, etc.);
- ecuaciones simbólicas;
- matrices;
- `~num`, `~txt`, `~log`;
- booleanos/comparaciones;
- scope/ownership definitivos;
- YIR/backend nativo.


## 0.0.5 - comentarios inline e indentación local de capturas

La sintaxis estable de 0.0.4 se conserva. Se añaden estas reglas:

- En `~code` y `~math`, `~` fuera de strings comenta hasta el final de línea.
- `x = ~math 2 + 6`, `x = ~text hello` y `x = ~code "hello"` son capturas inline.
- Si una captura comienza en la línea siguiente, las líneas con indentación mayor
  pertenecen al bloque y el dedent lo cierra.
- La indentación no tiene significado estructural fuera de capturas asignadas.
- Una captura inline puede continuar con líneas indentadas.
- `~text` elimina la indentación estructural común pero conserva la adicional.
- `~code` repetido como directiva de estado es idempotente.
- Los cierres explícitos usados en 0.0.4 continúan siendo aceptados.

Ejemplo:

```yek
main = ~code
    "nombre : ?"
    "edad : edad?"

    edad = ~math
        edad + 10

    show = ~code
        "edad futura =edad!"

    show!

main! ~ execute the captured block
```

## 12. YEK 0.0.6 - Code con parametros, retornos y referencias

La v0.0.6 extiende `Code` sin introducir `fn` ni `function`.

### 12.1 Parametros

```yek
sum(a, b) = ~code -> a + b
```

Los parametros son locales a la llamada y ocultan nombres exteriores. Una llamada normal debe proporcionar exactamente los parametros libres del `Code` o `BoundCode`.

### 12.2 Retorno explicito `->`

```yek
f(a) = ~code
    -> a + 1
```

`->` sin valores termina el `Code` sin retorno. `-> a, b, c` produce varios retornos ordenados.

### 12.3 Llamadas y `!`

```yek
x = f(10)      ~ ejecuta y captura retorno
f(10)!         ~ ejecuta y emite retorno(s)
copy = f!      ~ captura el Code, no su retorno
```

Para un `Code` sin parametros, `x = f` y `x = f()` obtienen su retorno. `copy = f!` conserva el ejecutable.

### 12.4 Retornos multiples

```yek
ops(a,b) = ~code -> a+b, a-b
sum, diff = ops(10,4)
sum, = ops(10,4)
```

Los slots vacios descartan conscientemente el retorno correspondiente. La cantidad total de slots debe coincidir con la cantidad de retornos.

### 12.5 BoundCode y partial application

```yek
sum(a,b,c) = ~code -> a+b+c
sum2 = sum(, , 0)!
sum2(1,2)!
```

`sum2` conserva el mismo cuerpo pero fija `c=0`; solo `a` y `b` quedan libres. Tambien se acepta la forma legible `sum(a,b,0)!`, donde un identificador que coincide con el parametro original en esa posicion deja ese parametro libre.

### 12.6 Referencias persistentes

```yek
a = 10
b = a!
```

`b` comparte la celda de almacenamiento de `a`. Una asignacion normal sobre cualquiera escribe en la celda compartida.

```yek
b = b + 2
```

no separa la referencia.

La unica forma especial de separacion es la autoasignacion desnuda exacta:

```yek
b = b
```

Esto copia el valor observado por `b` a una nueva celda y vuelve a ligar solo `b` a esa celda. Las siguientes formas NO separan:

```yek
b = b + 2
b = (b)
b = b!
```

`c = b` copia el valor actual. `c = b!` comparte la misma celda.

### 12.7 Seguridad inicial de referencias

Una referencia a una variable local de una llamada no puede escapar directamente:

```yek
make = ~code
    x = 10
    -> x!
```

La implementacion inicial rechaza ese retorno para evitar referencias colgantes.

### 12.8 Diagnosticos

La CLI de v0.0.6 renderiza errores y warnings con ubicacion, linea de fuente y caret. Los warnings usan amarillo ANSI y los errores rojo ANSI cuando la terminal lo soporta. `NO_COLOR=1` desactiva color.

## v0.0.7_3 — value/reference stabilization

For ordinary data, `x` means the current value and `x!` inside an expression means the stable reference to x's YEK cell. This distinction now applies to Code arguments and input contracts. `f(x)` passes a copy; `f(x!)` aliases the caller cell until exact `param=param` detaches the parameter.

`(x!)!` emits the stable logical CellID; it does not expose a native host pointer. `x!`, `(x)!`, and `x!!` keep their existing output/anonymous-output meanings and are not equivalent to `(x!)!`.

Multiple assignment distinguishes ValuePack storage from multiple RHS values: `a,b=(1,2)` destructures, `a=(1,2)` stores the pack, `a,b=1,2` assigns positionally, and `a=1,2` is an arity error.

String contracts no longer accept loose standalone character syntax. Write `~str("a","_")`; compact ranges `a..z` remain valid. A quoted one-character string is an allowed-character constraint, while longer quoted strings remain exact complete values.

`true` and `false` are real Bool literals. `true="verdad"` and `false="falso"` customize only output rendering in the current ContextFrame.

## v0.0.8_1 control-flow foundation

### Array and Range

```yek
a=[1,"two",(3,4),true]
x,y=0..1
p=(1..3)
```

`[...]` is a heterogeneous Array; `(...)` remains ValuePack. A finite `start..end`
acts as a multi-value Range producer outside `for`: `x,y=0..1` assigns `0` and
`1`, while `p=(1..3)` collects `(1,2,3)`. `x=0..10` is therefore an arity
error. Custom Range steps exist only in `for`; a comma in an ordinary
assignment/Pack is another value, never a Range step.

### Conditionals

```yek
if(a==10)
    "ten"
orif(a==3)
    "three"
else
    "other"
```

Conditions are strict Bool expressions. Comparison operators are `== <> < <= > >=`; Bool operators are `not`, `and`, `or`, with short-circuit for `and/or`.

### Contextual For

```yek
for                    ~ infinite
for(10)                ~ exactly ten repetitions
for(a=0..10)           ~ inclusive numeric Range
for(a=10..0,-2)        ~ explicit descending step
for(a=array)           ~ elements by value
for(i,a=array)         ~ index + element
for(condition)         ~ while-like conditional loop
```

`break` exits the nearest loop; `continue` advances to its next iteration. Loop binders are local and do not escape.

Destination-inclusive stepping guarantees the finite endpoint once. A supplied step is never corrected silently and must not be zero or move away from the destination.

Advanced producer/reference iteration and `~block/go` remain reserved for the second v0.0.8 delivery.
