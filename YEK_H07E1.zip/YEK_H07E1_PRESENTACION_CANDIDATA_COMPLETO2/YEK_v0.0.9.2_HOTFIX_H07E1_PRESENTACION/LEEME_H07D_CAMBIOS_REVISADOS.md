# YEK H07D — Integración estructural incremental

Base: H07C, incluyendo correcciones manuales posteriores de QA 18 y `v007_3_tests`.

## Cambios de motor incorporados (requieren validación real con Cargo)

1. `src/source.rs`: límite de ámbito para `~invalid`, `~text`, `~math` cuando están dentro de Code indentado. Una dedentación devuelve el control al lector del ámbito padre sin consumir la línea exterior. Las directivas raíz conservan su semántica anterior.
2. `src/interpreter/mod.rs`: `run_synchronized_arrays` ahora normaliza `Value::Array` de expresiones directas, como `m.keys`/`m.values` (no solo identificadores/literales).
3. `out.end`: configuración local al frame de Code para las salidas `!` y las cadenas activas; `none` elimina el terminador. Hereda la configuración del Code llamador mediante copia; no cambia a su llamador. Las salidas `~text` siguen sin reformatearse.
4. Operaciones locales sobre sentencias de cadena: `"hola".end("")` y `"hola".style(end="",prefix="",suffix="",width=10,fill=".",align="left")`; los argumentos de `.style` deben estar identificados por nombre. Se conserva la interpolación activa dentro de las comillas y el terminador se aplica exactamente una vez a la sentencia.
5. Dos correcciones manuales ya aprobadas y persistidas: suite `v007_3_tests.rs` (rango Unicode) y QA `18_matiz_encapsulado_vs_desnudo.txt` (producción múltiple H07).
6. `tests/h07d_integracion_segura_tests.rs`: regresiones Rust de este incremento.

## Restricciones conscientes

- El formateo local `width` cuenta escalares Unicode, **no ancho de columnas del terminal**. En esta versión no se admite alinear emoji compuestos/anchos dobles visualmente. Debe formalizarse mediante un motor de anchura Unicode antes de garantizar `.pos`.
- Los estilos de lectura (`in.prompt`, etc.), el ValuePack de argumentos nombrados persistentes con referencias vivas, la asignación general `out.style` y los renderizadores `.box/.bar/.table` **todavía no se incorporaron al motor**; añadirlos sin modelo de datos completo sería inseguro. Las especificaciones de aceptación están en `PLAN_H07E_H07G_PENDIENTE.md`.
- No se ha ejecutado `cargo`/`rustc` en este entorno. NO considerar H07D aceptado hasta compilar y pasar la suite general.

## Windows — comandos

```powershell
cargo build
cargo test --test h07d_integracion_segura_tests
cargo test --test etapa7_h07_universal_tests
cargo test --test v007_3_tests
cargo test --test qa_realista_tests
cargo test
```

En caso de fallo, enviar texto de Cargo y mantener el H07C anterior como respaldo.
