# Ejemplos H03C: longitud visual vlen

Cada `.yek` cuenta con archivo `.esperado.txt` para comparar la salida de terminal.

En la raíz del proyecto, ejecuta `cargo run --quiet -- run EJEMPLOS_H03C_VLEN/01_hola_y_unicode.yek`.

- `.len`: cantidad de puntos de código Unicode (comportamiento anterior, sin cambios).
- `.vlen`: cantidad de grafemas Unicode extendidos (UAX #29).
- `str.vlen(text)`: versión nativa al importar `str`.

Los grafemas no equivalen a ancho de pantalla ni siempre al número de glifos dibujados por la fuente. El resultado depende de la versión de Unicode implementada por unicode-segmentation.
