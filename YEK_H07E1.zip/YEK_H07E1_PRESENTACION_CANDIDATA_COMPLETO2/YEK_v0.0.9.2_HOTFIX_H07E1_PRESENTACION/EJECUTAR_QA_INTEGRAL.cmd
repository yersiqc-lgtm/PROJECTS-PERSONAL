@echo off
cd /d "%~dp0"
cargo test --test qa_exhaustiva_fixtures_tests -- --nocapture || exit /b 1
cargo test --test qa_exhaustiva_metamorfica_tests -- --nocapture || exit /b 1
cargo test --test qa_exhaustiva_semillas_tests -- --nocapture || exit /b 1
cargo test || exit /b 1
cargo check || exit /b 1
echo QA INTEGRAL FINALIZADA
