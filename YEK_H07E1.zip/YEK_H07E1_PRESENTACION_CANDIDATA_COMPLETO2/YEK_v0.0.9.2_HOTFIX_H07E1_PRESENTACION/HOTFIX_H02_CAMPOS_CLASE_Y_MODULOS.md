# YEK v0.0.9.1 — HOTFIX H02: asignaciones a campos de Class

**Base:** primera entrega HOTFIX H01 E0382. Mantiene todas sus funcionalidades.

## Incidencia
El test `class_shared_identity_and_method` fallaba con `module namespaces and their exports are read-only` cuando una operacion usaba `self.saldo = self.saldo + cantidad`. El test `struct_field_assignment_must_fail` devolvia el diagnostico equivocado por la misma razon.

## Causa
En `src/parser/mod.rs`, `try_assignment_targets` capturaba nombres cualificados (con `.`) como variables ordinarias antes de alcanzar la rama `Stmt::SetField`. El interprete rechazaba siempre tales variables por las protecciones antiguas de modulos.

## Correccion
- El parser reserva destinos cualificados para `Stmt::SetField`.
- `Stmt::SetField` diferencia nombres de modulo de valores Class/Struct, manteniendo modulos de solo lectura.
- Las instancias Class permiten actualizar campos existentes, incluido `self.campo` desde sus metodos.
- Structs siguen siendo inmutables; no se pueden sobreescribir metodos o crear campos desconocidos por asignacion.
- Se incorporaron 4 tests adicionales a `objetos_firmas_etapa1_tests.rs`. El total previsto es 27.

## Comprobacion desde PowerShell
Desde la carpeta que contiene Cargo.toml:

```powershell
cargo check --all-targets
cargo test --test objetos_firmas_etapa1_tests -- --nocapture
cargo test --all-targets
.\VERIFICAR_HOTFIX_H02_CAMPOS.cmd
```

Los scripts y tests necesitan Rust/Cargo; este entorno de empaquetado no dispone de ellos. Las correcciones de codigo fuente **no han sido compiladas aqui**.
