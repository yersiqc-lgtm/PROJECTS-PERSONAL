# HOTFIX H03 – Pruebas exploratorias de Sintaxis Universal

Base: YEK v0.0.9.1 Entrega 2 H02, con QA de 161 casos integrada.

## Causas y cambios

- **141:** salto de línea tras operadores dentro de una expresión delimitada: `Parser::unary` omite `Newline` antes del siguiente operando.
- **142:** un literal de texto seguido inmediatamente de `.` se interpreta como expresión con miembro; un literal de texto independiente mantiene el comportamiento de cadena activa.
- **143:** `~math` se reconoce como expresión al encontrarse dentro de una expresión Code, de modo parecido a `for`. El parser usa el parser Math existente para su contenido, incluyendo `^`; no añade potencia al modo Code general.
- **151–152:** el colector Code ahora valida el tipo de delimitador mediante pila y anuncia el cierre esperado. La indentación dentro de expresiones abiertas sigue siendo libre.

## Ejecutar en la carpeta donde esté Cargo.toml

```powershell
cargo check --all-targets
cargo test --test sintaxis_universal_hotfix_h03_exploratorios_tests -- --nocapture
cargo test --test qa_h02_sintaxis_universal_tests -- --ignored --nocapture
cargo test --test qa_h02_sintaxis_universal_tests -- --nocapture
cargo test --all-targets
```

**Resultados objetivos:** 10 pruebas H03 correctas, 48 exploratorias correctas, 113 QA de regresión correctas y suite histórica sin regresiones. Son objetivos por verificar: este entorno no tiene Cargo instalado.

El ZIP contiene todos los archivos QA en `QA_ENTREGA2_H02`. Ejecuta los comandos desde la misma carpeta que contiene `Cargo.toml`, evitando extraer únicamente `tests/` sin los casos de entrada. Si algún resultado difiere, comparte el primer fallo completo.
