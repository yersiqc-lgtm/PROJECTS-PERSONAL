# Entrega 1 de 2 — Firmas, entrada anónima y tipos básicos (CANDIDATA)

Esta candidata deriva de YEK v0.0.9.0 ENTREGA 3 HOTFIX H03, sin sustituir la implementación de ~logic, ~math ni los `~block nombre(...)` estructurales.

## Implementado en la candidata

- `f` y `f()` como sentencias ejecutables que DESCARTAN los retornos; los efectos secundarios internos siguen ocurriendo.
- `f!`, `f()!` conservan la salida, `x = f()` conserva el retorno.
- `f(a,b=5) = ~code` con defaults; llamadas por nombre `f(b=8,a=4)`.
- `?` en posiciones de expresión (por ejemplo `f(?)` y `-> ?`) y en defaults (`f(a=?)`). Una adquisición mediante ? en expresión no se agrega a la cola global de anónimos.
- `tarea = ~block`, `tarea(a) = ~block`: operación invocable sin retornos. `~block inicio(...)` conserva su semántica CFG anterior.
- `P(x,y=0) = ~struct` y `C(x,y=0) = ~class` con constructores, campos nombrados, y métodos declarados mediante `~code`/`~block`.
- Structs son valores por contenido; Class conserva identidad al asignarse a otra variable; `self.campo = nuevo_valor` modifica una instancia de Class. Struct rechaza escritura directa a campos.
- `estructura.values` produce un ValuePack y `estructura.fields` nombres de campos.

## Pendiente para la segunda entrega

Modificadores contextuales `~class(private)`, `~code(pure)`, validación/invariantes, encapsulación completa mediante ~export, transacciones atómicas, once, composición avanzada de operaciones, clases/structs como relaciones declarativas y parámetros anónimos posicionales sin nombre (`f(?,?)`). Estos últimos NO se simulan en esta candidata.

## Compatibilidad fundamental

El código previo `a(f,g) = ~code -> f+g`, `b = a(10,)!`, `f = a!` conserva vinculación parcial y capturas. Los bloques de control existentes, módulos, Arrays, ValuePacks, Logic y Math NO se reinterpretan.

## Verificación Windows / PowerShell

1. `cargo check --all-targets`
2. `cargo test --test objetos_firmas_etapa1_tests -- --nocapture`
3. `cargo test --all-targets`
4. `./VERIFICAR_ETAPA1_OBJETOS.cmd` o ` .\VERIFICAR_ETAPA1_OBJETOS.cmd ` desde PowerShell.
5. ` .\EJECUTAR_QA_INTEGRAL.cmd ` si está presente.

No se pudo compilar en el entorno de empaquetado por ausencia de `cargo` y `rustc`. La presencia del código y tests no garantiza compilación ni resultados.
