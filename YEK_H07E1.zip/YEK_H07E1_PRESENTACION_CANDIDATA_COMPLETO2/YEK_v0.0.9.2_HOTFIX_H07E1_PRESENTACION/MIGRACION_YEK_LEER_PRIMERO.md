# YEK — Migración integral de identidad y control (2026-10-17)

## Estado

**Base:** archivo adjunto `YersCode_v0.0.9.2_ETAPA_D_CONVERSIONES_UCS_HOTFIX_H02_RUST_TEST_QUOTES(1).zip`.

**Entrega:** proyecto reestructurado como `YEK_v0.0.9.2_MIGRACION_INTEGRAL`.

**Advertencia de validación:** esta entrega tiene controles estáticos y pruebas de regresión añadidas, pero **no ha sido compilada ni ejecutada**. En este entorno no están disponibles `cargo` ni `rustc` y el host no permite descargar el compilador. No debe asumirse que todas las suites antiguas pasan sin ejecutar `cargo test`.

## Cambios oficiales

| Antes | Ahora |
|---|---|
| YersCode | **YEK** |
| Fuentes `.yc` | **`.yek`** |
| Binario `yc` | **`yek`** |
| Crate Rust `yerscode` | **`yek`** |
| Módulos `@stdlib/math.yc` | **`@stdlib/math.yek`** |
| Variable de color `YERSCODE_COLOR` | **`YEK_COLOR`** |
| `~for` | **`for`** |
| `~if` | **`if`** |
| `~orif` | **`orif`** |
| `~else` | **`else`** |

Los bloques de control siguen dependiendo de las reglas de indentación y de la aridad de YEK. Se mantuvieron los modos `~code`, `~text`, `~math`, `~logic`, las capturas `~struct`/`~class`, `~block`, las entradas `~auto`/`~str`/`~num`/`~bool` y las declaraciones `~import`/`~export`.

### Ejemplo actualizado

```yek
~code
"Hola YEK"!

x=4
if(x>5)
    "mayor"!
orif(x==4)
    "igual a cuatro"!
else
    "menor"!

for(i in 1..3)
    i!

pares=[for(n in 1..6) if(n%2==0)->n]
pares!
```

**Cambio incompatible intencional:** las formas antiguas con `~` de estas cuatro palabras clave ya no son válidas. Se añadió un diagnóstico explícito para las líneas estructurales antiguas. `for`, `if`, `orif`, `else` quedan reservadas como palabras clave y no deben usarse como nombres de variables. Las palabras que solo empiezan igual (`format`, `iffy`) siguen disponibles.

### Dónde se aplicó

- Archivo `Cargo.toml`, crate/binary, imports y pruebas Rust.
- Analizador de alto nivel (`src/source.rs`), lexer (`src/lexer/lexer.rs`, `src/lexer/token.rs`) y parser de expresiones (`src/parser/mod.rs`).
- Imports, módulos locales y estándar (`src/modules.rs`, `src/module_tools.rs`) y CLI (`src/main.rs`).
- Todos los ejemplos y casos de prueba `.yc` de la base migrados a `.yek` (1073), además de un nuevo ejemplo.
- Scripts `.cmd`, `.ps1` y `.sh`, manifiestos JSON, pruebas esperadas, documentación Markdown y PDF histórico de 26 páginas (199 sustituciones tipográficas).
- Nueva suite `tests/yek_migration_tests.rs` con pruebas de palabras clave, productores, diagnósticos y módulos `.yek`.

### Validación de la entrega

Prueba estática que sí puede ejecutarse sin Rust:

```bash
python tools/VERIFICAR_MIGRACION_YEK.py
```

**Validación imprescindible en tu máquina, desde la raíz del ZIP:**

```bash
cargo build
cargo test
cargo run -- check examples/YEK_primera_guia.yek
cargo run -- run examples/YEK_primera_guia.yek
cargo run -- tokens examples/YEK_primera_guia.yek
```

En Windows PowerShell ejecuta los mismos comandos con Rust instalado y disponible en PATH.

**Antes de eliminar tu copia anterior:** revisa `cargo test` y los scripts QA específicos. Si alguna prueba falla, conserva el ZIP original para comparar el comportamiento, las expectativas y los mensajes de error. No se ha asegurado compatibilidad ejecutable con extensiones `.yc` ni sintaxis `~for`/`~if` previas.

### Observaciones

- El `Cargo.toml` original declaraba la versión `0.0.9-alpha.0`, mientras que el archivo recibido identificaba la distribución como 0.0.9.2. No se cambió artificialmente la versión del paquete sin una decisión de publicación.
- Se conservaron nombres de pruebas que incluyen números de etapas antiguas (`v008`, etc.) porque son identificadores históricos de regresión, no el nombre del lenguaje.
- El PDF antiguo se migró tipográficamente y se conserva como **documento histórico**, no como especificación actual definitiva.
- El script de comprobación estática no reemplaza compilación ni pruebas de ejecución.
