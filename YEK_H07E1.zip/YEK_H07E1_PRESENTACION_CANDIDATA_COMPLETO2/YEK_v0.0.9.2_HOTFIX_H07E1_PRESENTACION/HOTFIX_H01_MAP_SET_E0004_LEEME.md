# YEK v0.0.9.2 Etapa B — HOTFIX H01 (E0004)

Base: Etapa B MAP/SET candidata. Corrige los dos `match` no exhaustivos del archivo `src/interpreter/mod.rs` al incorporar Map, Set, Entry y View.

- `runtime_value_references_call`: recorre las claves y celdas de Map, los elementos de Set, los dos lados de Entry y las celdas de View. Inspecciona tambien los valores anidados y rechaza conservadoramente IDs de celda ausentes. Mantiene la proteccion contra referencias a variables locales que escapan de una llamada.
- `render_contract_value`: rechaza explicitamente Map, Set, Entry y View como valores de contrato directos. Los contratos que ya aceptaban numeros, texto, booleanos y rangos conservan sus reglas.
- Cinco pruebas unitarias Rust nuevas para las rutas corregidas. Se conservan las 83 pruebas de Etapa B y todas las pruebas anteriores.

## Validacion en PowerShell desde el directorio de Cargo.toml

```powershell
cargo check --all-targets
cargo test --lib map_set_exhaustive_hotfix_h01_tests -- --nocapture
cargo test --test colecciones_universales_v0092_etapa_b_map_set_tests -- --test-threads=1 --nocapture
cargo test --test colecciones_universales_v0092_etapa_a_tests -- --test-threads=1 --nocapture
cargo test --all-targets
```

**Estado:** comprobacion estructural del ZIP, pero no compilado con Cargo en este entorno. No declarar estable hasta verificar en Windows.
