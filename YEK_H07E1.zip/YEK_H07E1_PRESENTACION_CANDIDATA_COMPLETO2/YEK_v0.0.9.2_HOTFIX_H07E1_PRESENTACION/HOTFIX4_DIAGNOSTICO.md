# YEK v0.0.8.4 — Hotfix 4: productores dentro de expresiones `break(...)`

## Incidencia reproducida en PowerShell

Una de las 18 pruebas de `arrow_multivalor_regresion_tests.rs` falló con:

```
2:1: unterminated parenthesized/Array Code expression
```

Programa implicado:

```yek
a,b,c=for(x=1..10)
    break(for(y=1..2)->y,99)
a!b!c!
```

Salida prevista:

```
1
2
99
```

## Causa raíz

`SourceParser::collect_code_fragment` usaba `scan_code_line_for_fragment`,
que consideraba **cualquier `~` fuera de cadenas** como inicio de un comentario.
La línea `break(for(y=1..2)->y,99)` quedaba truncada a `break(`,
eliminando el paréntesis de cierre. El lector buscaba un cierre hasta el fin del archivo.
No era un defecto de la operación `break` ni de sus valores de retorno: el parser
nunca recibía una línea completa.

## Corrección en `src/source.rs`

`scan_code_line_for_fragment` ahora reconoce los productores `for` y sus filtros
`if` cuando aparecen en una **posición sintáctica de expresión** y mantiene
la semántica de comentario para los otros usos de `~`. Esta detección no depende
de nombres específicos de variables, de la cantidad de retornos ni del número de
iteraciones. Las comillas siguen protegidas frente al reconocimiento de `~`.

Este mismo escáner se usa para expresiones Code normales y para Code capturado;
no se añadió ningún parche al evaluador de `break`, que ya expandía correctamente
los valores una vez recibida una expresión completa.

## Pruebas añadidas

- Dos pruebas unitarias en `src/source.rs` para la distinción comentario/productor
  y el cierre equilibrado de `break(...)`.
- Nueve casos de regresión en `tests/arrow_break_nested_regression_tests.rs`:
  productor al principio, después de coma, multilínea, filtro, combinación con
  división estructural y ValuePack, comentarios, cadenas, Arrays y profundidad 2.
- Se preservan las 18 pruebas anteriores de `arrow_multivalor_regresion_tests.rs`
  y toda la batería histórica.

## Verificación en Windows PowerShell

Desde la carpeta que contiene `Cargo.toml`:

```powershell
cargo test --test arrow_multivalor_regresion_tests -- --nocapture
cargo test --test arrow_break_nested_regression_tests -- --nocapture
cargo test
cargo check
```

**Estado:** el ZIP y los archivos Rust se han revisado estáticamente, pero **no**
se ha ejecutado `cargo test` en el entorno de empaquetado, donde no hay `cargo`
ni `rustc`. Estas pruebas deben ejecutarse en tu máquina antes de considerar
estable la versión.

La prueba costosa del productor infinito permanecerá `ignored` por defecto.
