# YEK v0.0.9.2 — Hotfix H02: salida de cadenas activas

**Base exacta:** `YEK_v0.0.9.2_HOTFIX_H01_COMENTARIOS.zip`.

## Incidencia

En el código original, `"hola"!` y `"Hola, mundo\!"!` entraban en `active_string_statement()`; el `!` externo se convertía incorrectamente en `ActivePart::AnonymousOutput`. El motor ya había impreso el texto y después intentaba obtener un valor anónimo inexistente, provocando un error.

## Regla que adopta H02

- `"hola"` y `"hola"!` imprimen exactamente una vez `hola`.
- `"Hola, mundo\!"` y `"Hola, mundo\!"!` imprimen `Hola, mundo!`.
- **Dentro de comillas** el `!` sin escapar sigue siendo un operador activo: `"YEK!"` evalúa la variable `YEK` y debe fallar si no existe. `"YEK!"!` sigue aplicando esa misma regla.
- `"x!"!` sigue activando `x` si está definida.
- `"n =?"!` sigue recogiendo una entrada anónima y mostrándola; no se descarta el `!` posterior cuando la cadena contiene una operación de entrada `?`.
- Un segundo `!` (`"hola"!!`) sigue siendo una operación anónima y necesita un valor anónimo disponible.
- El operador `!` independiente, los `a!` y las cadenas pasivas asignadas (`texto="..."`) no se modifican.

## Archivos cambiados

- `src/parser/mod.rs`: corrección localizada en el analizador de cadenas activas.
- `tests/active_string_literal_bang_hotfix_h02_tests.rs`: **22 pruebas Rust** nuevas, incluyendo casos de retrocompatibilidad.
- `EJEMPLOS_H02_CADENAS_ACTIVAS/`: 13 ejemplos manuales (9 de éxito y 4 errores esperados).
- `VERIFICAR_H02_CADENAS.cmd`: atajo Windows para la batería H02.
- Este README y el inventario SHA-256.

No se cambió el VSIX, el lexer, los demás operadores, las colecciones ni los módulos.

## Verificación en Windows

Descomprime el nuevo ZIP completo, abre su carpeta raíz (donde está `Cargo.toml`) y ejecuta:

```powershell
cargo build
cargo test --test active_string_literal_bang_hotfix_h02_tests
cargo test
cargo run -- run EJEMPLOS_H02_CADENAS_ACTIVAS/02_escape_con_bang.yek
```

Para el archivo anterior E1-031, modifica el código a `"Hola, mundo\!"!` y vuelve a ejecutar. El caso E1-271 `"YEK!"` **debe** seguir dando error si `YEK` no existe.

**Otros dos resultados del reporte:** E1-108 y E1-110 informan `os error 2` (archivo no encontrado); sus rutas sí están dentro del ZIP original de 385 pruebas. Comprueba la extracción y la existencia física en disco, no son evidencia de un fallo del motor.

## Alcance de validación

Los cambios han sido inspeccionados y el ZIP validado estructuralmente, pero no se ejecutó Cargo en este entorno porque aquí no están disponibles `cargo` ni `rustc`. La prueba funcional definitiva se hará en tu computadora. Si aparece un fallo nuevo, envía la salida de la suite H02 y de `cargo test`.
