# H07 — Iteración universal, introspección y referencias seguras

Base: H06G (proyecto completo, sin modificaciones al significado de rangos Unicode ni contratos `~in`).

## Nuevas reglas

- `texto.num` o `texto.num()` devuelve el punto de código de exactamente **un escalar Unicode**. Textos vacíos, compuestos por varios escalares y receptores de otros tipos producen un error controlado.
- `valor.type` o `valor.type()` devuelve una etiqueta canónica Text para todas las variantes de valor. Capturas Code y constructores no se ejecutan al inspeccionarlos.
- `[for(x=1..3)->x,x*x]` produce dos valores por iteración; `[for(x=1..3)->(x,x*x)]` conserva un ValuePack por iteración. Las comas posteriores a `->` pertenecen al productor hasta su delimitador de cierre.
- `for(x in texto)` recorre escalares Unicode; su fuente no es mutable por referencia. Funciona también con indexador `for(i,x in texto)` y con productores.
- Los iteradores sincronizados recorren la longitud máxima. Las fuentes más cortas proporcionan `none` **por valor**. No se permite pedir referencia `!` cuando falta una celda.
- `for((clave,valor!) in mapa)` enlaza `valor` a la celda original del Map. Las claves son inmutables. `for((clave,valor) in mapa)` sigue entregando copias. `for(i,entrada in mapa)` continúa entregando índice y Entry de lectura.

## Compatibilidad deliberadamente modificada

Las pruebas históricas que esperaban error por longitud desigual se han actualizado (`v008_2_tests.rs`, `qa_realista_tests.rs`, `qa_exhaustiva_fixtures_tests.rs`). Las reglas de referencias, ValuePack, Map y Unicode previamente aprobadas continúan vigentes.

## Integración de editor

VS Code v1.3.2 añade coloreado y snippets de `.type` / `.num`, productores múltiples y Map. Se conserva la ejecución por Cargo.

## Seguridad

No se inventan celdas para referencias faltantes, no se mutan claves de Map, ni se permite alterar una cadena mediante el binder de caracteres. No se cambia el tratamiento de `~in(...)`.

## Limitaciones de validación

**Este entorno no dispone de Rust/Cargo ni acceso de red para instalarlo.** El código se revisó estáticamente, pero la compilación y la regresión funcional aún deben ejecutarse en Windows antes de aceptar H07.
