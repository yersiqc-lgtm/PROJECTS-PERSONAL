# H06A — Rangos sin ambigüedad

- Parser: todos los extremos dinámicos por valor exigen agrupación explícita.
- Bucle `for`: el extremo derecho agrupado `(x!)` sigue siendo referencia viva.
- `~in`: distingue dominios literales de caracteres y extremos dinámicos agrupados; los nombres numéricos desnudos dentro de rangos reciben error.
- `~in` con límites `str` de un carácter admite capturas `(a)`/`(a!)`, congeladas o vivas.
- Actualizadas las pruebas H06 afectadas y su laboratorio.
- Nuevas 40 pruebas Rust y 40 programas `.yek`, con ejecutor y reportes.
- `src/source.rs` / formatos tradicionales ContractPack: sin cambios.
- Extensión VS Code v1.3.0: incluida sin cambio de versión; las nuevas agrupaciones usan tokens que ya colorea.
- No se ha podido ejecutar Cargo en este entorno; pendiente verificar.
