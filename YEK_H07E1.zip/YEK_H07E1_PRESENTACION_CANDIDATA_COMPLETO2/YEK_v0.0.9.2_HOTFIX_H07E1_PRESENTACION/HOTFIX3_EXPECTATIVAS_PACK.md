# YEK v0.0.8.5 — Hotfix 3: representacion canonica en pruebas

## Motivo

El caso `metamorfica_desnudo_y_encapsulado` fallaba con `n=1` porque
el programa producia correctamente `(0, 1, [1], (1,), 99)` y el oraculo
esperaba `(0, 1, [1], (1), 99)`.

## Cambios

- `tests/qa_realista_tests.rs`: oraculo parametrico corregido.
- `tests/composicion_generativa_tests.rs`: reemplazada duplicacion de
  la regla de impresion por una utilidad compartida.
- `tests/support/pack_format.rs`: una unica funcion que formatea las
  expectativas de ValuePacks de 1 o mas elementos y dos pruebas unitarias.
- `src/`: **sin cambios**. El motor ya imprime el ValuePack unitario como `(1,)`.

## Comprobacion en PowerShell

```powershell
cargo test --test qa_realista_tests -- --nocapture
cargo test --test composicion_generativa_tests -- --nocapture
cargo test
cargo check
```

Un `ignored` en las pruebas de estres es intencional y no supone fallo.

**Estado:** el ZIP y su contenido se revisaron estaticamente; en este entorno
no hay Cargo/Rustc y no se afirma que las pruebas se hayan ejecutado aqui.
