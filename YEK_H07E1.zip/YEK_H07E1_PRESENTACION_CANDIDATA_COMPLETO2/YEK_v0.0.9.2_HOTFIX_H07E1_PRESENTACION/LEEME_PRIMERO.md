# YEK — Megabatería QA: Segunda Entrega HOTFIX H02

Esta entrega contiene **161 programas `.yek`**, cada uno con resultado esperado o un fragmento del error que debe producir. Hay **113 pruebas de regresión** inspiradas en casos comprobados por las suites previas de YEK y **48 casos exploratorios** nuevos.

**Aviso:** los casos de regresión se derivaron de pruebas que ya pasaron en fases anteriores, pero este paquete nuevo no se ha ejecutado aquí con Rust/Cargo. Los casos exploratorios **no están certificados**: algunos pueden fallar por bugs o por reglas aún no definidas. No cambies el lenguaje ni la expectativa sin analizar primero la causa.

## Instalación en Windows

1. Extrae el ZIP. Copia `QA_ENTREGA2_H02`, `tests` (fusiona su contenido) y los ejecutores al directorio principal que contiene `Cargo.toml` de **YEK v0.0.9.1 Entrega 2 HOTFIX H02**.
2. Ejecuta `cargo test --test qa_h02_sintaxis_universal_tests -- --nocapture` para los casos de regresión; los exploratorios aparecerán como `ignored`.
3. Ejecuta `cargo test --test qa_h02_sintaxis_universal_tests -- --ignored --nocapture` para las exploratorias, si quieres buscar errores nuevos.
4. Ejecuta `cargo test --all-targets` para comprobar también la suite histórica completa.
5. Opcional: `EJECUTAR_QA_H02.cmd` realiza las comprobaciones y la suite histórica; `EJECUTAR_QA_H02.cmd -Exploratorio` también ejecuta los casos experimentales.

Para ejecutar un solo ejemplo (desde el directorio de Cargo.toml):

```powershell
cargo run --bin yek -- QA_ENTREGA2_H02/casos/001_codigo_silencioso.yek
```

Los casos con entrada `?` tienen archivo `.entrada.txt` con datos de prueba. Los casos con `.error_esperado.txt` **deben fallar de forma controlada**. Para estos, no compares la salida normal: comprueba el fragmento del error indicado.

## Cómo interpretar un fallo

- **Fallo de regresión:** un comportamiento ya cubierto por las pruebas históricas está roto o el nuevo fixture no reproduce exactamente la sintaxis probada. Compara con el test Rust original.
- **Fallo exploratorio:** es una hipótesis, no una promesa de soporte. Averigua si hay bug, ambigüedad semántica o una funcionalidad todavía no acordada.
- **Error distinto del esperado:** revisa el archivo `.yek`, el error completo y la primera línea/columna. Es especialmente útil para evaluar diagnósticos.
- **Crash, cuelgue o desbordamiento:** incidente prioritario, conservar el caso mínimo reproducible.

## Organización

`QA_ENTREGA2_H02/casos/`: casos autocontenidos con salidas esperadas; `QA_ENTREGA2_H02/modulos/`: proyectos multifichero; `QA_ENTREGA2_H02/manifest.json`: metadatos legibles por herramientas; `tests/qa_h02_sintaxis_universal_tests.rs`: verificación con la API de YEK, sin interpretación imprecisa del texto de la terminal; `QA_ENTREGA2_H02/CATALOGO_COMPLETO.md`: índice numerado de todos los casos.

**Nota importante sobre referencias e identidad:** los programas sobre copias/alias de Class exploran las reglas existentes. No confundas referencias a celda (`!`) con identidad de la instancia. En las pruebas marcadas exploratorias, las expectativas pueden exigir revisar el contrato del lenguaje antes de modificar su implementación.
