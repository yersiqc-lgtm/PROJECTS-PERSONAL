# Comprobación manual del Hotfix H03 — Etapa 2

Los archivos `H03-01` a `H03-37` están separados para poder usar **YEK: Ejecutar archivo actual** desde VS Code. El inventario enumera las salidas o diagnósticos previstos. Un error en una prueba marcada `ERROR` significa que el motor ha rechazado correctamente la entrada; verifica que no sea un cierre inesperado.

- `H03-03`: proporciona la entrada `7` cuando se solicite.
- `H03-25` y `H03-26`: imprimen códigos ANSI ESC; los colores dependerán de la terminal. El inventario representa ese byte como `<ESC>`.
- `H03-34`: contiene intencionadamente un BOM UTF-8 al inicio para comprobar su tratamiento.
- `H03-30`, `H03-35` y `H03-36`: **deben seguir dando error** porque `!` dentro de comillas sigue siendo un operador activo.
- Los escapes operan en cadenas entre comillas. `~text` continúa siendo **texto crudo** y no debe decodificar `\n` o `\t`.

Para validar automáticamente las 47 regresiones incluidas en Rust:

```powershell
cargo test --test etapa2_hotfix_h03_modos_unicode_escapes_tests
cargo test
```
