# YEK v0.0.9.2 H03B — Ajuste de pruebas tras ampliar los escapes

## Diagnóstico

`cargo test --test runtime_tests` informó 67 éxitos y 1 fallo:
`unknown_string_escape_is_reported_in_english`.

La prueba anterior esperaba `unknown escape sequence` para `"hello\x"`. Esa
expectativa era válida antes de H03, pero H03 incorporó la forma `\xHH` (dos
dígitos hexadecimales). Ahora `\x` se reconoce como escape incompleto y el
motor debe mostrar `\x requires 2 hexadecimal digits`.

## Corrección aplicada

**Único archivo de código cambiado:** `tests/runtime_tests.rs`.

- Prueba de escape desconocido actualizada de `\x` a `\q`.
- Nueva prueba: `\x` exige dos dígitos hexadecimales.
- Nueva prueba: `\xG1` rechaza dígitos incorrectos sin pánico.
- Nueva prueba: `\x21` produce `!` correctamente.

**No hay cambios en `src/`, CLI, VSIX, lexer, parser, interpretación de
cadenas ni dependencias.** Se conserva íntegro el Hotfix H03A.

## Pruebas en Windows

Desde la carpeta que contiene `Cargo.toml`:

```powershell
cargo build
cargo test --test runtime_tests
cargo test --test etapa2_hotfix_h03_modos_unicode_escapes_tests
cargo test
```

## Alcance de la verificación

Se revisó el código de `src/escapes.rs` y la prueba Rust, además de verificar la
integridad del ZIP. **No se ejecutó Cargo en el entorno de empaquetado**.

## Migración rápida

Si ya tienes H03A, copia únicamente `tests/runtime_tests.rs` de la versión H03B
o utiliza el archivo ZIP con solo los cambios. No es necesario tocar el motor.
