# YEK H06A · Extremos de rangos explícitos

## Regla nueva (cambio incompatible intencional)

- Variables usadas **por valor** en rangos normales: `0..(x)` y `(a)..(b)`.
- Referencias vivas: `0..x!`, `0..(x!)`, `a!..b!` y `(a!)..(b!)`.
- Números literales: `0..5`, `-2..5`, `0..` y `..3` siguen sin paréntesis.
- Las expresiones calculadas que dependen de variables deben agruparse: `(a+1)..(b*2)`.
- Accesos, propiedades y llamadas no activadas requieren grupo: `(arr[0])..5`.
- `a..b`, `0..x`, `x..10`, `x+1..9` dejan de ser sintaxis válida en el parser de expresiones. El mensaje señala los paréntesis o el `!`.
- En rangos vivos de `for`, `(x!)` conserva identidad de celda y **no** equivale a `(x)`.

## Ejemplo

```yek
~code
a=1
b=5
v=((a)..(b))
v!
```

Resultado previsto: `(1, 2, 3, 4, 5)`. Si escribes `v=(a..b)`, obtendrás un error controlado de sintaxis de rango.

## Contratos unificados

```yek
~in(num=(a)..(b))    ~ dominios numéricos dinámicos capturados por valor
~in(num=a!..b!)      ~ referencias vivas sin agrupación
~in(num=(a!)..(b!))  ~ referencias vivas con agrupación
~in(str=a..z)        ~ rango literal de caracteres a-z
~in(str=(a)..(b))    ~ variables de un carácter cada una
~in(auto=a..z)       ~ rango literal de caracteres
~in(auto=(a)..(b))   ~ valores de variables, no letras literales
```

No se permite evaluar expresiones arbitrarias en los extremos de `~in`: las capturas dinámicas admitidas son nombres individuales, con `()` o `!`, por seguridad.

## Compatibilidad heredada

Los ContractPack antiguos, como `rules=(a..z,[2..4])`, conservan la ruta heredada por tener un marcador inequívoco de contrato. Para proyectos nuevos se recomienda `~in(str=a..z,len=2..4)`. La sintaxis de rangos explícitos para código ordinario es obligatoria.

La antigua batería de Etapa 6 anterior a H06A contiene ejemplos `0..variable` que deberán migrarse antes de utilizarla para la nueva especificación. La batería de H06 y la nueva suite de 40 casos están adaptadas en este proyecto.

## Verificación

Desde la raíz del proyecto ejecuta:

```powershell
cargo build
cargo test --test etapa6_h06a_rangos_explicitos_tests
cargo test --test etapa6_h06_migracion_unificada_tests
cargo test
py -3 EJEMPLOS_H06A_RANGOS_EXPLICITOS/ejecutar_h06a.py
py -3 EJEMPLOS_H06_UNIFICADO/ejecutar_h06.py
```

**Limitación:** la preparación no tiene Cargo disponible; aún no está compilado/validado con Rust real. Es un candidato H06A.
