@echo off
cd /d "%~dp0"
echo === YEK v0.0.8.5: nueva gramatica y QA integral ===
cargo test --test sintaxis_clara_v0085_tests -- --nocapture
if errorlevel 1 goto failure
cargo test --test qa_exhaustiva_fixtures_tests -- --nocapture
if errorlevel 1 goto failure
cargo test
if errorlevel 1 goto failure
cargo check
if errorlevel 1 goto failure
echo.
echo Revision de pruebas terminada sin errores.
pause
exit /b 0
:failure
echo.
echo Hubo una prueba fallida. Revisa el mensaje anterior.
pause
exit /b 1
