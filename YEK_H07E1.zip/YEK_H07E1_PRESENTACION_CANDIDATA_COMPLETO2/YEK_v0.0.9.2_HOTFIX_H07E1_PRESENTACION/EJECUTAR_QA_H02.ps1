param([switch]$Exploratorio, [switch]$Historico, [switch]$SoloQA)
$ErrorActionPreference='Stop'
Set-Location $PSScriptRoot
if (-not (Test-Path 'Cargo.toml')) {
  Write-Host 'Coloca el contenido del ZIP dentro de la carpeta que contiene Cargo.toml.' -ForegroundColor Red
  exit 2
}
Write-Host 'YEK QA segunda entrega / HOTFIX H02' -ForegroundColor Cyan
cargo check --all-targets
if ($LASTEXITCODE -ne 0) {exit $LASTEXITCODE}
cargo test --test qa_h02_sintaxis_universal_tests -- --nocapture
if ($LASTEXITCODE -ne 0) {exit $LASTEXITCODE}
if ($Exploratorio) {
  cargo test --test qa_h02_sintaxis_universal_tests -- --ignored --nocapture
  if ($LASTEXITCODE -ne 0) {exit $LASTEXITCODE}
}
if ($Historico -or (-not $SoloQA)) {
  cargo test --all-targets
  if ($LASTEXITCODE -ne 0) {exit $LASTEXITCODE}
}
Write-Host 'QA finalizada correctamente.' -ForegroundColor Green
