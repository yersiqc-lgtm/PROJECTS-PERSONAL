# Núcleo recursivo — HOTFIX H01 (desbordamiento de pila nativa)

## Diagnóstico

La versión candidata previa comprobaba `frames.len() > 128` antes de invocar Code. Esta comprobación llegaba **demasiado tarde** en Windows: cada llamada del intérprete anida varias funciones Rust que consumen pila nativa. La prueba `runaway_recursion_has_controlled_error` finalizaba el proceso con `STATUS_STACK_OVERFLOW (0xc00000fd)` en vez de devolver un error de YEK.

## Modificación

- `src/interpreter/mod.rs`, función común `invoke_code`: contador de marcos Code activos (`call_id.is_some()`) con un máximo prudente de **20 llamadas simultáneas**.
- El umbral se comprueba **antes** de crear el nuevo marco y funciona tanto con llamadas directas como indirectas, con parámetros nombrados, métodos, Code `pure,cache` y bloques operativos.
- El error conserva el contrato de la prueba histórica: `maximum recursive call depth (20) exceeded`.
- No se modifica la gramática, la captura léxica, los resultados ni el resto de funciones del lenguaje.

**Limitación honesta:** no hay garantía de seguridad de pila absoluta para cualquier ruta de evaluación o tamaño de pila. El límite 20 prioriza el funcionamiento en pilas relativamente pequeñas, como las de hilos de pruebas de Windows. La recursividad más profunda y eficiente requiere migrar el evaluador a una pila explícita, o aplicar una optimización comprobable de llamadas de cola. Aumentar la pila del proceso no es una reparación general.

## Verificación en Windows

Desde el directorio con `Cargo.toml`:

```powershell
cargo check --all-targets
cargo test --test recursion_stack_safety_hotfix_h01_tests -- --test-threads=1 --nocapture
cargo test --test nucleo_recursion_importacion_v0091_tests -- --test-threads=1 --nocapture
cargo test --all-targets
```

Luego opcionalmente repetir las nuevas suites sin `--test-threads=1` para comprobar ejecución paralela. La última etapa puede revelar otras regresiones; informar el primer fallo completo.

**Validación de preparación:** no se ha ejecutado `cargo` ni `rustc` en este entorno. El paquete se entrega como candidata HOTFIX para validación local.
