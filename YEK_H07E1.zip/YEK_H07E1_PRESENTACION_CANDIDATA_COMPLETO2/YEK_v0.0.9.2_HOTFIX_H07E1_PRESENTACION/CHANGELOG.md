# YEK v0.0.9.0 — Hotfix 1 (fuentes componibles)

- Corregida la deteccion de comentarios en encabezados de control con productores anidados.
- Unificado el escaneo de `for` en sentencias con el mismo mecanismo usado en expresiones.
- Nuevo test `for_fuentes_componibles_v0090_hotfix1_tests.rs` y ejemplos.
- `for(x in ...)` sigue siendo forma principal; `for(x=...)` se conserva temporalmente.
- No se modificaron las reglas de evaluacion de Arrays o Packs: un array anidado se mantiene anidado.
- Extension v0.3.7 destaca `in` exactamente como `as`.

**Compilacion Rust pendiente:** este entorno no incluye cargo/rustc. Ejecutar `cargo test` en Windows.

## v0.0.8.9 — Hotfix 5: expectativa de salidas TXT con salto final (12-oct-2026)

- Ajustada una expectativa histórica de `Interpreter::run()` que confundía
  una cadena con `\n` incrustado con dos líneas de salida.
- El TXT conserva su salto final. La impresión con `!` agrega otro salto.
- Se añadieron comprobaciones de salida exacta `run_with_io` para recursos TXT
  con y sin salto de línea final.
- No se ha cambiado el motor Rust ni la semántica del lenguaje.
- Ver `HOTFIX5_SALIDA_TXT.md`.

## v0.0.8.5 — desigualdad explícita y ValuePack unitario canónico

- El comparador `<>` sustituye a `!=` en la gramática de expresiones.
- La secuencia legacy `!=` se rechaza con diagnóstico de migración: usar `<>` o `! =` según intención.
- La notación `!` para referencias, activación y salida no cambia.
- Un ValuePack de un elemento se imprime `(x,)`, distinto de la agrupación `(x)`.
- Se armonizan `Value::Display` y `render_value`, sin modificar el AST de Pack.
- Se corrigen 18 discrepancias del QA integral: 14 encabezados de referencias,
  dos casos de packs unitarios, dos casos de entrada.
- Las pruebas originales de desigualdad se migran a `<>` y se añaden 14 nuevas pruebas
  de compatibilidad, tipos, producción, referencias y diagnósticos.
- La compilación y la ejecución completa de tests deben verificarse con Cargo.

## Hotfix 4 — 2026-10-11 — Escaneo de productores dentro de `break(...)`

- Evita que `for` dentro de una expresión Code se trate como comentario,
  provocando paréntesis artificialmente abiertos.
- Generaliza la distinción productor/comentario para posiciones de expresión,
  incluido `->for` y el filtro `if` posterior a un productor.
- Añade nueve pruebas de integración y dos pruebas unitarias de escaneo.
- Mantiene el resto de la semántica, incluidos los retornos múltiples y la
  validación de aridad.
- Pendiente de validación con Cargo en Windows.

## v0.0.8.4 — Hotfix 2 (suite QA)

- Corrige una prueba negativa obsoleta: la repetición `ValuePack * entero`
  ahora es válida, por lo que la expectativa antigua era incorrecta.
- Conserva el caso antiguo como prueba positiva con salida explícita.
- Sustituye E04 por una operación inversa no soportada (`Number * ValuePack`).
- Añade E09 para rechazar multiplicadores de tipo Array.
- **Sin cambios en el motor del lenguaje**: la corrección afecta solo a pruebas,
  datos de QA y documentación.

# Changelog

## v0.0.8.4 candidato — nuevo motor de operadores

- `//` como token y operador de misma precedencia que `/`, `*` y `%`.
- `//` numérico con redondeo matemático hacia menos infinito.
- Despacho polimórfico sobre Number, Array y ValuePack.
- `+` concatenación o añadido, `-` eliminación de primera coincidencia,
  `*` repetición plana, `/` grupos equilibrados independientes,
  `//` prefijo divisible, `%` residuo de la cola.
- Unificación del receptor multivalor para `/` y `for`.
- Nuevas pruebas metamórficas y de composición cruzada, más QA realista.
- Pruebas históricas actualizadas cuando cambia el contrato de ValuePack.
- Limitación deliberada del crecimiento materializado.
- Pendiente verificación real de Cargo (no disponible en entorno generador).

## Candidato v0.0.8.3 - Composicion recursiva (SIN VALIDACION CARGO)

- Expresiones `for` anidadas en Array/ValuePack con header compartido.
- Expansion uniforme de valores desnudos para contenedores, retornos y argumentos.
- Filtro local `if` dentro de productores de expresion.
- Conservacion del analizador legacy para productores con cuerpo de instrucciones.
- Limites iniciales de anidamiento, elementos producidos y celdas.
- 22 pruebas del contrato activadas y matriz de pruebas generativas.
- Pendiente de compilacion/test real y evaluacion de compatibilidad.

# Changelog

## v0.0.8_2 hotfix 2

- Fixes grouped finite Range collection after the advanced producer refactor: `a=(1..10)` once again produces one ValuePack instead of triggering a multi-value scalar error.
- Preserves nested grouping and grouped Range items inside ordinary ValuePacks.
- Removes the unused `expression_contains_activation` helper so `cargo test` no longer emits the dead-code warning introduced by the v0.0.8_2 refactor.
- No language semantics were changed beyond restoring the already-defined v0.0.8_1 hotfix 2 behavior.

## v0.0.8_2

- Completes v0.0.8 on top of the user-verified v0.0.8_1 hotfix 2 base.
- Adds producing `for` assignments with direct multi-value, parenthesized ValuePack and Array collectors.
- Reuses `->` as the For production operator; it emits to the nearest receiving For and ends the current iteration.
- Adds `break(value...)`, including flat multi-value and explicit ValuePack forms.
- Adds all four Array value/reference iterator modes: element ref and/or live container ref.
- Makes Array elements addressable runtime cells so reference iteration mutates the actual source element.
- Adds live Range endpoints and live steps using the universal `!` reference rule.
- Adds explicit iterator destructuring, including mixed value/reference subpatterns.
- Adds synchronized iteration across N Arrays and the N+1 shared-index rule; unequal lengths are errors.
- Adds `~block` and `go` with block arguments, value/reference transport and same-Code boundary enforcement.
- Keeps `go`, `block`, and all new diagnostics free of release/version wording.
- Preserves v0.0.8_1 hotfix 2 Range assignment semantics: outside `for`, finite Range expands as multiple values and a comma is never a step.

## v0.0.8_1 hotfix 2

- Corrected ordinary finite Range semantics: outside `for`, `start..end` is a multi-value producer rather than a storable scalar Range.
- `a,b=0..1` now assigns `0` and `1`; `a=0..10` is an arity error.
- `a=(1..10)` now collects the generated values into one ValuePack.
- A comma outside `for` is never a Range step: `a,b,c=0..1,9` is three assignment values and `p=(1..3,9)` is `(1,2,3,9)`.
- Open Ranges cannot be expanded by ordinary assignment; consume them with `for`.
- Added regression tests for ascending/descending expansion, Pack collection, comma semantics, and open-Range rejection.

## v0.0.8_1

- Adds first-class `Range` values with finite, descending and open forms.
- Adds heterogeneous `Array` values while preserving `ValuePack` as a distinct type.
- Adds comparison operators `==`, `!=`, `<`, `<=`, `>`, `>=`.
- Adds integer `%` and strict Bool operators `and`, `or`, `not` with short-circuit semantics.
- Adds indentation-based `if(...)`, `orif(...)`, and `else`.
- Adds contextual `for`: infinite loop, exact repeat count, conditional loop, numeric/Range iteration, Array iteration, and index+value Array iteration.
- Adds destination-inclusive Range stepping; an endpoint is visited exactly once even when the final increment is shorter than the requested step.
- Adds exact decimal loop stepping through the existing rational Number backend.
- Adds open/infinite loop forms using `..`, `inf`, and `-inf`.
- Adds `break` and `continue` as reserved ordinary keywords.
- Adds LoopFrame-style binder scoping: loop-created binders do not escape and shadowed outer names are restored.
- Preserves v0.0.7_3 value/reference, CellID, DetachSelf, Code, contract and Bool-label semantics.
- Narrows ContractPack detection so ordinary Array/Range ValuePacks such as `(1..10,2)` and `([1,2],3)` remain normal data.
- Explicitly rejects advanced reference iteration, destructuring, synchronized iterators, For value production and `break(value)` until the advanced iteration delivery.
- Keeps user-facing diagnostics free of release/version names.

## v0.0.7_3

- Hotfix: keeps `num` reserved inside `<type=num>` so Bool contracts do not reinterpret the type keyword as a runtime variable.
- Generalizes `!` for data expressions: a bare value is passed/copied by value while `name!` transports the stable YEK cell reference.
- Adds pass-by-reference Code arguments; mutations inside Code affect the caller only for reference arguments. Exact `x=x` still detaches the parameter from the shared cell.
- Adds stable logical CellID output through `(name!)!` without exposing host/Rust process pointers.
- Adds full multiple assignment distinction: `a,b=(1,2)` destructures a ValuePack, `a=(1,2)` stores it, `a,b=1,2` assigns two RHS results, and `a=1,2` is an arity error.
- Makes bare contract identifiers snapshot values when the directive executes; `identifier!` captures a persistent cell reference. The reference survives later `name=name` detachment of the source name.
- Extends value/reference rules to ContractPacks, handler messages/fallbacks, attempts/type values and dynamic range endpoints.
- Removes loose unquoted character literals from `~str`; use quoted characters such as `"_"`, `","`, `"\""`. Static ranges such as `a..z` remain concise and unambiguous.
- Defines a one-character quoted `~str` item as an allowed-character constraint; longer quoted strings remain exact complete values. `[1]` can force an exact one-character string.
- Supports by-value dynamic String ranges with `(a)..(z)` and live-reference ranges with `a!..z!` / `(a!)..(z!)`, including redundant grouping.
- Makes `true` and `false` real Bool literals in normal YEK expressions.
- Allows quoted Bool contract spellings `"true"`, `"false"`, `"0"`, `"1"`; other quoted Bool spellings are rejected.
- Adds ContextFrame-local Bool output labels through `true="..."` and `false="..."`; these customize rendering only and do not redefine Bool values or parsing.
- Explicitly rejects taking a data reference to Bool literals (`x=true!`).
- Preserves v0.0.7_2 nested Work-mode behavior and all v0.0.6 reference/DetachSelf semantics.

## v0.0.7_2

- Completes the frozen v0.0.7 scope on top of the verified v0.0.7_1 hotfix 1 base.
- Adds runtime contract bindings through `identifier!`, resolved once per `?` acquisition and snapshotted across its retries.
- Supports dynamic attempts, messages, fallbacks, numeric/string range endpoints, maximum lengths and compatible `<type=...>` values.
- Adds structured ContractPack values and recursive ContractPack expansion without string eval.
- Adds ValuePack values and positional pack expansion in ordinary Code calls and BoundCode creation.
- Allows ordinary ValuePacks to supply compatible contract items.
- Makes multiline parenthesized Code fragments collect correctly for Packs and calls.
- Adds regression coverage for nested Work modes inside captured Code; local `~math`, `~text`, `~invalid` and nested captured Code do not affect the exterior context.
- Removes release/version names from user-facing unsupported-contract and floating-point error messages.
- Preserves the active-string trailing-digit fix and the explicit `Vec<String>` parameter annotation.
- Keeps `#` predicates, `~auto(...)`, arbitrary handler Code, NamePack and IEEE numeric types outside the committed v0.0.7 core.

## v0.0.7_1

- Built directly on v0.0.6 hotfix 2; keeps its active-string trailing-digit fix and explicit `Vec<String>` parameter annotation.
- Allows ordinary double-quoted strings to span physical lines; active/passive behavior remains context-dependent exactly as before.
- Makes the high-level Code source scanner string-aware so Work directives inside multiline strings remain literal content.
- Formalizes a local `ContextFrame` input state for every Code invocation; every call starts with `Input=Auto` and local Input directives do not leak to the caller.
- Adds the orthogonal Input family: `~auto`, `~num`, `~str`, `~bool`, including inline forms such as `~num age?`.
- Adds the first native acquisition-contract engine shared by String, Number and Bool.
- Freezes attempts semantics: absent = 1, bare `<attempts>` = infinite, `<attempts=N>` = finite N.
- Separates per-attempt retry messages from final `none` / `warning` / `error` policies.
- Ensures final policy runs exactly once after attempts are exhausted.
- Adds implicit fallbacks `0`, `""`, `false`, explicit fallbacks and compile-time rejection of fatal error + fallback.
- Adds static String constraints: max/exact/ranged length, character/range unions, exact complete values, escaped characters, `string`/`char` subtype.
- Adds static Number constraints: exact rational value ranges, raw lexeme length, quoted exact mathematical values, `auto`/`int`/`decimal` subtype.
- Adds Bool values and contracts with string, numeric and explicit mixed encodings.
- Adds multiline contract directives.
- Runtime warnings use the same yellow ANSI label policy as compiler warnings when a terminal supports color.
- Adds a dedicated v0.0.7_1 regression suite and examples.

### Explicitly deferred to v0.0.7_2

- Dynamic contract values with `!` (`attempts=tries!`, dynamic message/fallback/range/length).
- Contract Packs and Value Packs.
- Advanced handler code execution.
- Static contract normalization/optimization beyond the base length intersection checks.
- Candidate predicate `#` remains outside the currently committed scope.

## v0.0.6 hotfix 2

- Keeps the hotfix 1 active-string maximal-munch fix for identifiers ending in digits (`result2!`, `value123!`, `value2?`).
- Corrects regression tests for adjacent active-string fragments.
- Restores `let mut params: Vec<String> = Vec::new();` in `src/source.rs`.

## v0.0.6

- Parameters on Code, explicit `->`, multiple returns, BoundCode / partial application.
- Persistent data aliases and exact `x = x` DetachSelf.
- Lifetime rejection for escaped local references.
- Source-aware diagnostics and warning/error colors.

Older history remains represented by the source/tests inherited from the previous releases.

### v0.0.7_1 hotfix 1
- Fixed the `warning_runs_only_once_after_attempts_are_exhausted` regression test so it follows the runtime diagnostic color policy instead of assuming plain text.
- No YEK language/runtime semantics changed: terminal warnings remain yellow when ANSI color is enabled and remain plain under `NO_COLOR` or non-TTY environments.

### v0.0.7_2 hotfix 1
- Corrected the dynamic-attempts regression test: the retry message is emitted for every rejected candidate, including the final rejected attempt before fallback.
- Removed an unnecessary-parentheses Rust warning in `src/input.rs`.
- No YEK language semantics were changed by this hotfix.

### v0.0.7_3 hotfix 2

- Fixed contract parsing so reserved numeric type names `float`, `f32`, and `f64` are not misclassified as bare runtime variables.
- Preserves dynamic type expressions such as `<type=kind>` / `<type=kind!>` while restoring the intended static IEEE floating-point diagnostic.
- Added a regression test covering all three reserved IEEE type names and ensuring diagnostics contain no release/version names.

### v0.0.8_2 hotfix 1

- Restored the finite-Range expansion helper used by assignment and collector contexts.
- Fixes Rust build errors at the three `Self::expand_finite_range_values(...)` call sites introduced while merging v0.0.8_1 hotfix 2 into the v0.0.8_2 interpreter.
- No YEK language semantics changed by this hotfix.

## Hotfix 1 — desambiguación ContractPack vs. expresiones binarias (2026-10-11)

- `src/source.rs`: antes se identificaba un ContractPack porque la RHS comenzaba
  con `(` y terminaba con `)`. Eso interpretaba `a=(1,2)+(3,4)` como un
  contrato de entrada y generaba el falso error `unmatched ')' in input contract`.
- El detector ahora comprueba que **un solo grupo parentizado ocupa toda la
  expresión**, respetando los delimitadores anidados, cadenas y caracteres
  escapados. Si existe cualquier operación posterior al cierre, la expresión
  pasa al parser normal. No hay excepciones para `+`, `//` ni `%`.
- Clasificación conservadora: errores de agrupación no son prueba de que la
  expresión sea un contrato; comparaciones como `x < 10` no deben confundirse
  con `<attempts=...>`. Se mantienen los manejadores de contratos con comas.
- `tests/contract_pack_disambiguation_tests.rs`: añade casos reales y una
  propiedad que genera diferentes combinaciones de `//` y `%`. Se incluyen
  pruebas unitarias para la clasificación y para contratos heredados.
- `tests/qa_realista_tests.rs`: elimina 8 advertencias de estilo `non_snake_case`
  sin cambiar los nombres de los archivos `.yek`.

**Verificación**: los registros originales enviados por el usuario muestran
10 pruebas de operadores correctas y 2 fallidas. Este hotfix corrige la causa
de esas dos fallas; la compilación y ejecución de Rust de la nueva variante
quedan pendientes porque `cargo`/`rustc` no están instalados aquí.

## Hotfix 3 — consistencia de productores inline y multivalor (11-oct-2026)

- Los productores `for(...) -> valor1,valor2` a nivel de RHS de asignación generan ambos valores **por iteración**; antes el segundo podía asignarse una sola vez fuera del bucle.
- Se aplica una regla de pertenencia de comas al AST, independiente del número de variables y de la cantidad de iteraciones.
- Las comas internas de Arrays, ValuePacks y llamadas conservan su significado previo, evitando regresiones composicionales.
- `break(...)` expande productores desnudos y divisiones estructurales de manera consistente con `->`.
- Nuevas regresiones en `tests/arrow_multivalor_regresion_tests.rs`; revisar HOTFIX3_PRODUCCION_MULTIVALOR.md.

## 0.0.8-alpha.7 (candidato, compilación aún pendiente)

- Token `.` propio y `Expr::Member` recursivo para nombres calificados y futuro sistema de registros/clases.
- Importación `~import(...)` con múltiples entradas, incluso multilínea.
- Importación selectiva con alias de `math.square`, `str.len` y `"archivo.yek".función`.
- Archivo `.txt` importado como dato, nunca ejecutado; máximo 8 MiB y UTF-8.
- Biblioteca inicial `stdlib/math.yek` desarrollada en YEK; módulo `str` con primitivas Rust.
- Ámbitos independientes, exportaciones explícitas, detección de ciclos y caché de módulos.
- Suite de regresión adicional para módulos, miembros, funciones y errores.
- La versión Rust no ha sido compilada en el entorno donde se preparó esta entrega.

## 0.0.8.9 — Entrega 2/2

- Nuevos comandos de inspección del API, árbol de dependencias y documentación Markdown (`yek inspect`, `yek deps`, `yek docs`).
- Sugerencias de exportaciones públicas ante nombres selectivos o miembros mal escritos.
- Ninguna herramienta de inspección ejecuta el código analizado.
- Pruebas `modulos_v0089_etapa2_tests.rs` y `VERIFICAR_ENTREGA2.cmd`.
- Actualización opcional de VS Code v0.3.4 para navegación y comandos de módulos.
- `except` y `lazy` siguen pendientes de una definición completa de inicialización/visibilidad.

## v0.0.8.9 Hotfix 2 — auto-public y entrada ejecutable

- Sin `~export`, el ámbito final de un módulo pasa a ser público automáticamente.
- Con `~export`, se mantiene la interfaz pública explícita (alias, reexportación y privacidad).
- Ahora se permite ejecutar directamente archivos `.yek` que contengan `~export`.
- La importación selectiva admite módulos sin exportaciones explícitas (comprobación en runtime).
- `inspect` y `docs` incluyen símbolos deducibles sin ejecutar el módulo y avisan de limitaciones.
- Migradas dos pruebas históricas al contrato nuevo; añadida una batería de regresión dedicada.
- Véase `HOTFIX2_VISIBILIDAD_AUTOMATICA.md`.

## v0.0.8.9 — Hotfix 3: importaciones sin alias y miembros de ruta literal

- Los nombres de archivo no necesitan ser identificadores YEK.
- Alias implícitos derivados de rutas (números, carpetas, espacios, caracteres especiales).
- Acceso por nombre de archivo `"archivo.yek".miembro` después de `~import`.
- Reexportación `~export "archivo.yek".miembro as nombre`.
- Múltiples alias comparten el módulo inicializado y las celdas públicas.
- Rutas literales técnicas no se filtran a la API automática de otros módulos.
- Pruebas de regresión y ejemplos: ver HOTFIX3_NORMALIZACION_IMPORTACIONES.md.


## v0.0.8.9 — Hotfix 4: miembros tipados, compatibilidad preventiva (12-oct-2026)

- Retirada la conversión de `Expr::Text` en namespaces de módulo para
  `"archivo.yek".campo` y retiradas las claves técnicas correspondientes.
- Rechazado `~export "archivo.yek".campo as alias` por contrato gramatical.
- Preservados `~import "archivo.yek"` sin `as`, alias automáticos derivados de
  rutas, importaciones selectivas y exportación de miembros con identificadores.
- Conservado el AST `Expr::Member` para posteriores campos y propiedades.
- Nueva batería de 24 pruebas positivas/negativas de estas reglas.
- El comportamiento temporal de HF3 queda marcado como superado en su guía.
- Compilación Rust y regresión real pendientes de confirmación en Windows.


## v0.0.9.0 (candidata, sin cargo local)

- `~import` local a cuerpos `~code`, `if`, `for`, `~block`; los alias se retiran al salir del bloque, sin borrar las asignaciones normales.
- Resolución estática recursiva de dependencias locales, caché única por ruta canónica y reportes `yek deps` que muestran importaciones anidadas.
- `in` reservado como separador de patrones `for`, preservando temporalmente `=` para compatibilidad.
- Nueva batería `modulos_locales_in_v0090_tests`.
