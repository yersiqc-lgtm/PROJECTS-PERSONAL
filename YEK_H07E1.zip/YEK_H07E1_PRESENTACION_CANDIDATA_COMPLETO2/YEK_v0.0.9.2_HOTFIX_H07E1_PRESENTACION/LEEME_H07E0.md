# H07E0 — actualización incremental sobre H07D2

## Implementado en el código
- Comparador `in` de expresiones, dentro y fuera de `if`.
- Fuentes: Array, ValuePack, Set, View, claves de Map, Range numérico (inclusivo) y caracteres Unicode (Pack del rango), o valor atómico.
- Texto NO se considera una secuencia de subcadenas al usar `in`: se trata como valor atómico. Un texto de varios caracteres frente a `a..z` da `false`.
- Aviso de `~in(...att=[n,"texto"])` emitido exactamente como se especificó, SIN salto final automático. `\n` añade salto explícito.
- `~num`, `~str` y `~bool` conservan su comportamiento histórico para minimizar incompatibilidades.
- VSIX 1.3.3: resaltado de `out.*`, `in.*`, cierre de modos raw por dedentación y `in` comparativo.

## NO implementado en esta versión
- ValuePack con nombres y referencias persistentes (requiere cambio del modelo de valores y de la resolución de llamadas).
- `~in(c)` con un ValuePack de opciones identificado; `~in` actual es configuración de directiva compilada, no llamada runtime.
- `out.style=pack`, `text.color`, font size, `box`, `bar`, `table` y estilos universales. Siguen pendientes de H07E1/H07F.

`P.type!` devuelve `Type` porque P es el CONSTRUCTOR. Solo una instancia de clase debe responder `Class`.

## Recomendación de validación
`cargo build`, `cargo test --test h07e0_membership_retry_tests`, `cargo test`.
En este entorno no hay Rust/Cargo; la compilación y los resultados reales deben confirmarse en Windows.

## Advertencia respecto a rangos
Los rangos numéricos son inclusivos y la prueba de pertenencia es directa, sin materializar cientos de miles de valores. Los rangos de caracteres Unicode siguen los puntos de código, no el orden lingüístico.
