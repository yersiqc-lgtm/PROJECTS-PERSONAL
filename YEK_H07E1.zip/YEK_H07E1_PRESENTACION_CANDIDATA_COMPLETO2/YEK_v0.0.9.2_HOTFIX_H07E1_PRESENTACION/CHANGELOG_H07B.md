# YEK H07B — Separación de resultados `break(...)` y productores H07

Base: H07A.

## Corrección del motor

- `src/parser/mod.rs`: los argumentos de `break(...)` se separan por comas de su nivel externo **antes** de analizar sus expresiones.
- `break(for(y=1..2)->y,99)` produce tres valores: `1`, `2`, `99`.
- Las expresiones agrupadas siguen siendo composables: `break([for(y=1..2)->y,99])` entrega un solo Array con `[1, 99, 2, 99]`.
- Los productos H07 conservan múltiples resultados por iteración dentro de Array/ValuePack: `[for(x=1..3)->x,99]` significa `[1, 99, 2, 99, 3, 99]`.
- No se ha modificado el ejecutor del bucle, el sistema Map, el motor de rangos Unicode, los contratos ni la extensión VS Code.

## Regresiones

- `tests/arrow_break_nested_regression_tests.rs`: 9 anteriores + 5 casos adicionales; la prueba de Array se actualiza a semántica H07.
- `tests/arrow_multivalor_regresion_tests.rs`: se migran expectativas anteriores de comas de productor en Array y productores anidados.
- `tests/composicion_contrato_tests.rs` y `tests/composicion_generativa_tests.rs`: se actualizan oráculos históricos afectados por la interpretación H07 de comas después de `->`.

## Ejecución

```powershell
cargo build
cargo test --test arrow_break_nested_regression_tests
cargo test --test arrow_multivalor_regresion_tests
cargo test --test composicion_contrato_tests
cargo test --test composicion_generativa_tests
cargo test --test etapa7_h07_universal_tests
cargo test
```

También puede ejecutar `VERIFICAR_H07B.cmd`.

**Importante:** estos paquetes se han validado estructuralmente pero no compilado con Cargo aquí. Confirmar los resultados en Windows antes de aprobar H07B.
