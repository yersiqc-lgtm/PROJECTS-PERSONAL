# QA Integral v2 — YEK v0.0.8.4 Hotfix4

## Que incluye

- **539** programas `.yek` de salida esperada, con `.txt` correspondiente.
- **12** programas con entradas simuladas (sin teclado interactivo).
- **25** programas invalidos que deben producir una clase especifica de error.
- **11** grupos de pruebas metamorficas/parametricas con miles de combinaciones.
- **3** grupos de pruebas seudoaleatorias reproducibles (1650 programas).
- **3** pruebas de carga desactivadas de manera predeterminada.
- Suite historica completa incluida desde Hotfix4 (no se altera el motor).

## Ejecucion sin modificar politica de PowerShell

Abrir PowerShell en esta carpeta (donde esta Cargo.toml) y ejecutar:

```powershell
cargo test --test qa_exhaustiva_fixtures_tests -- --nocapture
cargo test --test qa_exhaustiva_metamorfica_tests -- --nocapture
cargo test --test qa_exhaustiva_semillas_tests -- --nocapture
cargo test
cargo check
```

Opcionalmente, guardar el registro:

```powershell
cargo test -- --nocapture 2>&1 | Tee-Object -FilePath QA_INTEGRAL_RESULTADOS.txt
```

Para lanzar solo una categoria o un caso:

```powershell
cargo test --test qa_exhaustiva_fixtures_tests caso_produccion_ -- --nocapture
cargo test --test qa_exhaustiva_fixtures_tests caso_errores_ -- --nocapture
```

Las pruebas de esfuerzo requieren una ejecucion deliberada (y nunca deberian ejecutarse en una maquina con memoria escasa):

```powershell
cargo test --test qa_exhaustiva_estres_tests -- --ignored --nocapture
```

**Cuidado:** las pruebas de estres pueden usar mucha CPU y RAM; los resultados dependen de los limites de materializacion del interprete.

## Interpretacion

- `ok`: salida completa (o tipo de error) coincidente con las reglas del contrato.
- `FAILED`: posible bug, ambiguedad de gramatica, o error en nuestro oraculo. No cambiar motor automaticamente sin inspeccionar codigo y expectativa.
- `ignored`: estres no lanzado o prueba historica intencionalmente excluida; no es fallo.

## Carpeta de casos

`qa_exhaustiva/casos/<id>.yek` contiene codigo YEK.
`qa_exhaustiva/esperados/<id>.txt` contiene cada salida en su propia linea.
`qa_exhaustiva/MANIFIESTO.json` cataloga todos los archivos. Los casos de error indican `fragmento_error` en el manifiesto.

No se han introducido dependencias Rust adicionales ni modificaciones al interprete.
La bateria aun **no se ha ejecutado contra Cargo en este entorno**: verificarla en Windows puede revelar errores en la suite y en el lenguaje.
