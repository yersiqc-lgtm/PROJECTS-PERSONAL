# YEK H07D2 — Expectativas `out.end` corregidas

**Base:** H07D1

Esta revisión no modifica el intérprete. Corrige dos expectativas del test `h07d_integracion_segura_tests.rs`:

- `h07d_out_end_and_active_string`: `10holaotro` (no `10hola\notro`).
- `h07d_out_end_none`: `hola mundofin` (no `hola mundo\nfin`).

`out.end` es un terminador añadido **después de cada salida**. Cambiarlo de `none` o `""` a `"\n"` no introduce retroactivamente un salto de línea en el texto ya emitido.

Para separar la siguiente salida, emite antes un salto explícito en la última salida del bloque anterior (p. ej. `"hola\n"`) o usa `.end("\n")` para esa salida.

## Instalación

- ZIP completo: extraer la nueva carpeta del proyecto.
- Parche: sustituir `tests/h07d_integracion_segura_tests.rs` en H07D1.

## Verificación

```powershell
cargo test --test h07d_integracion_segura_tests
cargo test
```

El código de `src/` es idéntico a H07D1. Cargo/rustc no están disponibles en el entorno de preparación; las pruebas Rust deben ejecutarse en Windows.
