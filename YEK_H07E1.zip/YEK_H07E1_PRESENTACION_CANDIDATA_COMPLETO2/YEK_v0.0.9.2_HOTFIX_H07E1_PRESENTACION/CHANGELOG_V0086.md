# v0.0.8.6 — Modules / Primera entrega

## Motor

- `~import "archivo.yek" as alias` y alias implícito por nombre de archivo.
- `~export nombre` o `~export a, b` en módulos importados.
- Resolución recursiva de rutas por archivo; grafo de dependencias y ciclos con trazas.
- Ámbitos de módulo independientes; acceso calificado `alias.simbolo`, con privacidad explícita.
- Importación una vez por ejecución, reutilizando exportaciones y capturas de Code.
- `yek check` y `yek run` ahora emplean el cargador de archivos.
- Rechazo explícito de importación de datos, importaciones múltiples, nativas y selectivas pendientes.

## Compatibilidad

- El motor de ejecución interpretada, productores, rangos, operadores, referencias y entradas sigue utilizando el código histórico; no se reemplaza por un preprocesador de inclusión textual.
- Se amplió el lexer para reconocer identificadores calificados con puntos; los rangos `..` y números decimales permanecen diferenciados.
- `run_source()` sin ruta da error si el código contiene imports; los scripts sin imports conservan la API.

## Validación

- 15 nuevas pruebas en `tests/modulos_v0086_tests.rs`.
- Batería de regresión histórica incluida.
- La compilación Cargo y la ejecución de todas las pruebas permanecen pendientes de la verificación del usuario.
