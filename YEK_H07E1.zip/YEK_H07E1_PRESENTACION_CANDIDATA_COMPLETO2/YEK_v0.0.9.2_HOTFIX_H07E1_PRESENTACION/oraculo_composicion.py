#!/usr/bin/env python3
"""Oráculo semántico DE PRUEBA para un subconjunto composicional de YEK.

No es parser oficial ni modificación del intérprete Rust. Independiente de este, materializa
las reglas Scalar/Many, Array/Pack y For anidado. Solo soporta los casos QA del JSON.
"""
from dataclasses import dataclass
import json, re, sys
from pathlib import Path

@dataclass(frozen=True)
class Scalar:
    value: object
@dataclass(frozen=True)
class Many:
    values: tuple
@dataclass(frozen=True)
class Array:
    elements: tuple
@dataclass(frozen=True)
class Pack:
    elements: tuple

TOKENS=re.compile(r'\s*(for|if|->|\.\.|\d+|[A-Za-z_][A-Za-z_0-9]*|[=(),\[\]+*\-/])')
def tokenize(s):
    toks=[]
    pos=0
    while pos < len(s):
        if s[pos:].strip() == '': break
        m=TOKENS.match(s,pos)
        if not m:
            raise SyntaxError('oraculo: token desconocido en '+repr(s[pos:pos+30]))
        toks.append(m.group(1)); pos=m.end()
    return toks

class Parser:
    def __init__(self,ts): self.ts=ts; self.i=0
    def peek(self): return self.ts[self.i] if self.i<len(self.ts) else None
    def eat(self, t=None):
        q=self.peek()
        if q is None or (t is not None and t!=q):
            raise SyntaxError(f'oraculo: se esperaba {t}, llego {q}, posicion={self.i}')
        self.i+=1
        return q
    def expr(self): return self.add()
    def add(self):
        e=self.mul()
        while self.peek() in ('+','-'):
            op=self.eat(); e=('binary',op,e,self.mul())
        return e
    def mul(self):
        e=self.atom()
        while self.peek() in ('*','/'):
            op=self.eat(); e=('binary',op,e,self.atom())
        return e
    def atom(self):
        q=self.peek()
        if q=='-':
            self.eat(); return ('negative',self.atom())
        if q=='[':
            self.eat(); xs=self.elements(']'); return ('array',xs)
        if q=='(':
            self.eat(); xs=self.elements(')'); return ('parentheses',xs)
        if q=='for':
            self.eat(); self.eat('(')
            name=self.eat(); self.eat('=')
            lo=self.expr() if self.peek()!='..' else None
            self.eat('..'); hi=self.expr()
            step=None
            if self.peek()==',': self.eat(',');step=self.expr()
            self.eat(')')
            if self.peek()=='->':
                self.eat('->'); return ('for',name,lo,hi,step,self.expr())
            if self.peek()=='if':
                self.eat('if');self.eat('('); cond=self.expr();self.eat(')')
                self.eat('->')
                return ('for',name,lo,hi,step,('if',cond,self.expr()))
            return ('for',name,lo,hi,step,None)
        if q=='if':
            self.eat('if');self.eat('('); cond=self.expr();self.eat(')')
            self.eat('->'); return ('if',cond,self.expr())
        if q is not None and q.isdigit(): return ('number',int(self.eat()))
        if q in ('false','true'): return ('bool',self.eat()=='true')
        if q is not None and re.fullmatch(r'[A-Za-z_][A-Za-z_0-9]*',q): return ('var',self.eat())
        raise SyntaxError(f'oraculo: expresion invalida token={q}')
    def elements(self,closer):
        items=[]
        if self.peek()==closer: self.eat(closer); return items
        while True:
            items.append(self.expr())
            if self.peek()==closer: self.eat(closer);return items
            self.eat(',')
            if self.peek()==closer: self.eat(closer);return items

def scalar(ev):
    if isinstance(ev,Many):
        if len(ev.values)!=1: raise ValueError('esperaba escalar, obtuvo Many')
        return ev.values[0]
    assert isinstance(ev,Scalar)
    return ev.value

def expand(children,env):
    result=[]
    for item in children:
        v=eval_node(item,env)
        if isinstance(v,Many): result.extend(v.values)
        else: result.append(v.value)
    return tuple(result)

def eval_node(e,env):
    tag=e[0]
    if tag=='number' or tag=='bool': return Scalar(e[1])
    if tag=='var': return Scalar(env[e[1]])
    if tag=='negative': return Scalar(-scalar(eval_node(e[1],env)))
    if tag=='binary':
        a=scalar(eval_node(e[2],env));b=scalar(eval_node(e[3],env))
        return Scalar({'+':lambda:a+b,'-':lambda:a-b,'*':lambda:a*b,'/':lambda:a/b}[e[1]]())
    if tag=='array': return Scalar(Array(expand(e[1],env)))
    if tag=='parentheses':
        if len(e[1])==1:
            one=eval_node(e[1][0],env)
            if isinstance(one,Scalar): return one
            return Scalar(Pack(one.values))
        return Scalar(Pack(expand(e[1],env)))
    if tag=='if':
        c=scalar(eval_node(e[1],env))
        if not isinstance(c,bool): raise TypeError('if exige bool')
        return eval_node(e[2],env) if c else Many(())
    if tag=='for':
        name,lo,hi,step,body=e[1:]
        first=scalar(eval_node(lo,env))
        last=scalar(eval_node(hi,env))
        incr=scalar(eval_node(step,env)) if step is not None else (1 if first<=last else -1)
        if incr==0 or (last-first)*incr<0: raise ValueError('paso incorrecto')
        result=[];cur=first
        while True:
            new_env=dict(env);new_env[name]=cur
            generated=eval_node(body,new_env) if body is not None else Scalar(cur)
            if isinstance(generated,Many): result.extend(generated.values)
            else:result.append(generated.value)
            if cur==last: break
            next_value=cur+incr
            if incr>0 and next_value>last:cur=last
            elif incr<0 and next_value<last:cur=last
            else:cur=next_value
            if len(result)>100_000:raise ValueError('limite de materializacion en oraculo')
        return Many(tuple(result))
    raise ValueError('nodo desconocido '+str(tag))

def show(v):
    if isinstance(v,Array):return '['+', '.join(map(show,v.elements))+']'
    if isinstance(v,Pack):return '('+', '.join(map(show,v.elements))+')'
    if isinstance(v,bool):return 'true' if v else 'false'
    return str(v)

def run(source):
    m=re.fullmatch(r'\s*a\s*=\s*(.*?)\s*a!\s*',source,re.S)
    if not m: raise SyntaxError('oraculo solamente admite a = expresion; a!')
    tokens=tokenize(m.group(1))
    parser=Parser(tokens)
    expr=parser.expr()
    if parser.peek() is not None: raise SyntaxError('oraculo sobraron tokens: '+str(tokens[parser.i:]))
    result=eval_node(expr,{})
    return show(scalar(result))

def main():
    test_path=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).with_name('QA_COMPOSICION_V2.json')
    cases=json.loads(test_path.read_text(encoding='utf-8'))
    failed=0
    for t in cases:
        try:
            got=run(t['source'])
            ok=got==t['expected']
        except Exception as e:
            got=f'ERROR: {e}'
            ok=False
        print(('PASS' if ok else 'FAIL')+' '+t['id'])
        if not ok:
            failed+=1
            print(' Esperado:',t['expected']);print(' Obtenido:',got)
    print(f'Referencia independiente: {len(cases)-failed}/{len(cases)} casos coherentes')
    return 1 if failed else 0

if __name__=='__main__':sys.exit(main())
