# Contratos de aceptación posteriores — H07E / H07F / H07G

Estos fragmentos son **requisitos de diseño, no código que H07D prometa ejecutar**.

## ValuePack nombrado y con referencias (H07E)

```yek
f(a,b)=~code -> a+b
args=(a=10,20)
f(args)!                 ~ 30
```

El orden no importa para los argumentos nombrados, y los posicionales completan los huecos. Prohibir duplicados y nombres inexistentes. Garantizar la expansión `f(pack)` por valor o referencia declarada, sin alterar `f((pack))` ni `f((pack!))`. Los elementos del Pack deben tener datos tipados `(name:Option<String>, binding:Value|CellId)`. No esconder referencias mediante Map, Entry ni View con marcadores opacos. Definir clonación, igualdad, serialización, vida útil y desprendimiento antes de cambiar el AST.

```yek
color="red"
style=(text.color=color!,end="")
color="blue"
"Texto".style(style)
```

Cada referencia se lee en el momento de aplicación. `a=a` mantiene las reglas existentes de identidad y los CellId capturados no deben cambiar de destino. Fallar explícitamente ante una referencia inválida.

## Motor global de estilos (H07F)

```yek
format=(end="", color="red",width=20,align=center)
out.style=format
"titulo".style(format)
"valor".style(end="",color="black")
```

Diseñar `OutputStyle` por frame, resolver estilos en el orden predeterminado < estilo de Code < estilo de salida, no recalcular interpolaciones, validar todos los argumentos antes de emitir salida. `~text` es raw; no agregar formato por defecto. `text.size` exige backend gráfico, no fingir soporte de terminal.

## Consola y entrada (H07G)

`.pos()`, box, table, bar: reservar un backend de renderizado independiente de la gramática; respetar ancho de columnas Unicode, redirección a archivos y ausencia de terminal interactivo. `in.prompt`, `in.prompt_end`, trim, default: integra con `~in(...)` sin alterar validación; `in` es actualmente palabra reservada del lexer y requerirá gramática contextual. Input no debe cambiar de línea por afirmar que controla el Enter del terminal.

## Auditoría obligatoria

Matriz de equivalencias por origen de iterable, 1-7 QA global, pruebas referenciales de identidad, divergencia entre Code/Frame, rangos Unicode vivos, import/export, funciones parciales y Productores; comprobar todos los casos en Windows. No validar por simples hashes de ZIP.
