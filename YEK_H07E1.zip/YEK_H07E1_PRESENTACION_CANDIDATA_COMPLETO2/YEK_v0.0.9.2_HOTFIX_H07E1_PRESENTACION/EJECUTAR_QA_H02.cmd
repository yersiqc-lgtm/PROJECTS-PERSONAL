@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0EJECUTAR_QA_H02.ps1" %*
