# YEK v0.0.9.2 — Etapa C NONE HOTFIX H02

## Diagnóstico

El H01 bloqueó por error la asignación histórica `true="..."` / `false="..."` en el parser. En YEK esta sintaxis **no** reasigna literales ni crea variables: personaliza las etiquetas de visualización Bool dentro del contexto Code. Los tests `v007_3_tests` y `v008_1_tests` dependen de esa función.

También cambió indirectamente el diagnóstico histórico de `inf=10` por un rechazo prematuro en el parser.

## Corrección general

- `none` es el único literal nuevo cuyo nombre se bloquea explícitamente como destino de asignación en el parser, también en desestructuración. Se añade una defensa equivalente a `execute_assignment` para ejecución de AST construido programáticamente.
- `true` y `false` atraviesan el parser y utilizan el mecanismo existente de etiquetas de visualización. Solo aceptan texto y una asignación a la vez; mantienen su ámbito por marco de ejecución. No pasan a ser variables mutables.
- `inf` recupera el diagnóstico de error histórico gestionado en `execute_assignment`.
- Se actualizaron dos tests del HOTFIX H01 que interpretaban erróneamente la configuración Bool como asignación ilegal; mantienen la exigencia de que `true=7` y `false=7` no sean válidos, con el diagnóstico adecuado.
- Nueva batería de 21 pruebas para personalización, ámbito local, Array, referencias, inválidos, `none` e `inf`.

## Comprobación PowerShell

```powershell
cargo check --all-targets
cargo test --test none_hotfix_h02_bool_display_compat_tests -- --test-threads=1 --nocapture
cargo test --test v007_3_tests -- --test-threads=1 --nocapture
cargo test --test v008_1_tests -- --test-threads=1 --nocapture
cargo test --test none_hotfix_h01_literal_fallback_tests -- --test-threads=1 --nocapture
cargo test --test none_tipo_universal_v0092_tests -- --test-threads=1 --nocapture
cargo test --all-targets
```

**Estado:** ZIP y parche comprobados estáticamente; Rust/Cargo no están disponibles en el entorno de preparación. Validación de compilación y pruebas pendiente.
