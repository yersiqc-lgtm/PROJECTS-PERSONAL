# YEK 0.0.9.1 — Núcleo de recursión HOTFIX H02

## Error reparado

La invocación `f(n=n+1)` durante la recursión devolvía `parameter 'n' was already bound`.
La causa era mezclar los valores nombrados de **una llamada** con `CodeValue.bound`,
que representa los valores **fijados permanentemente** por aplicación parcial.
Tras la primera llamada nombrada, la auto-referencia de la función capturaba
una firma modificada y rechazaba parámetros que debían seguir libres.

## Corrección estructural

- `invoke_named_code` convierte argumentos posicionales y nombrados en ranuras
  `Option<RuntimeValue>` relativas a los parámetros **libres** de la función.
- `invoke_code` sigue aceptando llamadas posicionales, pero ambas rutas invocan
  `invoke_code_with_slots`. Los valores nombrados ya no mutan `code.bound`.
- `code.bound` continúa reservado a los valores fijados de forma permanente
  mediante `!` y aplicaciones parciales. Si ya estaba fijado un parámetro,
  un intento de reasignarlo mediante nombre se rechaza.
- La validación `~code(pure,cache)` reconoce los argumentos nombrados como
  expresiones, conservando sus restricciones de pureza.
- La protección conservadora de profundidad (20 marcos Code) de H01 permanece.

## Pruebas nuevas

Se incorpora `tests/recursion_named_arguments_hotfix_h02_tests.rs` con 16
pruebas sobre recursividad infinita con argumentos nombrados, recursividad
finita, recursividad mutua, bloques, métodos, múltiples retornos, `pure,cache`,
argumentos por defecto, aplicaciones parciales y errores controlados.

No se han modificado las 41 pruebas de la entrega anterior, las 7 de H01,
ni las suites históricas. No se ha alterado deliberadamente el parser,
los módulos, los objetos ni las referencias.

## En Windows / PowerShell

```powershell
cargo check --all-targets
cargo test --test recursion_named_arguments_hotfix_h02_tests -- --test-threads=1 --nocapture
cargo test --test recursion_stack_safety_hotfix_h01_tests -- --test-threads=1 --nocapture
cargo test --test nucleo_recursion_importacion_v0091_tests -- --test-threads=1 --nocapture
cargo test --all-targets
```

O ejecuta:

```powershell
.\VERIFICAR_NUCLEO_RECURSION_HOTFIX_H02.ps1
```

**Validación:** el ZIP fue comprobado estáticamente. Cargo no está disponible
actualmente en el entorno de construcción. Los resultados de ejecución deben
confirmarse en el equipo de destino; la entrega continúa siendo candidata.
