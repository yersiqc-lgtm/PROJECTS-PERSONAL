# YEK H06A · Rango explícito

40 programas `.yek` de regresión: 29 válidos y 11 rechazos controlados.

- `a..b`: **rechazado** como Range ordinario entre variables.
- `(a)..(b)`: extremos dinámicos **por valor**.
- `a!..b!`, `(a!)..(b!)`: referencias explícitas.
- `~in(str=a..z)`: dominio literal de caracteres, conservado.
- `~in(num=(a)..(b))`: referencias a valores numéricos, capturados por valor.

Desde la raíz del proyecto: `cargo test --test etapa6_h06a_rangos_explicitos_tests`.
Desde este directorio: `py -3 ejecutar_h06a.py`.
El informe estará en `RESULTADOS_H06A/REPORTE_PARA_CHATGPT.txt`.
