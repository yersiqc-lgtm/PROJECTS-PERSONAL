# YEK 0.0.9.2 — Hotfix H03: Etapa 2, modos / Unicode / expresiones multilínea / escapes

Base: **H02 CADENAS ACTIVAS**. No restaura `~for`, `~if`, `~orif` o `~else`.

## Cambios de comportamiento

1. **Modo + contenido en una sola línea.** `~code "hola"`, `~code a?a!`, `~text texto raw` y `~invalid ignorar esto` son reconocidos desde el comienzo de la línea; el contenido de `~code` se analiza como código YEK, no como comentario. `~code extra` ahora intenta ejecutar `extra` y, si no existe, produce un error. En `~text`, las demás líneas siguen siendo crudas hasta una directiva de modo válida. `~codex` no cambia de modo. `~ code` sigue siendo comentario.
2. **Agrupación a través de saltos de línea.** Dentro de `(...)`, `[...]` o `{...}`, los saltos físicos son espacios léxicos (salvo dentro de cadenas). Un `~ comentario` interno sigue terminando solo su línea, no el agrupador: `x=(1 ~ comentario\n +2)` produce `3`. Los cierres incorrectos siguen dando errores.
3. **Identificadores Unicode.** Se utilizan las categorías **XID_Start/XID_Continue** y la normalización **NFKC** de identificadores al analizarlos (NFKC no cambia el contenido de cadenas). `á` y `a` + acento combinante se identifican como el mismo nombre. Se añaden `unicode-ident` y `unicode-normalization` a Cargo: la primera compilación deberá obtenerlas de crates.io si no están en caché. No se aceptan símbolos arbitrarios como emojis al inicio de un identificador.
4. **Escapes de texto entre comillas**: `\n`, `\r`, `\t`, `\b`, `\f`, `\v`, `\a`, `\e` (ESC), `\0`/octal de hasta 3 dígitos incluido `\033`, `\xHH`, `\uHHHH`, `\u{H...}`, `\UHHHHHHHH`, `\\`, `\"`, `\'`, `\!`, `\?`. Se rechazan bytes octales fuera de 0..255, Unicode no escalar y secuencias desconocidas. **No se prometen todas las secuencias que otros lenguajes inventen en el futuro**. `\N{nombre}` todavía no está implementado.
5. **UTF-8 BOM al inicio de un archivo**: se descarta antes del análisis tanto por el lexer como por el lector de código.

## Deliberadamente inalterado

- `"YEK!"` intenta evaluar la variable `YEK`; `"YEK\!"` muestra la puntuación literalmente. E2-193, E2-194, E2-195 y E2-196 deben continuar dando errores por `for`, `if`, `orif` y `else` como expresiones incrustadas no válidas.
- `~text` es crudo: los caracteres `\t` permanecen como dos caracteres, no como tabulación. No se decodifican escapes en este modo.
- Los modos declarativos `~logic` y las variantes capturadas conservan sus restricciones previas. Este cambio no introduce nuevas formas de `~logic` global.
- Los números, mapas, sets, referencias, funciones y módulos no cambian intencionadamente de semántica.

## Diagnóstico del informe E2

| Caso | Situación bajo H03 |
|---|---|
| E2-193 a E2-196 | Errores correctos; el oráculo original del runner buscaba equivocadamente `used before receiving a value` |
| E2-601 | `~code extra` pasa a ser directiva válida + contenido Code, por tanto `extra` produce error como variable no inicializada |
| E2-607 | Expresión multilínea con comentario: se espera `3` |
| E2-608 | Acento combinante válido y normalizado: se espera `2` |
| E2CLI-012 | El BOM de UTF-8 inicial ya no debe causar `unrecognized symbol` |
| E2-067 | Cadena de comillas sin escapar: caso fuente mal formado; debe actualizarse su expectativa o escaparse las comillas |
| E2-600 | Regla de modo textual capturado e indentación aún por especificar; no se modifica en este hotfix |

## Comprobar en Windows

Abre una terminal de PowerShell en la carpeta que contiene este `Cargo.toml`:

```powershell
cargo build
cargo test --test etapa2_hotfix_h03_modos_unicode_escapes_tests
cargo test
cargo run -- run PRUEBAS_H03_ETAPA2/H03-10_parentesis_dos_lineas.yek
```

También puedes ejecutar `VERIFICAR_H03.cmd`. Las 47 pruebas Rust comprueban casos positivos y rechazos, y `PRUEBAS_H03_ETAPA2` contiene 37 programas para ejecutar manualmente desde VS Code (el archivo 03 requiere introducir `7`).

## Nivel de validación de esta entrega

**Inspección estática y empaquetado verificados. No compilado ni ejecutado con Rust en este entorno**, porque no se dispone de Cargo ni acceso de red para instalarlo. La validación funcional definitiva corresponde a `cargo build` y `cargo test` en tu Windows. No des por aprobada la Etapa 2 hasta analizar sus resultados.

Si una prueba nueva falla, envía la traza completa antes de actualizar más archivos: esta edición modifica el parser/lexer y no debería mezclarse con otras refactorizaciones hasta que pase Cargo.
