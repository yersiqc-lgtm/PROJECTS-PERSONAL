# YEK v0.0.9.2 — Etapa C: `none` como valor fundamental

## Estado
**CANDIDATA:** los cambios están integrados en Rust, pero no se ha compilado ni ejecutado Cargo en este entorno. El usuario debe validar en su equipo antes de sustituir H02.

## Semántica

- `none` es una palabra reservada y un valor inmutable, distinto de Number `0`, Bool `false` y Text `""`.
- `none!` muestra `none`.
- `x=none` guarda un valor y puede reasignarse; `r=x!` captura una celda mutable como de costumbre.
- `none==none` es `true`; frente a números, textos y Bool es `false`.
- `none` no se convierte implícitamente a número, Bool, índice o texto.
- `-> none` devuelve **un** resultado; `->` devuelve **cero** resultados. No cambiar la aridad de los retornos históricos.
- Admite Array, ValuePack, Map (clave y valor), Set (elemento único), Entry, Struct, Class y vistas vivas Map.
- Es válido en argumentos predeterminados, llamadas y resultados de Code, incluyendo `pure,cache`.
- En `~logic` existe como dato literal y puede cruzar el puente declarativo; las operaciones aritméticas de `~math` no lo aceptan como número.

## Recuperación de contratos

Si se agotan intentos de `~num`, `~str` o `~bool` y la política permite recuperación:

- Sin fallback explícito: `none` (ANTES: `0`, `""`, `false`).
- Con `->` vacío: `none`.
- Con `-> none`: `none` explícito.
- Con `-> 0`, `-> ""`, `-> false`: conservar el valor elegido.
- Política `<warning>`: advertencia y recuperación; `<error>`: error sin convertirlo a `none`.
- El `none` contextual de políticas de contrato se conserva para compatibilidad.
- En `~auto`, el texto que el usuario teclea `none` **continúa siendo Text**, no el literal del programa.

## Compatibilidad

Los programas que asumían `0`/`false`/`""` como resultado implícito de contratos fallidos deberán cambiarse a `dato==none`. Dos expectativas históricas correspondientes a este contrato se actualizaron expresamente en `tests/v007_1_tests.rs`; las recuperaciones explícitas y los valores válidos permanecen sin cambios.

## Pendiente para otra entrega

`~try`, `~catch`, `~raise`, `Result` y `~attempt` NO están implementados aquí. Un error fatal sigue siendo un error, no `none`.

## Verificación

Desde la carpeta donde está Cargo.toml:

```powershell
cargo check --all-targets
cargo test --test none_tipo_universal_v0092_tests -- --test-threads=1 --nocapture
cargo test --test colecciones_universales_v0092_etapa_b_map_set_tests -- --test-threads=1 --nocapture
cargo test --all-targets
```

O en Windows ejecuta `VERIFICAR_NONE_ETAPA_C.cmd`.

Los 12 archivos en `EJEMPLOS_NONE` permiten experimentar interactivamente; el caso 09 necesita una entrada inválida como `99`, y el caso 10 requiere `99` para observar la recuperación explícita.
