# YEK H07 — Laboratorio dirigido

Son 44 archivos `.yek` independientes, con resultado esperado y errores controlados en `MANIFIESTO.json`.

```powershell
py -3 EJEMPLOS_H07_ITERACION_UNIVERSAL\ejecutar_h07.py --auditar
cargo build
cargo test --test etapa7_h07_universal_tests
cargo test
py -3 EJEMPLOS_H07_ITERACION_UNIVERSAL\ejecutar_h07.py --sin-build
```

Los resultados quedan en `RESULTADOS_H07/REPORTE_PARA_CHATGPT.txt`. Las expectativas están derivadas de la semántica propuesta y **no han sido ejecutadas con Cargo en el entorno de preparación**; si una falla, conviene analizar tanto el motor como el oráculo antes de modificar el código.
