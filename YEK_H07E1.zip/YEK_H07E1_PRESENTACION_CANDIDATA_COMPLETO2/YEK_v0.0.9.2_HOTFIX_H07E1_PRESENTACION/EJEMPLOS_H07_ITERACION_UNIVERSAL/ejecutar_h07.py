#!/usr/bin/env python3
"""Run H07 standalone YEK programs; compare stdout and controlled diagnostics."""
import argparse,csv,hashlib,json,os,subprocess,sys
from pathlib import Path

BASE=Path(__file__).resolve().parent
PROJECT=BASE.parent


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--auditar',action='store_true')
    parser.add_argument('--sin-build',action='store_true')
    parser.add_argument('--timeout',type=float,default=8)
    args=parser.parse_args()
    cases=json.loads((BASE/'MANIFIESTO.json').read_text(encoding='utf-8'))
    for item in cases:
        file=BASE/item['file']
        if hashlib.sha256(file.read_bytes()).hexdigest()!=item['sha256']:
            raise SystemExit('Error de integridad: '+str(file))
    print('Integridad OK:',len(cases),'casos')
    if args.auditar:return 0
    executable=PROJECT/'target'/'debug'/('yek.exe' if os.name=='nt' else 'yek')
    if not args.sin_build:
        build=subprocess.run(['cargo','build','--quiet'],cwd=PROJECT,check=False)
        if build.returncode!=0:
            print('Cargo build fallo; no se ejecutaron los casos',file=sys.stderr)
            return 2
    if not executable.exists():
        raise SystemExit('No existe ejecutable: '+str(executable))
    results=[]
    for case in cases:
        try:
            p=subprocess.run([str(executable),'run',str(BASE/case['file'])],
                cwd=PROJECT,input=b'',stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                timeout=args.timeout)
            stdout=p.stdout.decode('utf-8','replace').splitlines()
            stderr=p.stderr.decode('utf-8','replace')
            if case['tipo']=='OK':
                ok=p.returncode==0 and stdout==case['stdout']
            else:
                ok=p.returncode!=0 and case['error_contiene'] in (stderr+'\n'+'\n'.join(stdout))
            status='OK' if ok else 'FALLO'
            results.append((case['name'],case['tipo'],status,p.returncode,' | '.join(stdout),stderr[:1500]))
            print(status,case['name'])
        except subprocess.TimeoutExpired:
            results.append((case['name'],case['tipo'],'TIMEOUT',-1,'',''))
            print('TIMEOUT',case['name'])
    dest=BASE/'RESULTADOS_H07';dest.mkdir(exist_ok=True)
    with (dest/'resultados.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f);w.writerow(['nombre','tipo','estado','exit','stdout','stderr']);w.writerows(results)
    with (dest/'REPORTE_PARA_CHATGPT.txt').open('w',encoding='utf-8') as f:
        f.write(f'H07: {sum(r[2]=="OK" for r in results)}/{len(results)} aprobadas\n')
        for r in results:
            if r[2]!='OK':f.write('\nCASO '+r[0]+' '+r[2]+'\nSTDOUT: '+r[4]+'\nSTDERR: '+r[5]+'\n')
    print('Informe:',dest/'REPORTE_PARA_CHATGPT.txt')
    return 0 if all(r[2]=='OK' for r in results) else 1

if __name__=='__main__':sys.exit(main())
