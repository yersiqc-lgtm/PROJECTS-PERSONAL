# YEK Hotfix H05B — Reparación de literal Rust en prueba H05A

## Diagnóstico

`cargo test --test etapa5_h05_inline_if_orif_else_tests` no llegaba a ejecutar
las 68 pruebas debido a un literal mal formado en la línea 271 del archivo:

`tests/etapa5_h05_inline_if_orif_else_tests.rs`

Antes: `output("if(false) "A"\nelse "B"", &["B"]);`

Ahora: `output("if(false) \"A\"\nelse \"B\"", &["B"]);`

## Alcance

- ÚNICO archivo de código modificado: el archivo Rust de pruebas indicado.
- Ningún archivo `src/` cambia respecto de H05A.
- Se mantienen las 68 pruebas originales. No se eliminó ni desactivó ninguna.
- El programa de ejemplo es un condicional YEK válido con `else` en la línea posterior.

## Aplicar el parche

Extraer este ZIP en la carpeta raíz H05A y reemplazar el archivo `tests/etapa5_h05_inline_if_orif_else_tests.rs`.

## Comprobación en PowerShell

```powershell
cargo build
cargo test --test etapa5_h05_inline_if_orif_else_tests
cargo test
```

## Nivel de verificación

Se comprobó la sustitución exacta, la conservación del proyecto,
la coincidencia entre el parche y el paquete completo, los hashes y la
integridad de ambos ZIP. **Aquí no existe Cargo/Rustc**, de manera que
la ejecución real de estas pruebas sigue pendiente de Windows.
