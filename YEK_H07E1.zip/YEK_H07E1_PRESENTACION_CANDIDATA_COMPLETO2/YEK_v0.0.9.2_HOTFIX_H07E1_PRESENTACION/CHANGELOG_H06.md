# H06 — Registro de cambios

- Nuevo `src/unified_input.rs`: gramática explícita de entrada y restricciones sin evaluación de código.
- `src/input.rs`: reconocimiento de `~in` y soporte de directivas multilínea.
- `src/interpreter/mod.rs`: validación tipada, referencias vivas/snapshot, reglas de longitud, reintentos, salida/errores y literales Auto seguros.
- `src/source.rs`: los rangos ordinarios de variables dejan de confundirse automáticamente con ContractPack ambiguos.
- Límite de seguridad de materialización de Range finitos.
- Tests Rust de H06 y laboratorio de 57 programas `.yek` con informe automatizado.
- Extensión VSIX v1.3.0 con coloreado de selectores y opciones `~in`.

Ninguna prueba Cargo fue ejecutada por falta del toolchain en el entorno de preparación. La compatibilidad con las suites anteriores debe verificarse en Windows.
