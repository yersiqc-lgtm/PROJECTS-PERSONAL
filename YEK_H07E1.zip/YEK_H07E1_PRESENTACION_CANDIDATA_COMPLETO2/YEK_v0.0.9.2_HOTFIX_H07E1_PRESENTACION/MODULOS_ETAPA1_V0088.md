# YEK v0.0.8.8 — Módulos, entrega 1 de 2

Esta entrega se basa en v0.0.8.7 Hotfix 1 y amplía su sistema de módulos. **Es una versión candidata**: ejecutar las pruebas con Cargo en Windows antes de adoptarla como estable.

## Contrato de la primera entrega

### 1. Declaraciones uniformes

Las tres variantes son equivalentes:

```yek
~export suma as s, resta as r
~export(suma as s, resta as r)
~export(
    suma as s,
    resta as r,
)
```

El mismo mecanismo se aplica a `~import`:

```yek
~import math, str.len as longitud, "ayuda.yek" as ayuda
~import(math, str.len as longitud, "ayuda.yek" as ayuda)
~import(
    math,
    str.len as longitud,
    "ayuda.yek" as ayuda,
)
```

**Una coma final dentro de paréntesis es opcional.** Las comas dentro de nombres de archivo entre comillas no separan elementos. No hay importaciones implícitas o modificación automática del código.

### 2. Alias de exportación

Archivo `calculos.yek`:

```yek
suma(a,b)=~code -> a+b
~export suma as s
```

En otro archivo:

```yek
~import "calculos.yek" as calculos
calculos.s(2,3)!
```

`suma` continúa siendo el nombre interno; `s` es el nombre público. Solo `calculos.s` existe desde el importador, no `calculos.suma`, salvo exportación adicional.

### 3. Reexportación sin copiar código

```yek
~import "calculos.yek" as calc
~export calc.s as sumar
```

También admite selectivos:

```yek
~import "calculos.yek".s as x
~export x as sumar
```

Ambas variantes vuelven público el **mismo valor/celda**. No vuelve público automáticamente el módulo completo ni símbolos privados. Se admite renombrar varias veces la misma fuente bajo nombres públicos distintos, pero se rechaza publicar dos símbolos con el mismo nombre.

### 4. Validación

- Rechaza elementos vacíos, alias inválidos, exportaciones duplicadas y símbolos exportados inexistentes.
- Se conservan los ámbitos de módulo y su caché; un módulo se inicializa una vez por ejecución.
- Rechaza importaciones circulares.
- Los archivos `.txt` continúan siendo datos y nunca se interpretan como código.
- Las declaraciones fuera del nivel superior no son legales.
- Los modos `~invalid` y `~text` no ejecutan importaciones.
- `~import` **ejecuta el código de inicialización** de archivos `.yek`; importar solo código de confianza.

## Prueba manual

Desde el directorio con `Cargo.toml`:

```powershell
cargo test --test modulos_v0088_etapa1_tests -- --nocapture
cargo test
cargo check
cargo run -- run examples/modulos_v0088_etapa1/main.yek
```

Salida esperada del ejemplo: `30`, `23`, `64`, `8` (una línea cada uno).

**Importante:** si VS Code tiene configurado `yek.manifestPath`, actualízalo para que apunte al `Cargo.toml` de esta entrega y no a una versión anterior.

## Segunda entrega prevista

`yek inspect`, `yek deps`, documentación extraída de exportaciones, diagnósticos con sugerencias y mejor navegación de módulos en VS Code. La importación diferida (`lazy`) y exclusiones (`except`) exigirán otro contrato de inicialización y quedan como propuestas futuras, no funciones implementadas aquí.

## Cambios en Rust

- `src/ast/mod.rs`: `ExportSpec { source, public }`.
- `src/source.rs`: misma gramática de colecciones para `~import` y `~export`, con alias y agrupaciones multilínea.
- `src/modules.rs`: exportaciones identificadas por nombre **público** y validación de selectivos contra esos nombres.
- `src/interpreter/mod.rs`: resolución de exportación desde el nombre interno y publicación bajo alias.
- `tests/modulos_v0088_etapa1_tests.rs`: 21 pruebas de integración y errores esperados.

## Estado de validación

El contenido fuente y el ZIP han sido revisados estáticamente. **No se ha ejecutado `cargo test` en este entorno porque no está instalado Cargo ni rustc.** No se garantiza que compile hasta probarlo en tu equipo.
