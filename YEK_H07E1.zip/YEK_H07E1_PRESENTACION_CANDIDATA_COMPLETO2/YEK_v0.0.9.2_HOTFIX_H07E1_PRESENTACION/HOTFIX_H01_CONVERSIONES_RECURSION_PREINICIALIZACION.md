# YEK v0.0.9.2 — UCS HOTFIX H01

## Causa
La reserva anticipada de declaraciones `~code`, `~block` y tipos crea una celda con valor marcador (`"<uninitialized declaration>"`) para garantizar que existan enlaces léxicos durante la compilación de la recursividad y los métodos. En la candidata UCS, la llamada de una variable utilizaba directamente `lookup_cell(name)` y leía `self.cells[cell].value` **sin consultar** `uninitialized_declarations`, evitando la validación histórica de `member_cell`.

Por eso `f(1)!` antes de `f(n)=~code -> n` devolvía `member or variable is text, not callable Code` en vez de `before initialization`.

## Corrección
- Comprobación única `ensure_declaration_initialized(cell, name)` y su uso en el despacho directo de llamadas, antes de evaluar los argumentos.
- Mismo requisito en `resolve_code` (capturas/binding), `activate_for_output` y accesos a receptores de métodos o consultas declarativas.
- Conservación explícita de la activación de conversores nativos (`set`, `array`, `pack`, `dict`, `num`, `str`, `bool`) cuando no hay una variable que los oculte.
- Sin cambios en la semántica de ValuePack, `none`, Map, Set o convertidores UCS.

## Comandos en PowerShell
```powershell
cargo check --all-targets
cargo test --test ucs_hotfix_h01_initialization_tests -- --test-threads=1 --nocapture
cargo test --test nucleo_recursion_importacion_v0091_tests -- --test-threads=1 --nocapture
cargo test --test universal_conversion_v0092_tests -- --test-threads=1 --nocapture
cargo test --all-targets
```

## Estado
Código revisado y paquete ZIP validado estáticamente. Cargo/rustc no están instalados en el entorno de preparación: **se requiere validación de compilación y pruebas en Windows**.
