# YEK — Entrega 3 final (candidata de validación)

**Base:** YEK v0.0.9.0, Entrega 2 HOTFIX H02. Se mantienen el runtime existente, los bloques de `~code`, los contratos, las referencias, la gramática y la suite histórica. La nueva funcionalidad se implementa como métodos **ligados al tipo del receptor**, no como operadores ni palabras reservadas globales.

> **Estado real:** cambios fuente preparados y auditoría léxica/estructural estática realizada. **No compilado ni probado con Cargo en el entorno de entrega**. No reemplazar la versión H02 validada hasta pasar todas las suites en Windows.

## API nativa por tipo (sin importar biblioteca)

| Receptor | Método (paréntesis opcionales cuando no hay argumentos) | Resultado |
| --- | --- | --- |
| `Array` y `ValuePack` | `.min`, `.max` | Valor mínimo/máximo; String o Number; sin mezclar tipos |
| `Array` de ValuePacks | `.min(INDICE)`, `.max(INDICE)` | Fila completa comparando la columna con índice **0-based** |
| `Array` y `ValuePack` | `.first`, `.last`, `.count`, `.len` | Primer/último valor o tamaño |
| `Array` y `ValuePack` numéricos | `.sum`, `.avg` | Número, media racional exacta |
| `String` | `.lower`, `.upper`, `.len`, `.count("subcadena")` | Transformación/longitud/ocurrencias |
| `Symbolic` | `.simplify`, `.expand`, `.factor` | Árbol simbólico reescrito estructuralmente |
| `~math` | `.min("bloque","OBJETIVO")`, `.max(...)` | Una asignación óptima como Number o ValuePack |
| `~logic` con relación de 2/3 columnas | `.path("tramo","A","B")` | Array con el camino mínimo ponderado |
| `~logic` con relación de 2/3 columnas | `.min("tramo","A","B")` | ValuePack `(Array de nodos, coste)` |
| `~logic` con relación de 2/3 columnas | `.depth("tramo","A","B")` | Número de aristas **en el camino de menor costo** |
| `~logic` | `.components("tramo")`, `.cycles("tramo")` | Array de componentes fuertemente conexas / ciclos |
| `~logic` | `.why("relacion", argumentos...)` | Comprobación textual. Para relaciones transitivas de dos posiciones puede mostrar un camino de hechos directos |

**Conflictos de nombres:** si el usuario declara una relación `min` en `~logic` o un `~block min` en `~math`, el miembro definido por el usuario tiene precedencia. Los métodos no son nuevas directivas `~min`, etc. El contexto `~code` no reinterpreta las mayúsculas ni `<-`.

## Semántica y seguridad

- Grafos: relaciones `tramo(ORIGEN,DESTINO)` o `tramo(ORIGEN,DESTINO,COSTO)`, con costo entero **no negativo**; conexiones dirigidas; duplicados admitidos. Dijkstra con costos `i128` y suma verificada contra overflow. Requiere nodos realmente presentes. Máximo de 200.000 aristas por consulta para proteger la memoria.
- `.min` sobre una base lógica significa **camino mínimo** solo cuando se pasan relación, origen y destino. `base.min` sin parámetros no tiene una interpretación única y no se acepta salvo que el propio usuario declare una relación llamada `min`.
- `~math` continúa usando variables declarativas completamente mayúsculas y dominios enteros finitos. La optimización usa poda de restricciones y *branch-and-bound*, con presupuesto de 8.000.000 nodos de búsqueda y hasta 64 variables. Conserva **únicamente la mejor solución** en lugar de enumerarlas todas; se detiene anticipadamente solo al alcanzar un extremo global del dominio del objetivo.
- No se garantiza que cualquier problema gigante sea resoluble; algunos problemas combinatorios son intratables y devolverán un error explícito de presupuesto.
- `Symbolic.factor` implementa extracción **estructural** de factor común. `.expand` aplica distribución con profundidad acotada; ninguna de ellas es un sistema completo de álgebra computacional con cálculo diferencial, integrales o ecuaciones reales generales.
- `~logic.why` **no es una demostración formal general**. Devuelve el resultado comprobado y evidencia de ruta cuando puede encontrarla. Para otros predicados declara explícitamente que la consulta fue verificada, sin inventar una prueba detallada.
- `.first` sobre una consulta abierta ya calculada **no es un productor perezoso auténtico**. Las consultas existentes pueden seguir materializando Arrays; el optimizador `.min/.max` sí evita enumerar materialmente todas las soluciones en los problemas matemáticos admitidos.
- Las referencias `!` se capturan con el mecanismo del runtime. Una consulta de ruta construye su instantánea de los datos de entrada; no muta los Arrays externos.

## Pruebas y comandos Windows

Desde la raíz del proyecto (donde está `Cargo.toml`):

```powershell
cargo check --all-targets
cargo test --test declarativo_etapa1_tests -- --nocapture
cargo test --test declarativo_etapa2_tests -- --nocapture
cargo test --test declarativo_etapa3_tests -- --nocapture
cargo test --all-targets
.\VERIFICAR_ENTREGA3_FINAL.cmd
```

También se incluye `VERIFICAR_ESTRES_ENTREGA3.cmd` (requiere Python 3 para generar archivos `.yek`). Sus grafos de 10.000 aristas y árbol de 4.095 nodos son escenarios artificiales reproducibles; no prueban por sí solos todos los perfiles de carga de aplicaciones reales.

## Alcance final y evolución futura

La entrega cierra la **API de grafos, optimización básica, álgebra simbólica estructural y métodos nativos sobre valores** prevista para esta fase. Quedan fuera de la garantía de esta versión: razonamiento algebraico general estilo CAS, programación matemática entera industrial sin límites de recursos, unificación sobre Arrays arbitrariamente anidados y flujo de inferencias totalmente perezoso. Requieren desarrollo independiente y no deben presentarse como ya disponibles.
