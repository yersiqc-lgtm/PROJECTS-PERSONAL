# YEK v0.0.9.1 — Entrega 3: modificadores y objetos avanzados

**Estado: CANDIDATA.** Construida sobre Entrega 2 HOTFIX H03. En el entorno de preparación no están disponibles `cargo` ni `rustc`: los resultados de compilación y pruebas que aparecen como objetivos no han sido ejecutados aquí. Mantener H03 como respaldo.

## Idea principal

La firma universal es `nombre(parametros) = ~directiva(modificadores)`. Los parámetros están a la izquierda y los modificadores se aplican **solo a esa directiva**, sin crear palabras reservadas globales ni alterar `~block nombre(...)` antiguo, `~logic`, `~math`, módulos, ValuePack o las reglas de `?`/`!`.

## Modificadores admitidos y restricciones

| Directiva | Modificador | Semántica y límite |
|---|---|---|
| `~code` | `pure` | Solo expresiones de retorno sin efectos, que dependen de sus parámetros y literales; rechaza lecturas globales, entrada, salida, acceso a miembros y llamadas arbitrarias. |
| `~code` | `cache` | **Requiere `pure`**. Memoiza por argumentos efectivos (incluidos los defaults). Solo claves/resultados escalares inmutables o ValuePacks de ellos. Arrays, clases y referencias mutables como claves están excluidos. |
| `~code` | `trace` | Emite `[trace] begin` y `[trace] end`; incompatible con `pure`. |
| `~block` operativo | `once` | Después de una ejecución exitosa no vuelve a ejecutar; aliases del mismo bloque comparten estado. |
| `~block` operativo | `when=expr` | Ejecuta únicamente si una condición booleana pura, basada en los parámetros, es verdadera. |
| `~block` operativo | `atomic` | Revierte cambios de celdas, objetos, variables, estado anónimo, estado de una sola vez y memoización **cuando hay un error**. No puede deshacer texto ya escrito, consumo de entrada ni operaciones externas. |
| `~block` operativo | `trace` | Muestra inicio y fin al ejecutarse. |
| `~struct`, `~class` | `guard=expr` | Valida al construir; Struct vuelve a validar `.with`, Class vuelve a validar cada escritura de campo. La expresión debe ser pura y depender solo de los parámetros/campos. |
| `~struct`, `~class` | `private` | Campos ocultos desde fuera; métodos siguen públicos salvo lista explícita de `~export`. |

Los modificadores no reconocidos producen **errores**, no se ignoran. No se admite un valor tras modificadores de bandera (`pure=...`, `once=...`, etc.).

## Contextual `~export` para tipos

```yek
~code
Cuenta(saldo=0) = ~class(private,guard=saldo>=0)
    ~export ver, ingresar
    ver = ~code
        -> self.saldo
    ingresar(n) = ~block
        self.saldo = self.saldo+n

c = Cuenta(5)
c.ingresar(7)
c.ver!
```

Salida prevista: `12`. La lista `~export` dentro de un tipo controla miembros del tipo; `~export` de archivos sigue controlando la API del módulo. La primera versión contextual **no** admite alias `as` dentro del tipo. Con `private` sin `~export`, los métodos son públicos y los campos privados. Con lista explícita, solamente sus miembros están expuestos. No debe utilizarse esta visibilidad como límite de seguridad frente a código malicioso arbitrario.

## Métodos y vistas

- **Struct** `.with("campo",valor)` crea un nuevo Struct por valor, sin mutar el anterior, y vuelve a enlazar correctamente el `self` de sus métodos. `.snapshot` devuelve copia por valor.
- **Class** `.snapshot` genera un Struct inmutable con los campos actuales, sin compartir campos Array mutables. Las clases conservan identidad entre copias ordinarias `b=a`.
- **Ambos** `.validate` devuelve `true` cuando el estado cumple la guarda, `.rows` crea un Array de un ValuePack (relación de una fila). Se conservan `.values`, `.fields` y `.entries` de la segunda entrega.
- Las vistas y snapshots completos no exponen indiscriminadamente campos privados desde el exterior.
- Una referencia explícita `r=obj.campo!` puede vincular un campo de Class **público no protegido por guarda**. Los campos de clases con `guard` rechazan alias mutable para no eludir sus invariantes. Las exportaciones de módulos siguen siendo de solo lectura.
- Un `~block` operativo sin parámetros puede componerse de forma diferida con `.then(otroBloque)`; `a.then(b)` produce un **nuevo bloque** que hay que invocar. No convierte `~code` en `~block`.

## Ejemplos

```yek
~code
suma(a,b=10)=~code(pure,cache)
    -> a+b
suma(3)!
suma(3)!
```

Salida: `13`, `13`.

```yek
~code
saludo=~block(once)
    "hola"
saludo
saludo
```

Salida: `hola` una sola vez.

```yek
~code
P(x)=~struct(guard=x>=0)
    doble=~code
        -> self.x*2
p=P(3)
q=p.with("x",8)
p.doble!
q.doble!
```

Salida: `6`, `16`.

```yek
~code
primera=~block
    "A"
segunda=~block
    "B"
secuencia=primera.then(segunda)
secuencia
```

Salida: `A`, `B`.

## Qué NO incluye esta candidata

- Herencia clásica, interfaces/protocolos estructurales formales o tipado estático integral.
- `defer`, transacciones sobre red/archivos o persistencia automática de objetos temporales.
- Modificadores que no figuran en la tabla; no se aceptan como no-ops.
- `~block(when=...)` con llamadas o efectos; las condiciones son expresiones puras de parámetros.
- Automatización de transacciones entre `~logic`, `~math` y recursos externos.

Estas capacidades no deben anunciarse como implementadas sin una especificación separada y pruebas.

## Validación obligatoria en Windows

Desde la carpeta con Cargo.toml:

```powershell
cargo check --all-targets
cargo test --test objetos_avanzados_entrega3_tests -- --nocapture
cargo test --test sintaxis_universal_entrega2_tests
cargo test --test objetos_firmas_etapa1_tests
cargo test --test qa_h02_sintaxis_universal_tests -- --nocapture
cargo test --test qa_h02_sintaxis_universal_tests -- --ignored --nocapture
cargo test --all-targets
```

**Aviso:** algunas pruebas antiguas de estrés tienen `#[ignore]` deliberado. Ejecutar pruebas de carga costosas solo de manera controlada.
