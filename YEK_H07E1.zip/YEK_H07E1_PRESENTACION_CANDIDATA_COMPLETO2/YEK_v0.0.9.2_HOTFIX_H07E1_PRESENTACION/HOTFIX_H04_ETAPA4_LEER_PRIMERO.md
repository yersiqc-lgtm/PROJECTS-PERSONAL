# YEK v0.0.9.2 — Hotfix H04 / Reglas generales de parámetros y ValuePack

Esta actualización parte de H03C, manteniendo `vlen` y las correcciones anteriores. El objetivo es **una semántica única** para las llamadas y las referencias, no excepciones por nombre de función.

## 1. Convención estable de ValuePack

```yek
~code
a=(1,2)

cambiar(p)=~code
    p=(20,2)

cambiar((a))  ~ pasar un solo ValuePack por valor
a!             ~ (1, 2); la asignación interna no afecta a `a`
```

```yek
~code
a=(1,2)

cambiar(p)=~code
    p=(20,2)

cambiar((a!)) ~ pasar un solo ValuePack por referencia
a!            ~ (20, 2); la asignación cambia el contenido de `a`
```

- `f(a)` sigue **expandiendo** un ValuePack de dos miembros en dos argumentos independientes.
- `f((a))` ofrece **un solo argumento**, que es una copia del paquete.
- `f((a!))` ofrece **un solo argumento**, que es una referencia viva al paquete.
- Los miembros de ValuePack NO se vuelven mutables por índice. `a[0]=90` sigue siendo inválido si `a` es ValuePack; el tipo apropiado para mutación por índice es Array.
- La diferencia de paso se aplica también a llamadas de Code y a los canales de llamada que evalúan argumentos (incluidos argumentos nombrados y constructores).

## 2. Contrato de referencia en la firma

```yek
~code
f(x!)=~code
    x=90

a=10
f(a!)
a!  ~ 90
```

`f(x!)` **exige** un argumento por referencia. `f(a)` y `f(10)` se rechazan, mientras `f(a!)` es válido. Un parámetro sin el marcador `!` conserva el contrato previo: recibe una copia o una referencia según el argumento que envíe quien llama.

El requisito se incorpora en las estructuras compartidas de funciones `~code`, `~block`, constructores `~struct` / `~class` y bloques nombrados `~block nombre(x!)` transferidos mediante `go nombre(a!)`. También se conserva durante la resolución de módulos y en código enlazado. No implica que los parámetros internos de un *builtin* se puedan redeclarar desde YEK.

Los parámetros marcados `!` no admiten valores por defecto. El intérprete valida las referencias antes de asignar o ejecutar el cuerpo de la función. **Los `!` activos de cadenas y las expresiones con operadores conservan su propia semántica.**

## 3. Analizador de texto activo

Los operadores `!` y `?` dentro de cadenas siguen siendo activos y requieren el operando adyacente, sin espacio, cuando se pretende unir una expresión. `"c.value!"` evalúa ahora la ruta `c.value` completa; también se reconocen accesos e índices encadenados, llamadas y agrupaciones. La forma `"(~math 2+5)!"` se evalúa en la gramática matemática. Fuera de paréntesis, **los operadores infijos complejos deben mantenerse agrupados** para no confundir texto con código.

`"variableInexistente!"` seguirá fallando. `"hola\\!"` sigue siendo la forma de imprimir una exclamación literal.

## 4. Etiqueta de ausencia

```yek
~code
true="verdad"
false="falso"
none="nada"
none!
```

`none="nada"` **no asigna a una variable**, sino que modifica la representación visible del literal `none` en el contexto actual. No cambia su tipo, igualdad, nulidad, identidad o conversión. `none=3` y `none,otro=...` siguen siendo errores. La configuración es local a cada llamada, igual que las etiquetas Bool.

Las antiguas pruebas que prohibían *cualquier* asignación a `none` se actualizaron según esta nueva especificación: las asignaciones numéricas todavía son inválidas.

## 5. Colecciones y compatibilidad

No se modifica la semántica de Array, Map ni Set. Map conserva sus escrituras por clave permitidas; Set mantiene su garantía de elementos únicos; ValuePack continúa siendo distinto de Array. La función hipotética `set.replace` queda fuera de H04 hasta establecer su contrato de duplicados, orden e identidad.

## Verificación en Windows

1. `cargo build`
2. `cargo test --test etapa4_h04_semantica_global_tests`
3. `cargo test`
4. `py -3 EJEMPLOS_H04_REFERENCIAS_PACK\ejecutar_casos_h04.py`

O ejecutar `VERIFICAR_H04_ETAPA4.cmd` desde el proyecto. Hay **32 casos `.yek` independientes** que generan `RESULTADOS_H04/REPORTE_PARA_CHATGPT.txt` con las diferencias.

**Estado de verificación de esta entrega:** modificaciones e integridad de archivos comprobadas estáticamente. No hay Cargo disponible en el entorno de preparación: faltan la compilación y la ejecución real de regresiones en Windows antes de considerarlo completamente aprobado.
