# YEK — Penúltima entrega experimental: integración declarativa

Base: **v0.0.9.0 HOTFIX E0004** (se conservan los archivos del proyecto y la suite histórica).

## Qué se ha incorporado

- `relacion(A,B) <- filas` dentro de `~logic` importa una instantánea de un Array de ValuePacks (o un ValuePack como una sola fila).
- `relacion(A,B) <- filas!` consulta de nuevo la fuente viva al comenzar cada consulta. En ambos casos, las consultas usan una vista fija mientras se ejecutan.
- Se comprueba aridad por fila y se admiten solo elementos escalares (Text, Bool, Number entero); no se permite anidamiento de Arrays en filas.
- Las reglas de `~logic` pueden usar `calculo.suficiente(N)` si `calculo` es una variable que contiene un bloque `~math`. Los argumentos deben estar vinculados al momento de la llamada. Las reglas nunca ejecutan comandos generales de `~code`.
- `not relacion(X,Y)` con semántica de ausencia en la base conocida y evaluación por estratos; se rechaza recursión negativa. Una variable usada únicamente dentro de `not` funciona como patrón existencial.
- Índice en memoria por nombre de relación para la resolución de reglas, con límites de hechos y candidatos.
- `.relacion!` / `.bloque!` (o sin `!` dentro de expresiones) equivalen a una llamada sin argumentos. Las llamadas con `()` siguen funcionando; los módulos y Code normales conservan la semántica previa.
- Para espacios matemáticos con más de 200 000 combinaciones teóricas se incorpora búsqueda por prefijos con descarte de restricciones que ya son falsas; hay presupuesto de 2 000 000 nodos y un máximo de 20 000 soluciones. La búsqueda original se conserva para espacios pequeños.
- La protección contra referencias que escapan de funciones también inspecciona contenedores Array y ValuePack anidados.

## Límites deliberados

- No hay optimización global (`.min()`, `.max()`), rutas ponderadas, explicación `why()` ni álgebra simbólica general. Esos motores se reservan para la entrega final.
- No se crean productores perezosos todavía: las consultas producen Arrays materializados, con límites defensivos.
- La integración Math → Logic admite usar **soluciones materializadas en Arrays** como relaciones. No admite unificación de incógnitas matemáticas sin vincular desde una regla lógica.
- Las fuentes enlazadas con `!` se evalúan en cada consulta; todavía no existe un observador reactivo que lance acciones automáticamente.
- Los nombres de receptores matemáticos utilizados dentro de las reglas se resuelven al consultar, por lo que deben estar accesibles en el ámbito de ejecución.
- No se cambia globalmente el significado de mayúsculas, `<-`, `in`, `not`, ni `~block` fuera de los modos declarativos.

## Comprobación Windows (CMD)

Abre CMD en el directorio que contiene `Cargo.toml`:

```bat
cargo check --all-targets
cargo test --test declarativo_etapa1_tests
cargo test --test declarativo_etapa2_tests -- --nocapture
cargo test --all-targets
VERIFICAR_ENTREGA2_DECLARATIVA.cmd
```

El script final vuelve a ejecutar comprobaciones anteriores y el QA integral. Para guardar la salida:

```bat
VERIFICAR_ENTREGA2_DECLARATIVA.cmd > resultado_entrega2.txt 2>&1
echo %ERRORLEVEL%
notepad resultado_entrega2.txt
```

Ejecuta un programa manual:

```bat
cargo run -- run ejemplos/etapa2_integracion/01_tres_arrays_logic_math.yek
```

## Estado

**Candidato experimental que requiere compilación y ejecución en el entorno del usuario.** En este entorno no hay `rustc` ni `cargo`, por lo que las pruebas nuevas no se han ejecutado y no se afirma que estén aprobadas. Conserva la versión estable de la Entrega 1 separada hasta completar QA.
