#!/usr/bin/env python3
"""Check H04C without touching interpreter code; requires Python 3 and Cargo."""
import json
import os
import subprocess
import sys
from pathlib import Path

folder = Path(__file__).resolve().parent
project = folder.parent
manifest = json.loads((folder/'MANIFIESTO.json').read_text(encoding='utf-8'))
results = folder/'RESULTADOS_H04C'
results.mkdir(exist_ok=True)
print('Preparando ejecutable YEK (solo una compilacion)...', flush=True)
try:
    build = subprocess.run(['cargo','build','--quiet','--manifest-path',str(project/'Cargo.toml')],
                           cwd=str(project),timeout=180,check=False)
except (OSError, subprocess.TimeoutExpired) as exc:
    print('No fue posible compilar YEK:',exc)
    sys.exit(2)
if build.returncode != 0:
    print('La compilacion fallo; primero corrige cargo build.')
    sys.exit(2)
exe = project/'target'/'debug'/('yek.exe' if os.name == 'nt' else 'yek')
rows = []
for entry in manifest:
    file = folder/entry['archivo']
    try:
        proc = subprocess.run([str(exe),'run',str(file)],capture_output=True,
            encoding='utf-8',errors='replace',timeout=12,cwd=str(project))
        stdout=proc.stdout.replace('\r\n','\n')
        stderr=proc.stderr.replace('\r\n','\n')
        if entry['tipo']=='exito':
            expected='\n'.join(entry['esperado'])+'\n'
            good=proc.returncode == 0 and stdout==expected
            detail='Salida correcta' if good else f'Esperado {expected!r}; recibido {stdout!r}; stderr {stderr!r}'
        else:
            good=proc.returncode != 0 and entry['esperado'] in stderr
            detail='Error controlado correcto' if good else f'Exit {proc.returncode}; stdout {stdout!r}; stderr {stderr!r}'
    except subprocess.TimeoutExpired:
        good=False;detail='Timeout de 12 segundos'
    except OSError as exc:
        good=False;detail=str(exc)
    rows.append({'id':entry['id'],'estado':'OK' if good else 'FALLO','archivo':entry['archivo'],'detalle':detail})
    print(entry['id'], 'OK' if good else 'FALLO')
failed=[r for r in rows if r['estado']=='FALLO']
lines=['YEK H04C - VERIFICACION DE CADENAS ACTIVAS',
       f'Total: {len(rows)} | OK: {len(rows)-len(failed)} | FALLIDOS: {len(failed)}','']
for item in failed:
    lines += [f"{item['id']} [FALLO] {item['archivo']}",item['detalle'],'']
if not failed: lines.append('Todos los casos del laboratorio H04C coinciden con los oraculos definidos.')
(results/'REPORTE_PARA_CHATGPT.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
(results/'resultados.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
print('\n'.join(lines[:2]))
print('Informe:',results/'REPORTE_PARA_CHATGPT.txt')
sys.exit(1 if failed else 0)
