# YEK v0.0.8.7 — Módulos, miembros y biblioteca estándar inicial

## Migración desde v0.0.8.6

**IMPORTANTE**: si VS Code sigue configurado con `yek.manifestPath` apuntando a la v0.0.8.5, ejecutará la versión antigua incluso cuando edites archivos dentro de la carpeta nueva. Actualiza `yek.manifestPath` para que apunte al `Cargo.toml` de esta versión, o ejecuta `cargo run --manifest-path ...` con la ruta nueva.

El ejemplo de las capturas importa `02_calificaciones_y_filtro.yek`. Ese archivo de pruebas no exporta `sumaAB`. Debes crear `calculos.yek` con una función `sumaAB` y una declaración `~export sumaAB`, o probar el ejemplo suministrado.

## Expresiones con punto

`objeto.miembro` ahora se representa como nodo `Expr::Member` del AST, con encadenamiento recursivo. La etapa de ejecución resuelve miembros exportados de módulos y funciones importadas. Los accesos a miembros de futuras instancias de clases o registros **no están implementados todavía**: solo está preparado el punto de extensión arquitectónico. `1.25`, `1..3` y `<>` mantienen su semántica.

## Importaciones

```yek
~import "calculos.yek" as calc
~import math
~import str
~import math.square as cuadrado
~import str.len as longitud
~import "calculos.yek".sumaAB as sumar
~import "notas.txt" as notas
~import(math, str.len, "calculos.yek" as calc, "notas.txt" as notas)
```

La sintaxis de lista admite varias líneas y comas entre elementos.

**Importar módulos `.yek`** los carga en un ámbito privado, con inicialización como máximo una vez por ruta canónica y ejecución. Solo los símbolos incluidos en `~export` son accesibles. Las funciones exportadas pueden conservar acceso a su ámbito original. El cargador rechaza ciclos y alias duplicados. Las rutas relativas se resuelven desde el archivo importador.

**Importar texto `.txt`** produce una variable `Text`; no interpreta ni evalúa ese contenido. Archivos de más de 8 MiB o codificados fuera de UTF-8 producen un error controlado. Las importaciones de datos no están pensadas todavía para bytes arbitrarios, JSON o CSV.

**Importar `math`** carga el archivo `stdlib/math.yek` escrito en YEK. Primera colección: `math.square(x)`, `math.cube(x)`, `math.add(a,b)`, `math.abs(x)`. Solo es un módulo inicial, no un conjunto matemático completo.

**Importar `str`** registra primitivas iniciales escritas en Rust, disponibles como `str.len(text)`, `str.vlen(text)`, `str.lower(text)`, `str.upper(text)` y `str.count(text, substring)`; también pueden importarse de forma selectiva. `len` cuenta puntos de código Unicode, mientras que `vlen` cuenta grafemas Unicode extendidos (aproximación a los caracteres percibidos). `count` no acepta subcadena vacía.

Las funciones de `math` sirven como ejemplo real de funciones de la biblioteca estándar escritas en YEK. Las primitivas de `str` requieren Rust hasta que construyamos las herramientas suficientes para expresarlas eficientemente dentro de YEK.

## Condiciones y límites

* Las importaciones se admiten solo en el nivel superior del modo `~code`.
* `~text` y `~invalid` no ejecutan importaciones.
* La lista de archivos `.txt` se almacena como texto, no como módulo ejecutable.
* Los símbolos exportados no se pueden sobrescribir directamente desde el importador.
* Las importaciones selectivas de archivos `.yek` utilizan `~import "archivo.yek".simbolo as alias`.
* Los módulos estándar disponibles inicialmente son `math` y `str`; `math.lower.count` no es un símbolo disponible.
* Los miembros de instancias de estructuras y clases, sobrecarga de `.` y escritura de propiedades serán objeto de entregas posteriores.
* Las importaciones de código `.yek` ejecutan su inicialización: no importes módulos de origen desconocido.

## Ejecución

Desde la raíz del proyecto:

```powershell
cargo test --test modulos_v0087_tests -- --nocapture
cargo test
cargo check
cargo run -- run examples/modulos_v0087/main.yek
```

Salida esperada del ejemplo completo:

```text
100
27
64
8
YEK v0.0.8.7 - importacion de texto sin ejecucion.

```

Nota: el archivo `notas.txt` termina con salto de línea; por eso la impresión añade una segunda línea vacía.

**Estado**: entrega candidata. Aquí se validó la estructura de archivos y el diseño de pruebas, pero no se ejecutaron Cargo ni Rustc. No declararla estable hasta compilar y pasar los tests en tu equipo.
