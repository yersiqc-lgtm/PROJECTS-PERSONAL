# Migración y contrato de YEK v0.0.8.5

## 1. Desigualdad

Desde ahora se utiliza `<>` para comparar desigualdad. Sigue existiendo
`not` como operador booleano unario: `not (a==b)` es equivalente a
`a<>b` en los valores comparables.

```yek
a=2
(a<>3)!
(not (a==3))!
```

Salida:

```text
true
true
```

El antiguo `!=` se rechaza deliberadamente: un fallo claro es preferible
a interpretaciones silenciosas. Los programas previos deben migrarse.

## 2. Referencias

`!` NO desaparece del lenguaje: conserva la referencia a celdas, la
activación de Code y la salida. En un encabezado `for` la vinculación
por referencia sigue necesitando `=` separado del `!` del patrón.

```yek
a=[1,2,3]
for(x! = a)
    x=x+5
a!
```

Salida: `[6, 7, 8]`.

`for(x <> a)` NO realiza este trabajo; `<>` representa comparación y
puede formar una condición, no un binder.

## 3. ValuePack unitario

- `(1)` agrupa el escalar 1 y produce `1`.
- `(1,)` construye un ValuePack con un único valor.
- `((1,),)` es un ValuePack que contiene otro ValuePack.
- `[]` siempre crea un Array, incluidos los Arrays de un elemento.

Por coherencia el sistema ahora imprime `(1,)` (no `(1)`) para
ValuePacks unitarios. Esto modifica la salida textual observable de los
programas, pero NO elimina ni añade automáticamente elementos.

## 4. Corrigiendo las expectativas de QA

- 14 casos `bucles_mutacion_ref_01..14`: `x! = a`.
- `colecciones_repetir_pack_01`: `(1,)*1` -> `(1,)`.
- `colecciones_division_pack_01`: `[(1,)/1]` -> `[(1,)]`.
- Todos los resultados de divisiones de ValuePacks con grupos de un
  único elemento usan coma final.
- `entrada_reintento`: dos intentos inválidos producen dos mensajes `retry`.
- `entrada_texto_interactivo`: la entrada se imprime explícitamente.

## 5. Criterios de aceptación

```powershell
cargo test --test sintaxis_clara_v0085_tests -- --nocapture
cargo test --test qa_exhaustiva_fixtures_tests -- --nocapture
cargo test
cargo check
```

También es aconsejable probar manualmente software existente que use
`!=` y migrarlo. El proyecto no acepta `!=` como alias de `<>`: es un
cambio intencional e incompatible.
