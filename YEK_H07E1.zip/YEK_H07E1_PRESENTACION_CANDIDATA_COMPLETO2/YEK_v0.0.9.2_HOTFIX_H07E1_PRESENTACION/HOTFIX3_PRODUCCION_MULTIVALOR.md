# Hotfix 3 — Corregir la pertenencia de comas tras `->`

## Problema confirmado por el usuario

Antes:

```yek
a,b,c,d = for(3)->"napa",2
a!b!c!d!
```

Salida anterior: `napa`, `napa`, `napa`, `2`.

**Causa:** el parser recursivo construía `Multi(Producer(body="napa"), 2)` en la raíz de la asignación. La coma separaba el `2` como un elemento de la asignación, evaluado **una sola vez** después de las tres iteraciones. Los productores de cuerpo indentado, por otra parte, ya evaluaban cada expresión de `->` en cada iteración.

## Regla general integrada

En el nivel raíz de la parte derecha de una asignación, si hay un productor desnudo con `->` y una secuencia de expresiones separadas por comas a su derecha, esas expresiones constituyen su **lista de retornos por iteración**. Esto vale aunque existan expresiones previas en la asignación. El AST usa `Expr::Multi` para contener la lista en `Expr::Producer.body`; no se concatena ningún valor fuera del bucle por accidente.

Las comas que están dentro de un contenedor o una llamada **pertenecen a ese contenedor/llamada**. No se pueden interpretar simultáneamente como lista de retornos del productor interno y como lista de elementos externos. Se respeta el contrato composicional anterior.

Por ejemplo:

```yek
a,b,c,d,e,f=for(3)->"napa",2
a!b!c!d!e!f!
```

Salida esperada: `napa`, `2`, `napa`, `2`, `napa`, `2`.

Y también:

```yek
a=[for(x=1..2)->(x,x*x),99]
a!
```

Salida esperada: `[(1, 1), (2, 4), 99]`. La coma antes de `99` pertenece al Array exterior.

Si se necesitan **varios valores desnudos por iteración dentro de un contenedor**, se conserva la sintaxis inequívoca con cuerpo indentado:

```yek
a=[for(x=1..3)
    -> x,x*x
]
a!
```

Salida esperada: `[1, 1, 2, 4, 3, 9]`.

`-> (x,x*x)` produce en cambio **un único ValuePack por iteración**, no dos valores desnudos.

## Otro ajuste de coherencia

`break(...)` usa `eval_values` en lugar de `eval_one` para cada retorno. Así puede conservar la misma expansión estructural que `->`, incluido un productor interno o una división estructural que genere varios valores. `break((1,2))` continúa devolviendo un solo ValuePack.

## Archivos modificados

- `src/parser/mod.rs`: `finish_assignment_rhs` para formalizar la pertenencia de la lista de retornos a un productor inline desnudo; no depende del número de destinatarios.
- `src/interpreter/mod.rs`: `Stmt::Break` expande valores mediante el mecanismo común.
- `tests/arrow_multivalor_regresion_tests.rs`: 18 comprobaciones, incluida una matriz metamórfica con 24 combinaciones de iteraciones y aridad.

No se altera el formato del AST ni la ejecución del bucle por iteración. Se modifica la construcción semántica en la frontera del parser, por lo que las demás partes del evaluador siguen operando sobre los mismos nodos (`Producer`, `Multi`, `Return`).

## Verificación requerida en Windows PowerShell

```powershell
cargo test --test arrow_multivalor_regresion_tests -- --nocapture
cargo test
cargo check
```

Este entorno de empaquetado no dispone de `cargo`/`rustc`. **No afirmar que las pruebas pasaron** hasta ejecutarlas realmente.

## Riesgos y límites explícitos

- Una coma después de un productor inline *dentro* de `[]`, `()` o una llamada se interpreta según la gramática de esos contenedores, no por la regla de raíz de asignación. Esto evita romper las pruebas de composición anidada. Para múltiples resultados por iteración dentro de contenedores, usar cuerpo indentado `-> x,y`.
- No se modifica la semántica de saltos `go`, ni se redefine el modo de pasar ValuePacks como argumentos; esa es otra discusión de contrato.
- Límites de materialización y profundidad del runtime siguen los existentes. La prueba de productor infinito continúa ignorada por defecto deliberadamente.
- Las pruebas agregadas no cubren exhaustivamente cada combinación; hay que completar QA con el compilador.
