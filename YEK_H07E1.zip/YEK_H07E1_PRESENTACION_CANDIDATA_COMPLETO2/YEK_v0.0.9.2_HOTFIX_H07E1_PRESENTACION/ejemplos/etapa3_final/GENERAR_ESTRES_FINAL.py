from pathlib import Path
out = Path(__file__).resolve().parent
# Directed chain of 10000 weighted edges; the shortest-path depth is 10000.
N=10000
lines=['~code', 'arcos = [']
lines += [f'    ("N{i}","N{i+1}",1){"," if i<N-1 else ""}' for i in range(N)]
lines += [']','red = ~logic','    arco(A,B,C) <- arcos',f'red.depth("arco","N0","N{N}")!']
(out/'ESTRES_GRAFO_10000.yek').write_text('\n'.join(lines)+'\n',encoding='utf-8')
# 4095-node binary tree: 11 edges from root to last leaf.
N=4095
lines=['~code', 'nodos = [']
lines += [f'    ("N{i//2}","N{i}"){"," if i<N-1 else ""}' for i in range(2,N+1)]
lines += [']','arbol = ~logic','    hijo(A,B) <- nodos',f'arbol.depth("hijo","N1","N{N}")!']
(out/'ESTRES_ARBOL_4095.yek').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print('Grafos de estrés generados: 10000 aristas / arbol de 4095 nodos')
