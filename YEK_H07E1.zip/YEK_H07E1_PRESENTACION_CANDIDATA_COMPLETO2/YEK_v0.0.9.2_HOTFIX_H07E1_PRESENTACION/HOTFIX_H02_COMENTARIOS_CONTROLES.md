# YEK v0.0.9.1 — Entrega 2, HOTFIX H02

## Diagnóstico

`cargo test --all-targets` compila, pero la suite histórica `for_fuentes_componibles_v0090_hotfix1_tests` falla en tres pruebas relacionadas con comentarios `~` al final de cabeceras de control. El nuevo separador de cabecera/cuerpo en línea trataba el comentario de la cabecera como una instrucción del cuerpo; podía producir `unrecognized Code directive '~' inside expression` o `for expression requires '(...)'`.

## Solución

En `src/source.rs`, `split_control_inline` aplica `clean_control_line` **antes** de separar la cabecera equilibrada y el cuerpo en línea. El escáner de expresiones preserva los productores `for` dentro de una cabecera, mientras elimina comentarios reales posteriores. La misma normalización se aplica al `~block` estructural con nombre y al tratamiento de `else`.

No se modificaron las reglas de ejecución de productores, colecciones ni el sistema de referencias; este HOTFIX trata solamente la separación léxica de comentarios en cabeceras.

## Nuevas pruebas

`tests/sintaxis_universal_hotfix_h02_comentarios_tests.rs`: ocho regresiones sobre `for`, `if`, `orif`, `else`, cuerpos en línea, cadenas con `~` y productores anidados.

## Verificación en Windows

Desde la carpeta con Cargo.toml:

```powershell
cargo check --all-targets
cargo test --test for_fuentes_componibles_v0090_hotfix1_tests -- --nocapture
cargo test --test sintaxis_universal_hotfix_h02_comentarios_tests -- --nocapture
cargo test --test sintaxis_universal_entrega2_tests -- --nocapture
cargo test --all-targets
```

Si vuelve a aparecer una regresión, conserva el registro completo y no sustituyas H03 como respaldo estable.

**Estado:** candidata de compilación. No se pudo ejecutar Rust/Cargo en el entorno de preparación.
