# Ejemplos para copiar y comparar

Para cada fragmento abre un archivo `.yek` o usa las pruebas automatizadas.

### A. Multiplicación sin nueva dimensión

```yek
a=[1,2]*2
a!
```

Esperado: `[1, 2, 1, 2]`

### B. Repetir contenedores completos, de manera explícita

```yek
a=[[1,2]]*2
a!
```

Esperado: `[[1, 2], [1, 2]]`

### C. Dos destinatarios para la división

```yek
a,b=[1,2,3]/2
a!
b!
```

Esperado (dos líneas): `[1, 2]` y `[3]`.

### D. Un solo destinatario para dos resultados (error esperado)

```yek
a=[1,2,3]/2
```

Esperado: error de aridad (`expression returns 2 value(s) ...`).

### E. Colección explícita

```yek
a=[[1,2,3]/2]
a!
```

Esperado: `[[1, 2], [3]]`.

### F. Prefijo y residuo

```yek
a=[1,3,4]
b=a//2
c=a%2
b!
c!
```

Esperado (dos líneas): `[1, 3]` y `[4]`.

### G. Operaciones combinadas y precedencia

```yek
a=([1,2,3,4,5]//2+[10,20])*2
a!
```

Esperado: `[1, 2, 3, 4, 10, 20, 1, 2, 3, 4, 10, 20]`.

### H. Operadores numéricos conservados

```yek
a=7//3
b=-7//3
c=7/2
a!
b!
c!
```

Esperado: `2`, `-3`, `3.5`.

**Advertencia:** son expectativas de contrato, todavía no verificadas con compilación de Rust en este entorno. El proyecto también incluye la suite automatizada, con verificaciones metamórficas y regresiones históricas.
