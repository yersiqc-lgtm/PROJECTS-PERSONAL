# YEK — Entrega 1/3: `~logic` y `~math` contextuales (experimental)

**Base utilizada:** YEK `0.0.9-alpha.0` HOTFIX1 FOR COMPOSICIONAL, sin sustituir los archivos de regresión originales.

## Estado de validación

**No se ha compilado ni ejecutado `cargo test` en el entorno de edición.** No había `rustc` ni `cargo`, y la instalación a través de apt no pudo completarse por falta de acceso a repositorios. Por tanto, la entrega es una **implementación candidata** con pruebas automatizadas añadidas pero **NO está certificada como compilable o estable**. No utilizarla como sustituto de la ZIP estable sin ejecutar la verificación incluida.

Los controles efectuados en el entorno son estáticos: inventario de archivos, comprobación de delimitadores de los archivos Rust modificados y comprobación independiente de ejemplos matemáticos. No confundir esas comprobaciones con ejecutar el intérprete.

## Implementaciones incorporadas al código Rust

- `valor = ~logic` con bloque indentado, hechos sin `~fact`, reglas `CABEZA <- CONDICIONES` sin `~rule` y `~block` para organizar predicados. Nombres completamente ASCII mayúsculos son variables de unificación **solo en este contexto**. Nombres mixtos y minúsculos son capturas externas. Un nombre externo terminado en `!` preserva una referencia viva a la celda original; sin `!` guarda una instantánea al construir la base.
- Consultas por miembros `base.predicado()`, `base.predicado(arg)`, `base.predicado(arg1,arg2)`, y `base.bloque.predicado()`; huecos de argumentos como `base.progenitor(,"Sofia")`. Consulta totalmente determinada devuelve Bool; las consultas abiertas devuelven un Array cuyos elementos son valores o ValuePacks si hay más de una incógnita. El Array puede utilizarse con `for`.
- Deducción bottom-up con reglas positivas recursivas, comparación de enteros `==`, `<>`, `<`, `>`, `<=`, `>=`, deduplicación y límites de hechos, candidatos y rondas.
- `algebra = ~math` admite `~block nombre` o `~block nombre(A,B,...)`. Las condiciones `A in 1..4`, relaciones aritméticas, `or` y las consultas a bloques funcionan en dominios **enteros y finitos**. Las restricciones con parámetros concretos y sin dominios funcionan como predicados Bool.
- Capturas matemáticas como `formula = ~math 3(X+4)` pueden conservar árboles simbólicos con identificadores mayúsculos. En grupos de reglas se admite `distribuir(A,B,C) <- A*(B+C) == A*B+A*C`; invocable como `algebra.reglas.distribuir(formula)` por coincidencia estructural. También se soporta un `~block formula` con una única expresión simbólica y consulta `.formula()`.
- Tanto `~math` como `~logic` almacenan instantáneas de valores externos ordinarios y referencias vivas por `!` cuando corresponda. Los bloques no cambian el significado de mayúsculas, `<-` ni `~block` en el `~code` existente.

## Limitaciones explícitas de la Entrega 1

- **No** constituye Prolog completo: sin negación, corte, funciones recursivas arbitrarias, estructuras anidadas, list matching, constraints por dominios infinitos o consultas perezosas.
- En `~logic` los hechos, reglas y comparaciones admiten variables/átomos/números enteros y Booleanos, no expresiones aritméticas generales en cada término. El orden de las premisas es relevante: una comparación debe usar variables ya vinculadas mediante relaciones anteriores.
- En `~math` la búsqueda usa enumeración de dominios **inclusivos** con máximo de 200.000 combinaciones y 20.000 resultados. Su evaluación aritmética es entera, con divisiones exactas para `/`. No hay optimización `.min/.max`, algoritmos de CSP, ni búsqueda perezosa todavía.
- La reescritura algebraica es **estructural**, no una simplificación polinómica general ni un sistema de álgebra computacional completo. `distribuir` reconoce patrones compatibles con su AST.
- No hay interop automática de metas `matematicas.condicion(N)` **dentro del cuerpo de una regla** lógica todavía. Desde `~code`, ambos motores pueden consultarse por separado.
- `~block` en `~logic` organiza nombres, pero se exige que una relación pertenezca a un solo grupo. El motor comparte sus relaciones dentro de la base para inferencia recursiva.
- El parser matemático todavía no acepta `abs`, funciones trigonométricas ni colecciones dentro de restricciones. Referencias numéricas externas deben representar enteros al usar los nuevos solver y los predicados.
- Para este primer prototipo se reservan mayúsculas **A–Z ASCII** dentro de `~logic` y la representación simbólica de `~math`; no se amplió aún a identificación Unicode. En `~code`, se preserva el comportamiento anterior de los identificadores mayúsculos.
- El motor no garantiza rendimiento óptimo en grafos grandes. Los límites de seguridad son intencionales, y las consultas se recalculan cuando hay referencias vivas.

## Archivos nuevos / modificados

- Nuevo `src/declarative.rs`: estructuras y semánticas de lógica, restricciones y patrones matemáticos.
- Modificados `src/source.rs`, `src/ast/mod.rs`, `src/interpreter/mod.rs`, `src/lib.rs`.
- Nuevos `tests/declarativo_etapa1_tests.rs` y cuatro ejemplos en `ejemplos/etapa1_declarativo/`.
- Nuevos `VERIFICAR_ETAPA1_DECLARATIVA.cmd` y `.sh`.

## Cómo comprobar en el equipo con Rust instalado

1. Descomprimir el ZIP sin sobrescribir la versión estable.
2. Desde la raíz del proyecto, ejecutar `cargo test --test declarativo_etapa1_tests`.
3. Después `cargo test --tests` para verificar las pruebas históricas.
4. Ejecutar `cargo run -- run ejemplos/etapa1_declarativo/01_familia.yek`, `02_grafo.yek`, `03_math.yek` y `04_math_expresion.yek`.
5. Si alguna prueba falla, conservar el mensaje de compilación/error para corregir la candidata. **No dar por aprobado el release sin compilar y ejecutar los tests.**

## Plan de siguientes entregas

- **Entrega 2:** integración entre metas lógico-matemáticas, control formal de reglas seguras, mejor propagación de restricciones y deduplicación/índices de consultas. Ajustes de rendimiento para grafos grandes y resultados perezosos.
- **Entrega 3:** motores especializados para optimización, análisis de rutas y explicación de pruebas, y nuevas bibliotecas sin proliferar directivas globales. Consolidación y regresión integral.

## Decisión de diseño que se preserva

**La sintaxis especial solo es interpretada en los cuerpos capturados de `~logic` y `~math`.** Los bloques `~code` anteriores no reciben ninguna nueva semántica declarativa de manera implícita.
