#!/usr/bin/env python3
"""Laboratorio H05. Ejecuta los .yek, captura resultados y genera reporte."""
import argparse, csv, json, os, subprocess, sys
from pathlib import Path

BASE=Path(__file__).resolve().parent
MANIFEST=json.loads((BASE/'manifest.json').read_text(encoding='utf-8'))

def project_root(start):
    for parent in [start, *start.parents]:
        manifest=parent/'Cargo.toml'
        if manifest.exists() and 'name = "yek"' in manifest.read_text(encoding='utf-8'):
            return parent
    raise SystemExit('No se encontro Cargo.toml de YEK. Coloca la carpeta de pruebas dentro del proyecto H05.')

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--desde',default=None)
    p.add_argument('--hasta',default=None)
    p.add_argument('--sin-build',action='store_true')
    p.add_argument('--auditar',action='store_true')
    args=p.parse_args()
    if args.auditar:
        bad=[]
        for case in MANIFEST:
            if not (BASE/case['file']).is_file():bad.append(case['file'])
        print(f'{len(MANIFEST)} casos; {len(bad)} archivos faltantes')
        if bad:print('\n'.join(bad));sys.exit(1)
        return
    root=project_root(BASE)
    exe=root/'target'/'debug'/('yek.exe' if os.name=='nt' else 'yek')
    if not args.sin_build:
        print('Compilando YEK ...',flush=True)
        subprocess.run(['cargo','build','--quiet'],cwd=root,check=True)
    if not exe.is_file():raise SystemExit(f'No existe el ejecutable: {exe}; ejecuta cargo build.')
    results=[]
    selected=[x for x in MANIFEST if (not args.desde or x['id']>=args.desde) and (not args.hasta or x['id']<=args.hasta)]
    for case in selected:
        file=(BASE/case['file']).resolve()
        try:
            proc=subprocess.run([str(exe),'run',str(file)],cwd=root,text=True,encoding='utf-8',errors='replace',capture_output=True,timeout=15)
            if case['kind']=='success':
                ok=proc.returncode==0 and proc.stdout.replace('\r\n','\n')==case['stdout']
            else:
                ok=proc.returncode!=0 and case['error_contains'] in proc.stderr
            status='OK' if ok else 'FALLO'
            entry={**case,'estado':status,'exit_code':proc.returncode,'stdout_real':proc.stdout,'stderr_real':proc.stderr}
        except subprocess.TimeoutExpired:
            status='FALLO';entry={**case,'estado':status,'exit_code':'TIMEOUT','stdout_real':'','stderr_real':'Tiempo limite superado'}
        results.append(entry)
        print(f"{case['id']} {status} {case['name']}")
    folder=BASE/'RESULTADOS_H05';folder.mkdir(exist_ok=True)
    with (folder/'resultados.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f);w.writerow(['ID','Tipo','Resultado','Codigo salida','stdout','stderr']);
        for r in results:w.writerow([r['id'],r['kind'],r['estado'],r['exit_code'],repr(r['stdout_real']),repr(r['stderr_real'])])
    (folder/'detalles.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
    bad=[x for x in results if x['estado']!='OK']
    msg=[f'YEK H05 - {len(results)} pruebas; {len(results)-len(bad)} aprobadas, {len(bad)} fallidas','']
    for x in bad:
        msg.extend([x['id']+' '+x['name'],f"archivo: {x['file']}",f"exit: {x['exit_code']}",f"stdout: {x['stdout_real']!r}",f"stderr: {x['stderr_real']!r}",''])
    (folder/'REPORTE_PARA_CHATGPT.txt').write_text('\n'.join(msg),encoding='utf-8')
    print(f"\nInforme: {folder/'REPORTE_PARA_CHATGPT.txt'}")
    if bad:sys.exit(1)

if __name__=='__main__': main()
