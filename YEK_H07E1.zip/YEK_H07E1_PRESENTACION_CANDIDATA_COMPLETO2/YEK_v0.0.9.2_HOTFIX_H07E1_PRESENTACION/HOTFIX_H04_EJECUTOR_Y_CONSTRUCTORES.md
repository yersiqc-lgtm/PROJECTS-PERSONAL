# YEK v0.0.9.1 — Núcleo Recursión HOTFIX H04

## Problemas reproducidos por el usuario

1. `c=herramientas.Cuenta` no activaba un constructor público obtenido de una importación profunda, pero `c=herramientas.Cuenta()` sí. La ejecución implícita de `Value::Template` estaba implementada únicamente en la ruta `Expr::Variable`.
2. Recursiones FINITAS como `par(8)` y `fibonacci(8)` cerraban `yek run` con `STATUS_STACK_OVERFLOW`. El límite de 13 marcos de YEK no equivalía a 13 marcos de Rust, y la CLI ejecutaba el intérprete sobre la pila principal de Windows.

## Cambio en la semántica de constructores

- En contextos de valor, `Cuenta` y `l.Cuenta` y `herramientas.Cuenta` construyen una instancia sin argumentos explícitos, siempre que los argumentos omitidos admitan valores predeterminados.
- `Cuenta()` y `herramientas.Cuenta()` siguen invocando el mismo constructor explícitamente.
- `crear=herramientas.Cuenta!` preserva el Template como dato invocable de primera clase, sin ejecutarlo.
- `a=herramientas.Cuenta` **no** ignora los parámetros obligatorios: produce el error habitual si faltan argumentos.
- Las clases creadas de esta manera mantienen identidad y privacidad normales; los miembros excluidos de `~export` siguen protegidos.
- La regla de activación implícita está en los caminos compartidos para valores de miembros y para salida, no en el importador particular.

## Cambio en el ejecutor

**No se ha transformado todo el intérprete en una máquina virtual sin pila nativa.** Eso exige una reestructuración considerable del motor de expresiones y control de flujo. Este HOTFIX es una defensa general, rigurosamente delimitada:

- Todas las ejecuciones por `Interpreter::run`, `run_with_input` y `run_with_io` usan un hilo de ejecución con pila reservada de 32 MiB.
- Las entradas y salidas siguen ejecutándose en el hilo llamador mediante un canal síncrono de solicitud/respuesta. Esto conserva la consola en streaming, los préstamos de I/O, la interfaz existente de callbacks y no exige `Send` a closures de los usuarios de la API Rust.
- Se mantiene el límite de 13 llamadas interpretadas activas, comprobado antes de evaluar los argumentos y en el motor común. Una recursividad infinita debería detenerse con un error controlado.
- Los fallos en callbacks de entrada/salida se traducen en errores del runtime, en vez de dejar la comunicación bloqueada.
- Cuando la ejecución completa, los canales se cierran y el hilo es unido al llamador; no hay una tarea en segundo plano.

### Límite de garantía

La pila reservada y el contador de invocaciones evitan la dependencia observada de la pila reducida del hilo principal de Windows, pero NO ofrecen una prueba formal contra desbordamientos de pila en cualquier programa (por ejemplo, expresiones/AST extremadamente profundas). Una VM con **pila explícita en el heap**, o un evaluador por continuaciones/trampolines, sigue siendo la arquitectura necesaria para ejecutar recursión arbitrariamente profunda y consolidar LLVM/YersIR.

## Nuevas pruebas

`tests/runtime_stack_implicit_members_hotfix_h04_tests.rs`:

- Recursividad mutua y Fibonacci con caché en API Rust y en proceso real `yek run`.
- Recursividad sin condición de salida, controlada, tanto en la CLI como en la biblioteca.
- Llamadas recursivas nombradas.
- Importación profunda `~import "api.yek".l.* as herramientas` y constructor implícito.
- Equivalencia con `()` y captura del constructor con `!`.
- Importación normal y selectiva de constructores, valores Code y datos.
- Parámetros obligatorios que no pueden omitirse.
- Callbacks de entrada y salida que **no implementan Send**, prueba de compatibilidad de la API Rust.

## Verificación Windows

En la raíz donde está `Cargo.toml`:

```powershell
cargo check --all-targets
cargo test --test runtime_stack_implicit_members_hotfix_h04_tests -- --test-threads=1 --nocapture
cargo test --test nucleo_recursion_importacion_v0091_tests -- --test-threads=1 --nocapture
cargo test --test recursion_named_arguments_hotfix_h02_tests -- --test-threads=1 --nocapture
cargo test --test recursion_dispatch_stack_safety_hotfix_h03_tests -- --test-threads=1 --nocapture
cargo test --all-targets
```

Alternativamente `./VERIFICAR_NUCLEO_RECURSION_HOTFIX_H04.ps1` desde PowerShell.

**Estado:** comprobaciones estáticas realizadas, no verificado con Cargo en el entorno de creación. Se entrega como candidata, no versión estable.
