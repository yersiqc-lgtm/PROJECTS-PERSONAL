# YEK v0.0.8.9 Hotfix 5 — prueba de salida de archivos TXT

## Problema reportado

La batería `modulos_v0089_hotfix4_miembros_seguros_tests` compiló, pero falló el caso
`txt_resource_with_numeric_filename_keeps_automatic_alias` porque comparaba
`["Contenido de texto\n"]` con `["Contenido de texto", ""]`.

## Causa comprobada en el código

`Interpreter::run_with_io` transmite las cadenas de salida exactas. La operación
`valor!` agrega un `\n` final a la representación de ese valor. Si el archivo
`.txt` ya contiene un salto final, la transmisión exacta es:

```text
"Contenido de texto\n\n"
```

`Interpreter::run()` agrega los fragmentos a una cadena y devuelve
`stream.lines().map(str::to_string).collect()`. Por tanto, su contrato devuelve
`["Contenido de texto", ""]`, NO una cadena con el `\n` incrustado.

## Corrección

- Solo se cambió `tests/modulos_v0089_hotfix4_miembros_seguros_tests.rs`.
- Se actualizó la expectativa para la API `Interpreter::run()`.
- Se agregó la ayuda de prueba `run_raw()` para verificar que la salida exacta
  conserva los saltos de línea originales del `.txt`.
- Se añadió una prueba de texto sin salto final para distinguir ambos casos.
- El motor y el parser no se han modificado; no se recortan los archivos `.txt`.

## Pruebas en Windows

```powershell
cargo check
cargo test --test modulos_v0089_hotfix4_miembros_seguros_tests -- --nocapture
cargo test
```

Esta entrega se revisó estáticamente; Cargo/Rust no está disponible en el entorno
que preparó el ZIP. La compilación debe confirmarse en la máquina del usuario.
