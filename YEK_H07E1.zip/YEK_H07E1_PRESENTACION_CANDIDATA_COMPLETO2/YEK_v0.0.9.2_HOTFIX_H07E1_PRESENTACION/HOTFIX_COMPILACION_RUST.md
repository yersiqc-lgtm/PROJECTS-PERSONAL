# Hotfix de compilación — YEK v0.0.8.5

## Problema

En `tests/qa_realista_tests.rs`, el caso `metamorfica_contadores_con_continue` utilizaba `i%3<>0` como código Rust. `<>` es el nuevo operador de desigualdad de **YEK**, pero **Rust** utiliza `!=`. Este error impedía compilar la suite de pruebas.

## Corrección

La línea se actualizó a:

```rust
let expected=(1..=max).filter(|i| i%3!=0).sum::<i64>().to_string();
```

La nueva sintaxis `<>` **permanece** en los programas `.yek` y en las cadenas Rust que representan programas YEK. No se cambiaron `src/` ni las reglas del lenguaje.

## Verificación

Desde la raíz que contiene `Cargo.toml`:

```powershell
cargo test --test qa_realista_tests -- --nocapture
cargo test
cargo check
```

La corrección se verificó estáticamente contra el ZIP de origen. En el entorno de empaquetado no está disponible el compilador Rust, por lo que los resultados de Cargo todavía deben confirmarse en Windows.
