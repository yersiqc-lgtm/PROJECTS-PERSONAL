# YEK v0.0.9.2 — Especificación de colecciones universales

**Base:** v0.0.9.1 Núcleo Recursión HOTFIX H04 validado por el usuario.
**Estado del proyecto empaquetado:** ETAPA A IMPLEMENTADA COMO CANDIDATA, no certificada con Cargo en este entorno. Etapas B–E están diseñadas pero NO están implementadas en el código adjunto. No utilizarlo como sustituto de H04 estable hasta completar la validación.

## 1. Principios normativos

- Un operador actúa sobre una **capacidad** del contenedor: `index`, `slice`, `iter`, `reference`, `mutable-entry`, `key-lookup`; el intérprete no debe inventar excepciones basadas en nombres de variables.
- Las copias normales y las vistas referenciadas son objetos semánticamente distintos. Un corte normal produce una colección independiente, nunca una vista viva accidental.
- Ninguna referencia puede eludir `guard`, `private`, la unicidad de Set o la estabilidad de claves de Map.
- Las operaciones sobre valores inválidos deben devolver errores YEK, jamás errores de índice de Rust o fallos del proceso.
- El significado de `!` en capturas no puede cambiar el significado histórico de `!` al final de una instrucción.
- Cada comportamiento admitido debe probarse en expresiones locales, objetos anidados, retornos de Code, funciones parciales, módulos, bucles y copias.

## 2. Estado de la primera implementación

**Etapa A (candidate)**
- AST estructural `Expr::Index` y `Expr::Slice`, más `Stmt::SetIndex`.
- Lexer para `:` en expresiones indexadas.
- Lectura indexada `[i]` en Array, ValuePack y Text, con índices negativos.
- Slicing `[start:end:step]` en esos tipos, incluida inversión `[:: -1]` sin espacio requerido.
- Copia del resultado de slicing: Array copia recursivamente sus elementos; Pack conserva su identidad de tipo y es por valor.
- Asignación indexada y captura por `!` exclusivamente para celdas mutables de Array.
- Rechazo de paso cero, índices fraccionarios, fuera de rango y escritura en Pack/Text.
- Conexión del AST nuevo con el compilador de módulos y el inspector.

**Limitación A**: Texto se indexa por *escalares Unicode* (`char` en Rust), no por grafemas percibidos. El índice de un emoji compuesto puede devolver solo un escalar. Esta decisión deberá especificarse antes de declarar el núcleo estable.

## 3. Etapa B — Map y Set ordenados (pendiente)

Sintaxis:
```
map = {"a":1,"b":2}
set = {1,2,2,3}
map_vacio = {}
set_vacio = Set()
```

- Map: entradas ordenadas por **primera inserción**, claves únicas e inmutables; actualizar una clave no cambia su posición.
- Set: unicidad matemática, conserva orden de **primera inserción** para indexación y visualización; la comparación de conjuntos ignora el orden.
- `map[0]`: entrada posicionada, no búsqueda de clave numérica. `map["a"]`: valor por clave de texto. `map.get(clave)` es la búsqueda general, especialmente necesaria para claves numéricas. La existencia de claves numéricas nunca debe alterar el significado de `[0]`.
- `map[i:j:k]` y `set[i:j:k]`: copia **del mismo tipo** conservando el orden de entradas/elementos elegido; `[:: -1]` invierte el orden, no intercambia clave y valor.
- Entrada de Map como `Entry(key,value)`, con `.key` y `.value` y representación `key:value`. `.key` no es modificable por referencia.
- Claves permitidas inicialmente: Number exacto, Text, Bool y Pack recursivo de claves válidas. No son claves Array, Map, Set, Class ni referencias mutables. Igualdad numérica debe respetar equivalencia de racionales (1 == 2/2).
- Literales Map con claves duplicadas: rechazar; asignación posterior por clave: actualizar.
- Literales mixtos `{1,"a":2}`: rechazar.

## 4. Etapa C — Vistas vivas seguras (pendiente)

- `m.keys`, `m.values`, `m.entries` retornan arrays independientes, como copia (sin `!`).
- `m.values!` devuelve una colección de **referencias vivas a celdas de valor**, nunca a las claves.
- No confundir un Array que **posee** sus celdas con `ValueView` que **toma prestadas** celdas administradas por Map.
- Cada entrada tiene identidad estable y generación; borrar una entrada invalida la referencia anterior, sin redirigirla a otra entrada.
- Las vistas capturan las entradas existentes al crearse; nuevas entradas no se añaden retrospectivamente.
- Una vista de valores no permite append, insert, clear ni redimensionado: carece de capacidad para crear claves.
- Las capturas a Pack, Text, claves Map y elementos Set por `!` se rechazan para evitar mutación que rompa invariantes.
- No aceptar una ruta de referencia si viola encapsulación de un campo `private`, una guarda o la semántica de objeto.
- `atomic` revierte mutaciones de entradas y sus versiones sin crear referencias accidentalmente válidas después del rollback.
- Diseño futuro: `a.view(i,j)` para ventanas vivas de Array; no sobrecargar inmediatamente `a[i:j]!` sin decisión explícita sobre su ciclo de vida.

## 5. Etapa D — Iteración y productores (pendiente)

- `for(x in set)` itera por orden de inserción.
- `for(e in map)` itera entradas `Entry`, no solamente claves ni solamente valores.
- `(clave,valor)` puede desestructurar `Entry` cuando se haya terminado la unificación de patrones.
- `for(x! in m.values!)` permite actualización viva, siempre con restricciones del tipo.
- No duplicar el motor `for` ni el productor; incorporar fuentes mediante protocolo interno común.
- Revisar `count`, `first`, `last`, `contains`, `reverse`, `get`, `add`, `remove`, `keys`, `values`, `entries`, `union`, `intersection`, `difference` con reglas por tipo.

## 6. Etapa E — Cierre de estabilidad (pendiente)

- Compatibilidad de todas las pruebas H04 y QA histórico.
- Pruebas de estrés: nested indexing, igualdad de racionales, referencias caducas, guardas, atomic, tipos recursivos, módulos, iteradores y productores.
- Fijar precedencia, conversión, evaluación una sola vez de receptores/índices, errores y límites de memoria.
- Probar en `yek run`, API Rust e imports compilados.
- Documentar formalmente la distinción entre la **celda de la variable**, la **celda del elemento** y la **identidad del contenedor**.

## 7. Ejemplos de la ETAPA A candidata

```
~code
a=[1,2,[6],(1,3),"hola"]
b=(1,2,[6],(1,3),"hola")
a[0]!
b[1]!
a[::-1]!
b[1:3]!
a[1]=99
a!
```

`a[0]!` debe mostrar `1`; `b[1]!` muestra `2`; `a[::-1]` crea Array invertido independiente; `b[1:3]` crea ValuePack `(2,[6])`; `a[1]=99` modifica `a` y no otra copia.

## 8. Decisiones pendientes antes del congelamiento v0.1.0

1. Definir si la indexación textual usa escalares Unicode o grafemas.
2. Definir reglas de igualdad de Bool y Number en Maps.
3. Definir representación del Entry como valor público o tipo de vista y su interoperabilidad con Pack.
4. Definir si la iteración sobre contenedores mutados durante el bucle toma snapshot o señala invalidación.
5. Definir propagación de referencias que apuntan a Class dentro de Pack y ValueView.
6. Determinar la política de hashing estable, ataques por colisiones y límites de tamaño.

## 9. Pruebas

La suite `tests/colecciones_universales_v0092_etapa_a_tests.rs` cubre 16 casos de Stage A. Debe ejecutarse con
```
cargo check --all-targets
cargo test --test colecciones_universales_v0092_etapa_a_tests -- --test-threads=1 --nocapture
cargo test --all-targets
```

No se ha ejecutado Cargo dentro de este entorno; cualquier error de compilación/test deberá corregirse antes de iniciar Etapa B.
