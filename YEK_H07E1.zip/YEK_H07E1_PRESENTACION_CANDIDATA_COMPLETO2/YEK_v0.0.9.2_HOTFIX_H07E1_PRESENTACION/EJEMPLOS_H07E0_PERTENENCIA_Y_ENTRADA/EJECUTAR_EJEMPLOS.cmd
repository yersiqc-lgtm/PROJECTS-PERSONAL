@echo off
setlocal
cd /d "%~dp0.."
cargo test --test h07e0_membership_retry_tests
if errorlevel 1 pause
