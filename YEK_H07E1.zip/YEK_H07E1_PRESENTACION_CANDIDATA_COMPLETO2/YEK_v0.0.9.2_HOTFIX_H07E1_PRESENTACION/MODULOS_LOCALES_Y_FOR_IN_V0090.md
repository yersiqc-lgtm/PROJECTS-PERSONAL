# YEK v0.0.9.0 candidata — `~import` local y `in`

Esta entrega parte de la **v0.0.8.9 Hotfix 5**.

## Importaciones locales

```yek
~import "libre.yek" as global

accion=~code
    ~import "prueba.yek" as local
    local.valorExterno!
    global.valor!

accion!
global.valor!       ~ valido
~ aqui `local.valorExterno!` sería un error, pues `local` no pertenece al ámbito exterior
```

Las importaciones en cuerpos `~code`, `if`, `for` y `~block` se resuelven estáticamente desde la ubicación del archivo que contiene la declaración, pero se **vinculan solo cuando el bloque se ejecuta**. Al abandonar los cuerpos de If/For/Block se retiran sus nombres importados; las asignaciones ordinarias a variables externas se conservan. Cada Code tiene su propio marco. La caché de módulos mantiene una sola inicialización por archivo canónico y ejecución.

Una importación local no se vuelve exportación pública automáticamente. Los `~export` siguen siendo declaraciones **de ámbito superior** del archivo de biblioteca. Los `~import` realizados dentro de `~code` no aparecen como símbolos públicos por el mero hecho de existir en el AST.

**Nota:** los imports siguen siendo estáticos: un archivo inexistente en una rama que no vaya a ejecutarse provoca error al compilar. La carga realmente diferida (`lazy`) es una función distinta y no se ha implementado.

## `in` en For

Sintaxis recomendada:

```yek
for(x in [1,2,3])
    x!

a=[for(x in 1..3)->x*2]
```

Se permiten los mismos patrones de referencias, destructuración, fuentes sincronizadas y pasos que ya existían; solo cambia la palabra que separa el patrón de las fuentes. `in` es una palabra reservada, no puede usarse como variable. Las apariciones dentro de cadenas y de expresiones anidadas no son separadores.

`for(x=fuente)` permanece válido temporalmente para evitar romper programas existentes; en nuevas guías se recomienda `in`. Si se quiere eliminar `=` definitivamente, conviene hacerlo con una versión mayor y migración automática, no con un hotfix.

## Compatibilidad y límites

- `~import "archivo.yek"` sin `as` y alias automáticos: conservados.
- `~export`, alias y reexportaciones a nivel de archivo: conservados.
- El acceso por ruta literal (`"archivo.yek".valor`) sigue retirado.
- `~text` y `~invalid` siguen sin activar directivas importadas.
- Los alias repetidos en el mismo ámbito provocan error; los alias importados no sobrescriben silenciosamente variables existentes.
- Se revisó la herramienta `yek deps` para mostrar también las importaciones anidadas sin ejecutar módulos.

## QA

Desde PowerShell, en la carpeta con `Cargo.toml`:

```powershell
cargo check
cargo test --test modulos_locales_in_v0090_tests -- --nocapture
cargo test
```

**Estado:** candidato pendiente de compilación/verificación Rust. Aquí no está disponible Cargo.
