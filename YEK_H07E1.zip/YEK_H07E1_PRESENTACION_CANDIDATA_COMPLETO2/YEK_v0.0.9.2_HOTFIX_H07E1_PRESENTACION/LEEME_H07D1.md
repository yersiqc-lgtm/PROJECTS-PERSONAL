# H07D1: compilación del escritor de salida en cadenas con estilo

Base: H07D. Esta corrección no añade sintaxis YEK ni cambia su semántica.

## Causa

`Stmt::StyledString` pasaba una closure concreta nueva a `run_active_string`, que
puede acabar evaluando Code anidado. Al monomorfizar las llamadas genéricas recursivas
`execute_program<R,W>`, el compilador Rust creaba una cadena ilimitada de tipos
nuevos para `W`, provocando `reached the recursion limit while instantiating`.

## Cambios

- `src/interpreter/mod.rs`: se usa un escritor `&mut dyn FnMut(&str) -> Result<(),String>`
  en la captura de la cadena, con ámbito de vida acotado, para mantener estable
  el tipo de `W` en todas las profundidades de recursión.
- `src/source.rs`: se elimina el binding local `limit` que no se utilizaba,
  sin cambiar el control de indentación de H07D.
- `tests/h07d1_styled_capture_regression_tests.rs`: dos casos de Code anidado.

## Comprobaciones en Windows

```powershell
cargo build
cargo test --test h07d1_styled_capture_regression_tests
cargo test --test h07d_integracion_segura_tests
cargo test
```

**Limitación:** no se pudo ejecutar Cargo en el entorno de preparación de esta
entrega. La compilación funcional debe confirmarse en tu equipo. No se ha
incrementado `#![recursion_limit]`: eso ocultaría el origen del problema.
