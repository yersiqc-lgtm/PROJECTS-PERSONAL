# YEK v0.0.9.2 HOTFIX H06C — Autodomínios tipados

Base: H06B (incluye migración H06 y rangos explícitos H06A).

## Causa del fallo

El parser `~in(auto=["hola",2,[2,6],true])` transformaba el literal
entrecomillado `"hola"` a una cadena sin comillas, `hola`, guardada como
`DomainAtom::Exact`. Luego el resolvedor de referencias del intérprete la
confundía con una variable numérica por valor. Los Arrays y valores Bool
podían recorrer la misma ruta errónea. 

## Cambios estructurales

- `DomainAtom::TextLiteral` conserva el origen citado del literal.
- `DomainAtom::ArrayLiteral` conserva el literal Array anidado sin ejecutarlo.
- `DomainAtom::Exact` conserva las alternativas numéricas y Bool.
- Los literales de Auto no se resuelven como símbolos: solo `(variable)` o
  `variable!` son extremos dinámicos en rangos compatibles con H06A.
- Validación de candidatos diferencia texto `"2"` y número `2`.
- Auto reconoce también `none` como alternativa exacta explícita.
- Los dominios Array solo se comparan mediante su representación literal
  canónica; el decodificador posterior permite exclusivamente literales,
  nunca ejecuta código introducido como entrada.

## Regresión

La suite `tests/etapa6_h06_migracion_unificada_tests.rs` crece de 57 a 70
pruebas; 13 casos nuevos tienen equivalente `.yek` independiente en
`EJEMPLOS_H06C_DOMINIOS_AUTO`.

El intérprete, los contratos Num/Str/Bool, la política de fallos, la regla
de rangos H06A y la VSIX v1.3.0 no reciben cambios adicionales.

## Validación

Se ha revisado la integridad y la consistencia del código y se ha ejecutado
la auditoría de los archivos de pruebas, pero no se ha compilado este hotfix
con Cargo en el entorno de generación. Compilar y ejecutar `cargo test` en
Windows sigue siendo obligatorio antes de aprobar H06C.
