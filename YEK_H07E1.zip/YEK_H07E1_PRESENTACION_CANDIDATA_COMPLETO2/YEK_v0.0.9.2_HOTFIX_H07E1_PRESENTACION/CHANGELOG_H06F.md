# YEK H06F — Integración Unicode Range

- Incluye **52 pruebas independientes y Rust** para los rangos de caracteres Unicode.
- El parser convierte en extremos de texto las letras Unicode literales unitarias de `a..d`. Las variables se consultan mediante `(nombre)`; las referencias se indican con `!`.
- `Range` se clasifica en ejecución por los tipos de sus extremos: Number mantiene su ruta histórica, Text produce caracteres Unicode. Los dominios mixtos o textos multicaracter se rechazan.
- Se soportan ValuePack, Array, `for`, productores, pasos enteros, límites vivos y Unicode ascendente/descendente; se excluyen los puntos de código surrogate sin asignarlos a caracteres.
- Sin cambios en ~in(str=a..z) ni en la representación estándar de Text y Pack.
- Riesgos pendientes de verificación real: compilar con Rust, ejecutar todas las regresiones, VS Code y entornos de Windows.
