# YEK v0.0.9.2 — Hotfix H04B: prueba ValuePack

## Causa
Al ejecutar `cargo test --test etapa4_h04_semantica_global_tests`,
37 de 38 pruebas terminaron correctamente. La última prueba
`valuepack_still_not_writable_by_element_index` rechazó con éxito
`a[0]=90` cuando `a=(1,2)`, pero el test esperaba la cadena
`ValuePack` mientras que el diagnóstico del motor era:

`value pack does not support mutable indexed elements`

El problema estaba **solo en el texto esperado por el test**, no en el
comportamiento del lenguaje.

## Cambio exacto
En `tests/etapa4_h04_semantica_global_tests.rs`, se sustituyó:

```rust
error("~code\na=(1,2)\na[0]=90", "ValuePack");
```

por:

```rust
error("~code\na=(1,2)\na[0]=90", "value pack does not support mutable indexed elements");
```

El motor Rust (`src/`), las otras 37 pruebas y la distinción ValuePack/Array
permanecen sin cambios.

## Uso
Si ya has aplicado H04A, descomprime el parche mínimo y reemplaza solo
`tests/etapa4_h04_semantica_global_tests.rs`.

Desde la raíz del proyecto (donde está `Cargo.toml`):

```powershell
cargo test --test etapa4_h04_semantica_global_tests
cargo test
```

Las 38 pruebas específicas deberían aprobarse de acuerdo con el registro
compartido, aunque la confirmación real requiere ejecutarlas en Windows.

## Validación
Se verificó que el ZIP completo H04B conserva byte a byte todos los demás
archivos de H04A (excepto la documentación adicional H04B). Se verificaron
los ZIP. Este entorno no dispone de Cargo ni rustc, por lo que la validación
de ejecución sigue pendiente.
