# YEK v0.0.8.7 — Hotfix 1: directivas estructurales y exportaciones

## Problema reproducido

En Windows, `cargo test --test modulos_v0087_tests -- --nocapture` compiló pero fallaron 4 de 13 pruebas:
- `math_module_and_selective_symbols` (`cube` no exportado)
- `nested_modules_selective_imports_and_cache` (`square` no exportado)
- `multiline_combination_of_data_user_and_stdlib` (`square` no exportado)
- `module_mode_ignores_inactive_imports` (`math.add` inaccesible)

**Causa:** en `src/source.rs`, al determinar si una línea de indentación cero cerraba un bloque `~code`, se trataba `~export ...` (y potencialmente `~import ...`) como comentario ordinario `~`. En `stdlib/math.yek`, el `~export square, cube, add, abs` siguiente a la función indentada `abs` podía quedar absorbido por su cuerpo, por lo que el cargador veía una lista vacía de exportaciones.

## Corrección

- `~export` y `~import`, con frontera de palabra válida, ahora son directivas estructurales y **no** comentarios cuando se calcula el fin de un bloque indentado.
- La detección de comentarios ordinarios se mantiene: `~ comentario`, `~exported` y `~important` no se convierten en directivas válidas.
- Declaraciones de módulos indentadas donde no se permiten siguen produciendo un error de nivel superior.
- Los modos `~invalid` y `~text` mantienen su comportamiento de inactividad/datos.
- No se cambió el intérprete, el AST, la gramática de miembros, las reglas de caché ni los nombres de las exportaciones.

## Pruebas

Además de las 13 pruebas originales de módulos, incluye 9 regresiones nuevas en `tests/modulos_hotfix1_directivas_tests.rs` para exportaciones después de capturas indentadas, la biblioteca `math`, importaciones posteriores a funciones, nombres falsamente parecidos y los modos inactivos.

Desde la raíz del proyecto:

```powershell
cargo test --test modulos_v0087_tests -- --nocapture
cargo test --test modulos_hotfix1_directivas_tests -- --nocapture
cargo test
cargo check
```

También se puede ejecutar `VERIFICAR_MODULOS_HOTFIX1.cmd` desde Windows.

**Validación:** el cambio está auditado estáticamente, pero aquí no se dispone de `cargo`/`rustc`. Los 13 + 9 casos **deben comprobarse en tu equipo**; no se consideran superados hasta que Cargo confirme los resultados.

## Nota sobre VS Code

En Settings (`settings.json`), `yek.manifestPath` debe apuntar al `Cargo.toml` de **esta carpeta**, no a la versión 0.0.8.5 o a una copia 0.0.8.7 anterior.
