@echo off
cd /d "%~dp0"
py -3 ejecutar_h06.py
pause
