#!/usr/bin/env python3
"""YEK H06: 57 independent input/range checks (no third-party dependencies)."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import csv
import sys

BASE=Path(__file__).resolve().parent
ROOT=BASE.parent
CASES=json.loads((BASE/'MANIFIESTO.json').read_text(encoding='utf8'))


def main():
    parser=argparse.ArgumentParser(description='Verificación de YEK H06')
    parser.add_argument('--sin-build',action='store_true')
    parser.add_argument('--solo',help='ID H06-001, H06-020 etc.')
    parser.add_argument('--timeout',type=int,default=7)
    parser.add_argument('--auditar',action='store_true')
    args=parser.parse_args()
    missing=[c['id'] for c in CASES if not (BASE/c['path']).is_file()]
    if missing:print('FALTAN:',missing);return 2
    if len({c['id'] for c in CASES})!=len(CASES):print('IDs repetidos');return 2
    print(f'Integridad básica: {len(CASES)} archivos')
    if args.auditar:return 0
    if not args.sin_build:
        try:
            build=subprocess.run(['cargo','build','--quiet'],cwd=ROOT,capture_output=True,text=True,timeout=240)
        except Exception as exc:print('No se pudo ejecutar Cargo:',exc);return 2
        if build.returncode!=0:
            print('CARGO BUILD FALLÓ:\n',build.stderr);return 2
    exe=ROOT/'target'/'debug'/('yek.exe' if os.name=='nt' else 'yek')
    if not exe.exists():print('No existe el ejecutable:',exe);return 2
    selected=[c for c in CASES if not args.solo or c['id']==args.solo]
    dest=BASE/'RESULTADOS_H06';dest.mkdir(exist_ok=True)
    rows=[]
    for case in selected:
        stdin='\n'.join(case['stdin'])+('\n' if case['stdin'] else '')
        try:
            proc=subprocess.run([str(exe),'run',str(BASE/case['path'])],input=stdin,capture_output=True,text=True,encoding='utf-8',timeout=args.timeout)
            stdout=proc.stdout.splitlines()
            if case['error']:
                passed=proc.returncode!=0 and case['error'].lower() in proc.stderr.lower()
                detail=f'error buscado: {case["error"]} / exit={proc.returncode} / stderr={proc.stderr[:500]}'
            else:
                passed=proc.returncode==0 and stdout==case['stdout']
                detail=f'output real: {stdout!r}; esperado: {case["stdout"]!r}; stderr={proc.stderr[:400]}'
        except subprocess.TimeoutExpired:
            passed=False;detail='TIMEOUT'
        record={'id':case['id'],'nombre':case['name'],'estado':'OK' if passed else 'FALLO','detalle':detail}
        rows.append(record)
        print(f'{record["estado"]:6} {case["id"]} {case["name"]}')
    with (dest/'resultados.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['id','nombre','estado','detalle']);w.writeheader();w.writerows(rows)
    report=f'YEK H06 | revisados {len(rows)} | OK {sum(r["estado"]=="OK" for r in rows)} | FALLARON {sum(r["estado"]!="OK" for r in rows)}\n\n'
    report+='\n'.join(f'{r["id"]} {r["estado"]} {r["nombre"]}: {r["detalle"]}' for r in rows)
    (dest/'REPORTE_PARA_CHATGPT.txt').write_text(report,encoding='utf-8')
    print('\nInforme:',dest/'REPORTE_PARA_CHATGPT.txt')
    return 1 if any(r['estado']!='OK' for r in rows) else 0

if __name__=='__main__':sys.exit(main())
