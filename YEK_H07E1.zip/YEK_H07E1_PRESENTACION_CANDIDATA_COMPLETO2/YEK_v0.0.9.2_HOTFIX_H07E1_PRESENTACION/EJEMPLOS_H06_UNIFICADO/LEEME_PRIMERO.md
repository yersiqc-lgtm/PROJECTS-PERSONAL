# YEK H06 — 57 pruebas específicas

Dentro de la raíz del proyecto YEK, con `Cargo.toml`:

```powershell
cargo build
cargo test --test etapa6_h06_migracion_unificada_tests
cargo test
cd EJEMPLOS_H06_UNIFICADO
py -3 ejecutar_h06.py --auditar
py -3 ejecutar_h06.py
```

`RESULTADOS_H06/REPORTE_PARA_CHATGPT.txt` contiene las diferencias con las salidas esperadas.

**IMPORTANTE:** estas pruebas fueron escritas tras inspeccionar el código fuente H05B y diseñar la nueva gramática; el entorno que generó la entrega no dispone de Cargo y no ejecutó YEK real. Trate los resultados esperados como hipótesis de regresión hasta verificar en Windows.
