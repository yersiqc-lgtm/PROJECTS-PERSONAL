# YEK RFC-06 — Separación de Range/ValuePack/ContractPack y unificación de contratos `~in`

**Estado:** diseño propuesto; no implementado ni probado mediante Cargo.
**Base examinada:** YEK H05B (archivos Rust `src/source.rs`, `src/input.rs`, `src/interpreter/mod.rs`, `src/ast/mod.rs`; regresiones `tests/v008_1_tests.rs`, `tests/v007_2_tests.rs`, `tests/v007_3_tests.rs`, `tests/contract_pack_disambiguation_tests.rs`).
**Origen de las propuestas:** ejemplos aportados por el usuario en `Markdown pegado.md`, de 355 líneas.

## 1. Diagnóstico comprobable de `(0..x)`

```yek
x=26
a=(0..x)
a!
```

**Actual:** `<contract-pack>` (según prueba del usuario). **Deseado:** `(0, 1, ..., 26)`; lista de los 27 enteros, completa en la salida real.

La ruta especial `parse_contract_pack_assignment()` de `src/source.rs` intercepta asignaciones `nombre=(...)` antes del parser estándar. `looks_like_contract_pack()` considera que `0..x` es un rango de caracteres porque `looks_like_static_char_range()` admite un extremo de un único carácter identificador como `x`. También extrae paréntesis de `(x)`. En consecuencia se produce `Expr::ContractPack(String)` y el visualizador del intérprete escribe `<contract-pack>`.

**No es fallo del formato de impresión:** se ha construido el nodo AST erróneo. **No es limitación general de Range:** `a=(1..10)` está expresamente cubierto por pruebas Rust de materialización.

### Regla definitiva propuesta

1. El código ordinario utiliza el parser ordinario para `Range`, expresiones, ValuePack y agrupaciones.
2. La gramática propia de los contratos se interpreta exclusivamente dentro de `~in(...)` (o un constructor explícito de contrato, si se aprueba).
3. No decidir el tipo de una expresión a partir de que un identificador tenga un solo carácter.
4. `a=(0..x)` y `a=(0..(x))` son un único ValuePack con 27 valores. Si `x=26`, abarcan ambos extremos.
5. `for(i=0..x!)` debe seguir siendo vivo: límite dereferenciado durante el bucle. `a=(0..x!)` es una materialización finita en el instante de construcción, NO una secuencia que se actualiza después.
6. Un rango abierto no puede materializarse sin límite o interrupción; sí puede consumirse en `for` con `break`.
7. Agregar límite configurable de materialización y error controlado si se excede; evitar trabajo y memoria ilimitados.

### Migración de ContractPack

Actualmente `rules=(a..z,[3..10])` tiene interpretación heredada como `ContractPack` y sus pruebas existen. Sustituir el detector implícito sin transición rompería ejemplos antiguos. Se propone:

- Período de compatibilidad: aceptar contratos heredados, pero advertir sobre la ambigüedad y proveer alternativa explícita `~in(str=[a..z], len=3..10)`.
- Posteriormente: requerir contexto de contrato explícito; retirar `looks_like_contract_pack()` como clasificador de asignaciones ordinarias.
- Los casos `a..z` en código ordinario pasarán por el parser normal y requerirán límites numéricos; dentro de `str=` se interpretarán como rango de caracteres.

## 2. Sintaxis normativa provisional de `~in`

```yek
~in
~in(auto)
~in(num)
~in(num.int=[1,4..6,100], len=[2,10..20], att=2, msg="incorrecto")
~in(num.float=1..10, att=[3,"prueba de nuevo"], warning="alerta", -> 1.0)
~in(str=[a..z,A..Z,0..9,"_"], len=3..10)
~in(str.char=["a".."m"])
~in(bool.str=[true,false], len=4..5)
```

La directiva configura **lecturas futuras mediante `?`**, no cambia el tipo de variables ni de asignaciones comunes. Su alcance es el del frame actual y su reemplazo por otra directiva debe seguir siendo explícito. El orden de opciones es irrelevante. Duplicados o selectores incompatibles se rechazan. Las claves `msg`, `warning`, `error`, `att`, `len` y `auto` solo tienen significado contractual dentro de la directiva, no se convierten en keywords globales.

### Reglas algebraicas

- Alternativas dentro de un selector `[1,4..6,100]` se unen (OR).
- Parámetros diferentes (`num`, `len`, etc.) se intersecan (AND).
- Los límites numéricos de `..` son inclusivos. En contratos, `0..-inf` y `-inf..0` representan ambos el dominio `(-inf,0]`, no un bucle descendente.
- `num.int`: texto de entrada con forma de entero y valor compatible con rango; `num.float`: texto con formato decimal explícito; `num.auto` admite enteros y decimales. Se debe escoger formalmente cómo tratar exponentes; H05B no los admite en `Number::parse`.
- `len` opera sobre el lexema original completo (`+`, `-`, `.`, ceros anteriores cuentan). Definir tratamiento del espacio en blanco antes de implementarlo.
- `str`: entrada textual cruda. Literales entrecomillados son coincidencias completas, mientras rangos de caracteres describen un alfabeto admitido; esos dos tipos de alternativa se unen.
- `str.char`: exactamente un escalar Unicode. Un futuro `str.grapheme` admitiría un clúster visual; no mezclarlo con `.len` y `.vlen`.
- `bool`: propuesto aceptar los cuatro lexemas `true`, `false`, `0`, `1`; `bool.str` solo los dos literales y `bool.num` solo `0/1`. Una lista explícita restringe representaciones aceptadas, no solo el valor lógico.
- `auto`: actualmente solo número/texto; para aceptar bool, Array y otros tipos, necesitaría un parser *de literales de datos no ejecutables*, con límites de tamaño/profundidad, sin evaluar código escrito por el usuario.

## 3. Semántica de errores, intentos y reserva

| Parámetro | Significado propuesto |
|---|---|
| `msg="x"` | Mensaje final ordinario, no fatal; devuelve reserva/`none` |
| `warning="x"` | Aviso final y resultado de reserva; continúa |
| `error="x"` | Error final fatal; sin retorno |
| ninguno | Error final fatal con diagnóstico generado automáticamente |
| `att=n` | Hasta `n` entradas, mínimo 1; por defecto 1 |
| `att=[n,"x"]` | Mensaje de reintento en cada rechazo y límite n |
| `att=inf` | Reintentos ilimitados hasta entrada válida; EOF sigue dando error controlado |
| `-> valor` | Valor de reserva cuando la política permite continuar; `->` significa `none` |

Las políticas terminales (`msg`, `warning`, `error`) se excluyen entre sí; no aplicar «la última gana». `error` y `->` se contradicen. `att=inf` no puede combinarse con acciones que solo suceden tras agotar intentos: usar el mensaje de `att=[inf,"..."]` para aviso por intento. Una reserva no se somete al mismo conjunto de valores permitidos, pero sí a su tipo declarado (salvo `none`), porque es una sustitución explícita. Reservas incompatibles como `~in(num, -> "no")` deben rechazarse o exigir un modo opcional de resultado heterogéneo, no convertirse silenciosamente.

### Compatibilidad y contradicción

- Sintaxis inválida, argumentos repetidos, tipos o claves desconocidas: diagnóstico estático.
- Restricciones imposibles (p.ej. `bool=true,len=6`; `str.char,len=3`): diagnóstico al instalar el contrato cuando sus límites son constantes.
- Restricciones con variables dinámicas/referencias (`x!`): validar cuando se resuelven, antes de consumir un intento.
- Conjunto vacío no significa ausencia de filtro: distinguir `selector omitido` de `selector=[]`.
- No confundir `+inf` del dominio con un intento infinito; no enumerar dominios abiertos.

## 4. Referencias y estado

El motor ya soporta valores capturados y referencias de celda en contratos viejos. Conservar en `~in` el patrón general del lenguaje:

- Variable ordinaria `limite`: captura por valor / instantánea según el punto de activación del contrato.
- `limite!`: referencia a la misma celda, resuelta antes de cada adquisición.
- Reasignación que desprende una celda (`x=x`) no debe alterar una referencia que apunta a la celda previa.
- La evaluación de candidatos debe ser determinista y sin efectos secundarios.
- `for(i=0..x!)` y `~in(num=0..x!)` pueden compartir referencias, pero uno itera y el otro valida lecturas; **son mecanismos distintos**.

## 5. Arquitectura sugerida

1. Separar contextos sintácticos `ExprParser`/`ContractParser`, reutilizando lexer y utilidades, no inferencias heurísticas.
2. AST `InputContract { family, subtype, candidates, length, attempts, retry_message, failure_policy, fallback, bindings }`.
3. Analizador de tipos y contradicciones antes de instalar el contrato; errores con ubicación exacta.
4. Compilar dominios en predicados/intervalos; no construir colecciones infinitas ni expandir un rango solo para validar una entrada.
5. Normalizar entrada en pasos `raw → lexema → valor tipado → dominio → longitud → aceptar / política de reintento`.
6. Mantener la máquina de estados de `?`, referencias, parámetros y frames. Separar lectura de valor / mensajes / fallo.
7. Actualizar gramática TextMate VSIX con `~in`, selectores y contextos; conservar resaltado de código y texto.
8. Migración progresiva, documentación/diagnósticos de deprecación, baterías de regresión de etapas 1-6.

## 6. Pruebas críticas propuestas

### Rangos / colisión con contratos

```yek
x=26
a=(0..x)
a!
```

Debe mostrar 27 números, no `<contract-pack>`.

```yek
x=26
a=(0..(x))
a!
```

Idéntica salida.

```yek
x=3
a=(0..x)
x=5
a!
```

Debe mostrar `(0, 1, 2, 3)`; materialización congelada.

```yek
x=3
for(i=0..x!)
    i!
    if(i==2)
        x=5
```

Debe seguir reevaluando el final dinámico en el bucle.

### Entradas y contradicciones

```yek
~in(num.int=1..10, len=3, att=2, warning="entrada inválida", -> 5)
x?
x!
```

La implementación debe decidir explícitamente la aceptación de `005` y rechazo de `5.0`.

```yek
~in(bool=true, len=6)
x?
```

Debe ser diagnosticado como contrato insatisfacible, sin pedir entrada.

```yek
~in(num=1..10, att=inf, error="nunca debería agotarse")
x?
```

Debe rechazarse por política terminal inalcanzable o normalizarse explícitamente antes de ejecución (recomendado: rechazo).

```yek
~in(num=1..10, -> "texto")
x?
```

Debe rechazarse por fallback incompatible salvo que el programa active expresamente un modo de resultado heterogéneo.

```yek
~in(str=[a..z,"si"], len=2..5)
nombre?
```

Es imprescindible definir que las alternativas de alfabeto aceptan cadenas formadas por esos caracteres, mientras `"si"` es una alternativa textual exacta.

## 7. Riesgos / condiciones para aprobar

- Alto: romper compatibilidad de ContractPack heredado y los modos de entrada.
- Alto: usar evaluación de código YEK para interpretar texto de usuario en `auto`.
- Alto: bucles abiertos o materializaciones masivas que saturen memoria.
- Medio-alto: confundir referencias vivas y snapshots; resolver a momentos distintos.
- Medio: falsos positivos al detectar contratos insatisfacibles cuando hay ceros iniciales, rangos abiertos o variables dinámicas.
- Medio: semántica de Unicode escalar frente a grafema y rangos por code point.
- Medio: cambios del formato `num.float` con backend numérico racional existente.

### Puertas de validación

A. Hotfix aislado de colisión Range/ContractPack, regresiones mínimas.
B. Aprobación de esta semántica de `~in` y sus decisiones pendientes.
C. Nuevo parser tipado `~in` conservando temporalmente directivas antiguas.
D. Verificación estática, referencias y máquinas de intentos.
E. Entradas `auto` complejas y validación de Unicode.
F. Migración/documentación/VSIX y regresión completa.

**Ninguna de estas propuestas equivale a implementación. No se ha modificado H05B.**
