*estuve viendo la posiblidad de poder hacer un cambio general en lenguaje con respecto a los contratos*

*como sabras ahora mismo tenemos esto:*



*\~num*

*\~str*

*\~bool*



*lo cual tiene un funcuionamiento actualmente algo raro pero funional para ello quisiera hacer un cambio*

*grande en este parte ptracticamente eliminar todas esas directivas y pasar a tener esto:*



*\~in(auto=["hola",2,[2,6],true])*

*\~in(num=[1,4..6,100], len = 5, msg="incorrecto", att = 2)*

*\~in(str=["a",b..z,0..9,"."..",","si"], error,len = 2..4, att = inf)*

*\~in(bool=[true,false],len=4,warning="incorrecto")*



*como habras podido observar en los ejemplos que te mostre conservamos la matoria de funcionalidades que&#x20;*

*ya teniamos disponible unicamente, la idea es que ahora eliminar como tal las cabeceras o comandos*

*"\~num", "\~bool", "\~str" y "\~auto", esto ademas sera muho mejor ya que generalizaremos simplemente colocando "\~in"*

*y en los parametros ya podra modificar directamente el tipo y tambien comompodra darte cuenta esos comandos*

*ahora pasarian a ser paramtros tambien, que podran utilizarse directamente dentro de "in" e ire especificando*

*sus funcionalidades nuevamente:*



*\~in(num=[1,4..6,100], len = 5, msg="incorrecto", att = 2)*



*como veras en este caso sera de tipo "num", y ademas aqui el detalle mas importante, directamente se le podra asignar a&#x20;*

*dichos parametros valores que podran ser permitidos en este caso [1,4..6,100], esto indica que el valor de entra puede ser "1"*

*o del 4 al 6 o tambien el numero 100, cabe mencionar que cada asignacion qu se le hace a cada parametro*

*no deberia ser obligatorio, y que puede directamente simplemente asi*



*\~in(num, len = 5, msg="incorrecto", att = 2)*



*eso abarcara directamente a todos los valores numericos generalizados y como ya es de costumbre tambien saber que se pueden hacer conbiaciones*

*mas extraordinarias como por ejemplo tambien*



*\~in(num=[0..+inf], len = 5, msg="incorrecto", att = 2)*



*eso quiere decir desde el 0 hasta el +inf, no es necesario porner el "+" se da entender que lo es, tambien podemos otras formas interesantes como*

*por ejempo:*



*\~in(num=[0..], len = 5, msg="incorrecto", att = 2) \~ esto es equivalente al ejemplo anterior hacia el inf positivo*

*\~in(num=[0..-inf], len = 5, msg="incorrecto", att = 2) \~ esto quiere decir del 0 hacia el -inf*

*\~in(num=[-inf..0], len = 5, msg="incorrecto", att = 2) \~ esto tambien es equivalente al ejemplo anterior del -inf hasta el 0*

*\~in(num=[..0], len = 5, msg="incorrecto", att = 2) \~ esto tambien quieres decir desde el -inf hasta el valor 0 se da entender*



*como veras habria formas de lograr un mismo resultado y es muy intuitivo y mucho mas que nuestra forma atual, asi que*

*creo que seria mejor implementar dicha funcionalidad y cambiarla al 100% ahora tambien te presento otras formas directas de conseguir*

*numeros flotantes y algo que hasta ahora mismo no teniamos, ya que el actual que estamos viendo abarca tanto numero reales como tambien numeros enteros*

*asi que este seria nuestro siguiente enfoque:*



*num.float*

*num.auto \~ esta seria la forma estandar equivalente a solo escribir: "num"*

*num.int*



*asi que sus usos ya mas o menos te imaginaras de como se hara observa estos ejemplos:*



*\~in(num.auto=[1,4..6,100], len = 5, msg="incorrecto", att = 2) \~ aquivalente a nuestros annteriores y tambien el por defecto*

*\~in(num.float=[1,4..6,100], len = 5, msg="incorrecto", att = 2) \~ aqui explicitamente se pedira una entrada flotante, asi que si el usuario por ejemplo introduce "1" daria error emcambio "1.0" ya lo aceptaria, asi que aqui ya no es opcional aqui sera obligatorio y fuertemente tipado*

*\~in(num.int=[1,4..6,100], len = 5, msg="incorrecto", att = 2) \~ explicitamente numeros enteros, por lo tanto cualquier otro tipo d entrada como un flotante dara error, esto debemos hacerlo bastante estricto en todo los aspectos*



*pienso tambien que a esta parte poodriamos agregar aun mas funcionalidades podrias darme ideas interesnate para trabajar por ejemplo numeros compeljos, imaginarios, etc. puedes darme mas ideas interesantes*



*ahora pasemos con el otro parametro que vimos en el ejemplo:*



*\~in(num=[1,4..6,100], len = 5, msg="incorrecto", att = 2)*



*en este caaso como veras "len", esto como ya sabras ya tenemos bastante bien definido en el actual asi que seguiremos conservando dicha funcionalidad*

*la cual era, el tamanio de un numero no el lo mismo lo que represnta el valor de un numero por ejemplo:*



*2*

*002*



*ambos matematicamente son equivalente, pero en tamanio no lo son, asi que aqui es donde entra el papel exacto de "len" para numeros, incluso lo simbolos haran la diferencia, asi que seguiremos conseervando dicha funcionalidad*

*y aqui puede entrar una pregunta que tal si el usuario quiere por ejemplo hacer esta combinacion:*



*\~in(num=[1,4..6,100], len = [2,10..20], msg="incorrecto", att = 2)*



*que quiere decir, esto puedes si que quiere introducir mas de un parametro, entonces se considera ambos validos y asi crea conbinaciones interesantes*

*y aqui entones quiere decir que el len debe ser 2 o entre 10 a 20, y podria crear incluso mas convinaciones interesantes, y como podras haberte dado cuenta, cuando se quiere introducir mas de un aspecto obligatoriamente hay que utlizar los "[]"*

*y si utlizas solo un valor entonces no hay problema al utlizar "[]" puede quedar opcional como:*



*\~in(num=6, len = 1..4, msg="incorrecto", att = 2)*



*aqui como veras quiere decir que solo exactamente el numero debe ser 6 y que ademas, el len debe ir desde 1 hasta 4&#x20;*

*bien teneiendo todo ello en cuenta pasemos al siguiente argumento:*



*\~in(num=[1,4..6,100], len = 5, msg="incorrecto", att = 2)*



*como veras ese "msg" sustituira a lo que anteriormente teniamos "none" y con esto queremos decir que este sera el mensaje normal sin formato que se lanzara cuando no se cumpla el contrato*

*ahora te muestros los tipo que existiran:*



*msg = "mensaje" \~ este mensaje no tiene formato&#x20;*

*error = "esto se mostrara en rojo" , cuando no se llega a utilizar nada en lo absoluto esto sera el por defecto siempre, mencionar tambien que si no se esccribe un mensaje personalizado, entonces con simplemente utlizar "error" el error se lanzara desde nuestro propio sistema*

*warning = "esto se mostrara en amarillo como alerta", igual en este caso*



*ahora el detalle mas intersante podriamos hacer estas excelentes convinaciones:*



*\~in(num=[1..10], len = 3, msg="incorrecto")*

*\~in(num=[1..10], len = 3, msg) \~ aqui por defecto el mensaje sera vacio, por lo tanto no deberia haber como tal nada&#x20;*

*\~in(num=[1..10], len = 3, error="incorrecto") \~ se lanzara el mensaje de error en rojo "incorrecto" y termina el programa y tambien mencionar que cuando se utlizar error si o si el programa termina*

*\~in(num=[1..10], len = 3, error) \~ aqui nuestro lenguaje da el error mismo*

*\~in(num=[1..10], len = 3) \~ esto seria equivalente a poner error directamente, sin ningun mensaje*

*\~in(num=[1..10], len = 3, warning="alerta") \~ aqui se muestra el mensaje personalizado en amarillo, y continua el programa*

*\~in(num=[1..10], len = 3, warning) \~ aqui el propio lenguaje manda el warning*



*por cierto estas palabras reservadas como tal, actualmente solo deben funcionar dentro exactamente de este contexto, mas adelante ya iremos expadiendo sus posiblidades, asi que sus funcionamiento ahora mismo limitado aqui mismo*

*ahora continuemos con el penultimo parametro:*



*\~in(num=[1..10], len = 3, msg="incorrecto", att = 2)&#x20;*



*aqui como podremos observa el att, hace alusion a "attempts" , intentos antes de fallar esto por defecto como ya tenemos actualmente en nuestro lenguaje su forma nativa es "1"*

*por lo que no existiran por defecto 2 intentos, solo 1 ahora observa estos ejemplos de uso:*



*\~in(num=[1..10], len = 3, att = 1) \~ esto quieres decir 1 intento al igual que no escribir mada*

*\~in(num=[1..10], len = 3, error, att = 2) \~ esto quieres decir lanzara el error al fallar al segundo intento*

*\~in(num=[1..10], att = [3,"incorrecto"])   \~ esto quiere decir que lanzara el error al tercer intento y por cada intento fallido dara un mensaje personalizado en este caso "incorrecto"*

*\~in(num=[1..10], len = 3, msg="incorrecto", att = inf) \~ esto quieres decir la cantidad de intento es infinito, hazta que el usario escriba lo requerido, y aqui ojo ese "msg", personalizado jamas llegara a funcionar ya que se contradicen asi que aqui podemos dar un error en tiempo de compilacion indicando la contradiccion*

*\~in(num=[1..10], len = 3, error="incorrecto", att = +inf) \~ aqui igual que el anterior caso deberia dar error por la cotradiccion que se escribio&#x20;*

*\~in(num=[1..10], len = 3, msg="incorrecto", att) \~ en este caso esto es equivalente a "att = 1" o simplemente no escribir nada*

*\~in(num=[1..10], len = 3) \~ aqui por ejemplo el numero de intentos por defecto es 1, y error por defecto al no cumplir contrato  &#x20;*



*ahora el ultimo parametro por ahora:*



*\~in(num=[1..10], len = 3, msg="incorrecto", att = 2, -> 10)&#x20;*



*esto indicara el valor por defecto, a adquirir en caso de no cumplir el contrato, ahora mostrar unos cunatos ejemplos de uso*



*\~in(num=[1..10], len = 3, msg="incorrecto", att = 2, -> 50) \~ aqui retornara el valor de 50*

*\~in(num=[1..10], len = 3, msg="incorrecto", att = 2, -> "no") \~ en este caso retornara "no", aqui lo interesante aunque inicialmente el usuario queria un numero, el mismo decidio al final que sea un texto, podrias recomendarme acerca de ello, si deberia ser asi o deberia dar error por contradiccion que opinas*

*\~in(num=[1..10], len = 3, msg="incorrecto", att = 2, ->) \~ esto quiere decir que retornara "none" y ojo que tambien que por defecto ya viene a ser none el retorno cuando no cumple el contrato*

*\~in(num=[1..10], len = 3, msg="incorrecto", att = 2) \~ esto sera equivalente a retornar "none" o vacio el "->"&#x20;*



*como habras visto en esta parte existe un monton de posibilidades y convinaciones posibles, y tambien mencionar que el orden no deberia importar en lo absoluto de como se le de los parametros como tampoco el numero de arguemntos que demos por ejemplo:*



*\~in(num=[1..10], att = 2, len = 1, error) \~ desordenado*

*\~in(num=[1..10]) \~ solo con un argumento*

*\~in(num) \~ num general*

*\~in \~ en este caso tambien funcional, pero es como estar poniendo todo en auto, por lo tanto seria inutil literalmente escribirlo*



*ahora con los otros tipos se aplicara casi las mismas funcionalidades por ejemplos "Str"*



*\~in(str)*

*\~in(str="hola")*

*\~in(str=["si","no"])*

*\~in(str=a..z)*

*\~in(str="\\"".."/") \~ tambien valido quiere decir que sera valido desde el caracter '"' hasta el "/", asi que se podria hacer monton de convinaciones interesantes tambien aqui*

*\~in(str=[a..z,A..Z,0..9,".","@"]) \~ tambien valido como para especificar correos*

*\~in(str=[а..я,ا..ي]) \~ como ves actualmente nuestro lenguaje ya soporta alctualmente casi cualquier caracter del mundo por lo tanto creo que tambien esto deberia ser posible*

*\~ aqui tmabien mencionar que con emogis y otros caracteres tambien deberia poder ser posible de manera normal*

*\~in(str=[a..]) \~ esto tambien como en los numeros posible e indicar caracteres desde la "a" hacia adelante*

*\~in(str=a..+inf) \~ tambien equivalente al anterior*

*\~in(str=[a..z,-inf.."="]) \~ tambien valido al igual que numeros, y mencionar que aqui todos ellos son caracteres y completamente valido*

*\~in(str.char) \~ esto indica que solo sera admitiran caracteres y tambien poder hacer mas especificaciones*

*\~in(str.char = [a..m]) \~ caracter entre a la m, tambien podriamos conseguir un resultado similar haciendo esto sin necesidad de utilizar "str.char"*

*\~in(str = a..m, len = 1) \~ como podras ver bastante intuitivo y equivalente*



*y asi podriamos hacer mas convinaciones interesante y al igual que con "num", llevan sus mismos parametros*

*igual ocurrira con nuestro "bool", por ejemplo:*



*\~in(bool) \~ activado entrada solo de booleanos, aqui por defecto aceptara tanto true, false como 0 y 1*

*\~in(bool.num) \~ indica solo en formato numero quiere decir solo se acepta 0 y 1*

*\~in(bool.str) \~ indica que solo se acepta "true" y "false"*

*\~in(bool = [true,false]) \~ especifica que solo se acepta "true" y "false"*

*\~in(bool = [true,1,false]) \~ solo se acepta lo que se espcifica caso contrario retornara "none" o lo que se especifique retorno*

*\~in(bool.num = 1) \~ indicando que solo se aceptara el valor 1*

*\~in(bool.str = false) \~ solo se acepta "false", todo none*

*\~in(bool = true, len = 4) \~ el len aunque siga funcionando sera casi inutil utlizarlo en esta parte ya que solo tenemos pocas opciones, pero quedara igual habitado*

*\~in(bool = true,-> false) \~ especificado retornar none*



*como haabras visto en estos ejemplos, tenemos un monton de formas de usos, pero quiero mencionar que a diferencia de nuestra anteior version,*

*donde aceptaba mas cosas aqui hay que ser mas estrictos ya que si po ejemplo se haria esto:*



*\~in(bool = true, len = 6) \~ deberia dar error por contradiccion, y no solo en este caso si no en todos las cominaciones posibles, verificar, y ver su posibilidad para no tener incongruencias esto con todos los tipos "num, bool, str"*

*ahora otro detalle interesante, como ves con toda esta nueva correccion estamos viendo la posibilidad de poder ingresar tambien este nueva forma*



*\~in(auto) \~ esto es como la forma estandar que viene por defecto nuestro lenguaje, al inciar un programa y aqui tambien podremos hacer convinaciones interesantes como por ejemplo:*

*\~in(auto = ["hola","j",a..z,1..9,true], len = 20, -> "hola"), esto permite formarlo tambien de varias formas, y convinaciones de todo tipo&#x20;*



*asi que con toda esta informacion hagamos el cambio general en todo el lenguaje para que sea mas elegante creo yo, que opinas al respecto de todo ello*