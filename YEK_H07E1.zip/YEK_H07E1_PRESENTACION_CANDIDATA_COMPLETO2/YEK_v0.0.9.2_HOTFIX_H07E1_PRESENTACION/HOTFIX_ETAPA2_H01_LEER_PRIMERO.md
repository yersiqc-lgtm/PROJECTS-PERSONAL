# YEK – Entrega 2 HOTFIX H01

## Registro recibido

`cargo test --test declarativo_etapa2_tests -- --nocapture`: 8 pruebas superadas y 10 fallidas.
Nueve de los fallos observados compartían el mensaje `member ... is not available`, y el décimo correspondía a que `<-` era reconocido accidentalmente en `~code`.

## Causas verificadas en el código fuente

1. `src/interpreter/mod.rs`: `activate_for_output` no llamaba a `try_declarative_call` para un `Expr::Member` sin paréntesis. La ruta de `eval_values` sí lo hacía, lo cual explica la diferencia entre `base.relacion()!` y `base.relacion!`.
2. `src/lexer/lexer.rs`: `<-` podía tokenizarse como `<` seguido de `-` y aceptarse como comparación con negativo dentro de `~code`.

## Cambios

- Salida sin paréntesis de relaciones y bloques matemáticos pasa por la misma consulta declarativa de cero argumentos que la forma con `()`.
- `<-` contiguo se rechaza en el lexer de `~code`, manteniendo `< -` y los literales de texto intactos.
- Tres pruebas de regresión adicionales en `tests/declarativo_etapa2_tests.rs` (21 en total).
- Script `VERIFICAR_HOTFIX_ETAPA2.cmd`.

## Verificación Windows CMD/PowerShell

Situarse en la raíz donde está `Cargo.toml` y ejecutar:

```bat
cargo check --all-targets
cargo test --test declarativo_etapa2_tests -- --nocapture
cargo test --all-targets
VERIFICAR_HOTFIX_ETAPA2.cmd
```

En PowerShell el último comando necesita prefijo `./` o `.\`.

También puede guardar los resultados desde CMD:

```bat
VERIFICAR_HOTFIX_ETAPA2.cmd > resultado_hotfix2.txt 2>&1
echo %ERRORLEVEL%
notepad resultado_hotfix2.txt
```

## Estado de las validaciones

Se revisaron los cambios y se prepararon pruebas automatizadas; **no se ejecutó Cargo en este entorno**, porque `cargo` y `rustc` no están disponibles. Se trata de un parche candidato pendiente de compilación y regresión en Windows. Mantenga una copia de la versión anterior hasta completar los comandos.
