# H06D — Correccion QA de los productores For con extremos explicitos

Base: H06C. Cambios mínimos de compatibilidad con la sintaxis H06A.

## Causa

La regla H06A exige escribir `(units)`, `(qty)` y `(n)` cuando se usan
variables como extremos de un rango por valor. Los tres archivos QA antiguos
seguían usando extremos sin agrupar; esa sintaxis ya no es válida.
El parser, después de rechazarla, intentaba procesar el mismo código como
un For heredado y emitía un mensaje secundario, menos descriptivo.

## Modificaciones

- `qa_realista/casos/21_caja_interactiva.yek`: `1..(units)`.
- `qa_realista/casos/23_reintentos_y_fallback.yek`: `1..(qty)`.
- `qa_realista/casos/24_ambito_de_entrada.yek`: `1..(n)`.
- `src/source.rs`: conserva el diagnóstico `dynamic Range endpoint requires
  parentheses` cuando falla una expresión productora.
- `tests/etapa6_h06a_rangos_explicitos_tests.rs`: 5 regresiones nuevas,
  incluyendo productores filtrados y errores intencionados.

No cambia la evaluación de ValuePack, `~in`, referencias o contratos heredados;
no se tocan las salidas esperadas de QA ni los archivos de extensión VS Code.

## Pruebas reales (pendientes de ejecutar con Cargo)

```powershell
cargo build
cargo test --test qa_realista_tests
cargo test --test etapa6_h06a_rangos_explicitos_tests
cargo test --test etapa6_h06_migracion_unificada_tests
cargo test
```

El proyecto ha sido revisado estáticamente. No se dispone de Cargo en el
entorno de empaquetado, así que no se afirma que estas suites hayan pasado.
