# YEK H06G — Compatibilidad de tests con rangos Unicode

## Causa del fallo
La regresion H06A `check_17_variable_sin_agrupar_dos` esperaba un rechazo de `a..b`.
H06F aprobo `a..b` como rango literal de caracteres Unicode, aun cuando existan variables
con esos nombres. La expectativa se habia quedado desactualizada.

## Cambio
Solo se modifica `tests/etapa6_h06a_rangos_explicitos_tests.rs`:
- `a..b` se comprueba como rango literal con salida `(a, b)`.
- `(a)..(b)` se comprueba como rango por valor con salida `(1, 2, 3, 4, 5)`.
- Se conservan los otros 44 tests, incluidos los rechazos de extremos dinamicos
  numericos sin agrupar y las referencias vivas con `!`.

No hay cambios en `src/`, el motor, la semantica de YEK, ~in ni el VSIX.

## Verificacion Windows (en la carpeta del Cargo.toml)
```
cargo build
cargo test --test etapa6_h06a_rangos_explicitos_tests
cargo test --test etapa6_h06f_rangos_unicode_tests
cargo test
```

Este paquete se verifico por integridad ZIP y comparacion de contenido con H06F.
No se ha ejecutado Cargo en el entorno de entrega; la compilacion y las pruebas
reales deben ejecutarse en Windows.
