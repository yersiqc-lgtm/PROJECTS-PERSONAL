# YEK H06E — Compatibilidad ContractPack y rangos explícitos

## Problema detectado en H06D
`cargo test --test v007_3_tests` tenía 33 de 34 pruebas correctas.
La prueba `contract_pack_reference_survives_pack_name_detach` todavía
usaba `rules=(a..z,[2])`. Desde H06A, `[2]` también puede representar
un Array ordinario y no constituye una marca inequívoca de ContractPack.
El parser, correctamente, no puede asumir que `a..z` sea un alfabeto
de contrato cuando no hay un marcador inequívoco.

## Corrección H06E
En esa prueba se sustituyen exclusivamente los marcadores de longitud:
`[2]` → `[2..2]`, que significa la misma restricción: dos caracteres.
Se añadió una prueba negativa que preserva la obligación de emplear
sintaxis explícita cuando hay ambigüedad.

## Escritura recomendada para programas nuevos
```yek
~in(str=a..z, len=2)
valor?
valor!
```

## Compatibilidad
No cambian los archivos `src/`, el AST ni el intérprete. Se conservan
la sintaxis de rangos explícitos, la semántica de referencias y el
soporte de contratos heredados que poseen marcadores inequívocos.
La forma ambigua `rules=(a..z,[2])` no se restaura deliberadamente.

## Verificación en Windows
Abrir PowerShell en la carpeta de Cargo.toml y ejecutar:
```
cargo build
cargo test --test v007_3_tests
cargo test --test etapa6_h06a_rangos_explicitos_tests
cargo test --test etapa6_h06_migracion_unificada_tests
cargo test
```

**No se ha ejecutado Cargo en el entorno donde se generó este ZIP.**
El parche está verificado por comparación estática con H06D e integridad ZIP.
