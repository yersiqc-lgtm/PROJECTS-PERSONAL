# YEK v0.0.8.4 — Hotfix 1 de detección de contratos

## Problema reproducido por el usuario

La versión anterior superó las pruebas históricas y 10/12 pruebas de operadores,
pero falló con `unmatched ')' in input contract` en:

```yek
a=(1,2)+(3,4)
a!
```

```yek
a=[]
b=(a//1)+(a%1)
(a==b)!
```

## Corrección de arquitectura

La ruta especial para ContractPack solo se activa cuando **toda la expresión
a la derecha** es un grupo parentizado y su contenido usa gramática exclusiva
de contratos. De otro modo, se analiza mediante la gramática común de
expresiones. La decisión no depende del operador utilizado.

Se mantienen sin modificar la semántica de Arrays, Packs y operadores.

## Ejecución en PowerShell

Desde la carpeta que contiene `Cargo.toml`:

```powershell
cargo test --test operadores_polimorficos_tests -- --nocapture
cargo test --test contract_pack_disambiguation_tests -- --nocapture
cargo test
cargo check
```

Salida esperada para la suite de operadores: **12 passed, 0 failed**.
Si no se alcanza, comparte el registro: esta variante no se ha compilado
localmente por falta de herramientas Rust en el entorno de preparación.

Las pruebas con `ignored` de recursos quedan desactivadas deliberadamente.

## Archivos principales modificados

- `src/source.rs`: detección de paréntesis completos y selección de contrato.
- `tests/contract_pack_disambiguation_tests.rs`: nueva regresión.
- `tests/qa_realista_tests.rs`: nombres de las funciones de prueba normalizados.
- `CHANGELOG.md`: registro del cambio.

No se ha cambiado `Cargo.toml`: sigue identificándose como
`0.0.8-alpha.4`, con el sufijo **Hotfix 1** solo en el paquete.
