> **Aviso de compatibilidad:** Este documento describe el comportamiento provisional
> del Hotfix 3. El **Hotfix 4 lo sustituye parcialmente**: el acceso
> `"archivo.yek".miembro` y la reexportación por ruta literal fueron retirados
> deliberadamente para preservar las futuras propiedades de String.
> **Sí se conserva** `~import "archivo.yek"` sin `as`, los alias por defecto,
> los alias explícitos y las reexportaciones por identificador.
> Véase `HOTFIX4_MIEMBROS_SEGUROS.md` para las reglas vigentes.

# YEK v0.0.8.9 — Hotfix 3: normalización de importaciones

## Problema reproducido

Antes, `~import "03_ventas_con_funciones.yek"` fallaba porque se utilizaba el nombre
`03_ventas_con_funciones` como alias predeterminado y este no es un identificador
válido. Además, `"archivo.yek".total` se rechazaba aunque el archivo hubiera sido
importado.

## Nuevo contrato

1. `~import "archivo.yek"` **no exige `as`**. El intérprete deriva un alias válido
   del nombre relativo, incluidas carpetas (`ventas/resumen.yek` -> `ventas_resumen`).
   `03_ventas_con_funciones.yek` -> `_03_ventas_con_funciones`.
2. Cada `~import "ruta/archivo.yek"` también registra el nombre literal de la
   ruta como namespace del **mismo** módulo. Permite:

   ```yek
   ~import "03_ventas_con_funciones.yek"
   "03_ventas_con_funciones.yek".total!
   _03_ventas_con_funciones.total!
   ```

3. `~import "archivo.yek" as alias` sigue funcionando, y también permite acceso
   literal con `"archivo.yek".valor` dentro del mismo archivo importador.
4. Se puede reexportar un miembro a partir de la ruta literal:

   ```yek
   ~import "03_ventas_con_funciones.yek"
   ~export "03_ventas_con_funciones.yek".total as ventas
   ```

5. Las importaciones repetidas con distintos alias comparten celdas y caché:
   no se ejecuta dos veces el módulo. Varias importaciones desde diferentes
   carpetas con idéntico *file stem* obtienen nombres predeterminados diferentes
   si sus rutas relativas lo son.
6. Las rutas literales no se convierten automáticamente en módulos. Por ejemplo
   `"archivo.yek"!` sigue siendo un texto y `"archivo.yek".valor` solo resuelve
   si ese literal se registró mediante `~import` en el ámbito vigente.
7. En modo auto-público, los identificadores técnicos `"ruta".símbolo` NO se
   reexportan transitivamente. Las variables normales y las importaciones con
   nombres accesibles sí siguen la regla auto-pública anterior.
8. Mantiene la política de `~export` explícito (lista blanca), comprobación de
   duplicados y acceso solo de lectura a miembros importados.

## Restricciones deliberadas

- Las referencias a `.py`, `.js`, `.exe`, etc. no ejecutan intérpretes externos:
  la importación directa sigue admitiendo `.yek` y `.txt` como formatos seguros.
- Una cadena dinámica `ruta = "archivo.yek"; ruta.valor` no es una referencia a un
  módulo; para módulos dinámicos necesitamos introducir en el futuro un tipo de
  valor de módulo, no reinterpretar cualquier cadena como un módulo.
- `~export "archivo.yek".valor` sin `as` es ambiguo como nombre público; requiere
  `~export "archivo.yek".valor as nombrePublico`.
- Si dos importaciones producen el **mismo alias predeterminado** por nombres
  normalizados equivalentes, se emite un error claro. Se puede resolver con
  `as`, o usar rutas literales con nombres distintos. No se sobrescribe nada.

## QA en Windows

Desde el directorio que contiene `Cargo.toml`:

```powershell
cargo check
cargo test --test modulos_v0089_hotfix3_normalizacion_tests -- --nocapture
cargo test
cargo run -- run examples/modulos_v0089_hotfix3_normalizados/main.yek
```

Salida esperada del ejemplo: `90`, `90`, `35`, `90`, `40`, uno por línea.

Esta entrega se ha preparado y auditado estáticamente; el entorno de creación
no dispone de compilador Rust operativo. Las pruebas requieren ejecución en
Windows antes de clasificarla como versión estable.
