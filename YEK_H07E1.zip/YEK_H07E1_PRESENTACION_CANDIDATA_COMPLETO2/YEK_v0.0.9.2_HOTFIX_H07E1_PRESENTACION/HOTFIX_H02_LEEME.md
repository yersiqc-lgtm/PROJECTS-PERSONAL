# YEK v0.0.9.2 — Etapa B, HOTFIX H02

Base: Etapa B HOTFIX H01 (match exhaustivo). Este paquete **no cambia** la sintaxis ni el modelo de Map, Set o las referencias.

## Correcciones

1. `Map` y `Entry` muestran valores `Text` con comillas, al igual que las claves de texto. Esto distingue `{0:"zero"}` de un valor no textual. No cambia la salida directa de `Text`, `m.get(k)`, `m.values` ni los Strings que están dentro de Arrays/ValuePacks.
2. El error de un literal mixto de Set/Map menciona `Map entry` y mantiene el rechazo: `s={1,"x":2}`.

## Ejemplos

```yek
~code
m={0:"zero",1:"one"}
m[0]!
m.get(0)!
```

Salida esperada:

```text
0:"zero"
zero
```

## Validación en PowerShell

```powershell
cargo check --all-targets
cargo test --test colecciones_map_set_hotfix_h02_render_tests -- --test-threads=1 --nocapture
cargo test --test colecciones_universales_v0092_etapa_b_map_set_tests -- --test-threads=1 --nocapture
cargo test --test colecciones_universales_v0092_etapa_a_tests -- --test-threads=1 --nocapture
cargo test --all-targets
```

Se conservan las 83 pruebas de Etapa B, las 22 de Etapa A y las suites históricas. Cargo/Rust no están disponibles en el entorno de preparación; las salidas son **esperadas**, no verificadas mediante ejecución.
