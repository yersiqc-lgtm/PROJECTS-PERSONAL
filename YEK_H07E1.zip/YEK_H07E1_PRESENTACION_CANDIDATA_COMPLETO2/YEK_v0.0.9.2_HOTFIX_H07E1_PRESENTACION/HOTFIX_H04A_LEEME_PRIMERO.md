# YEK v0.0.9.2 — HOTFIX H04A (compilación)

## Contexto
El código de H04 produjo en Windows:

```
error: expected `,`, or `}`, found `directive`
  --> src\source.rs:37:32
warning: unused import: `id_start`
 --> src\parser\mod.rs:5:22
```

## Arreglos incluidos
1. En `src/source.rs`: se añadió la coma que faltaba entre los campos `defaults` y `directive` de la estructura `CaptureSpec`.
2. En `src/parser/mod.rs`: se eliminó `id_start` de la lista de importaciones, porque ese símbolo no se utilizaba allí.

Son exactamente **dos cambios de código fuente** respecto al ZIP H04.
No se modificaron el intérprete, AST, semántica de referencia, ValuePack, etiquetas `none`, archivos YEK ni pruebas.

## Validación en Windows (PowerShell)
Desde la carpeta que contiene `Cargo.toml`, ejecutar:

```powershell
cargo build
cargo test --test etapa4_h04_semantica_global_tests
cargo test
```

En caso de otros errores de compilación, compartir el registro completo; el primer error sintáctico puede haber ocultado otros diagnósticos.

## Limitación de validación
El entorno donde se creó este parche no tiene `cargo` ni `rustc`, ni acceso a la distribución de Rust. Se comprobó la integridad del ZIP y que los dos archivos son los únicos cambiados respecto a H04, pero **no se ha realizado compilación real**. No se declara el hotfix aprobado hasta pasar Cargo en Windows.
