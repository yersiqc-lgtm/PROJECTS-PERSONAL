# HOTFIX E0004 — exhaustividad de RuntimeValue y referencias declarativas

## Error corregido

`error[E0004]: non-exhaustive patterns` en `src/interpreter/mod.rs`,
función `runtime_value_references_call`, al incorporar
`Value::Logic`, `Value::MathBlocks` y `Value::Symbolic`.

## Solución

- `Logic(_, refs)` y `MathBlocks(_, refs)`: verificar si alguna referencia viva
  apunta a una celda perteneciente a la llamada de `~code` que está retornando.
  En ese caso se conserva el error de escape de referencia.
- `Symbolic(_)`: no almacena CellId; se permite su retorno como valor.
- Se conservan todas las variantes anteriores del `match`. Sin comodines y sin `todo!()`.

## Pruebas nuevas

Se añadieron cinco pruebas de regresión a `tests/declarativo_etapa1_tests.rs`:

1. Una base `~logic` con referencia `!` a una variable local no puede escapar de Code.
2. Un grupo `~math` con referencia `!` a una variable local no puede escapar.
3. Una base lógica que captura por valor puede retornarse.
4. Una base lógica con referencia `!` a una variable global puede retornarse.
5. Una expresión simbólica sin CellId puede retornarse.

## Ejecutar desde CMD de Windows

En la raíz del proyecto:

```bat
cargo check --all-targets
cargo test --test declarativo_etapa1_tests
cargo test --all-targets
VERIFICAR_HOTFIX_E0004.cmd
EJECUTAR_QA_INTEGRAL.cmd
```

## Estado

Comprobación local: el parche se ha aplicado al código fuente y el ZIP es verificable.
En este entorno **no está instalado Cargo/Rust**, por lo tanto **no se ha podido compilar ni ejecutar**
ninguna prueba Rust. El ZIP sigue siendo candidato experimental hasta validar en Windows.
