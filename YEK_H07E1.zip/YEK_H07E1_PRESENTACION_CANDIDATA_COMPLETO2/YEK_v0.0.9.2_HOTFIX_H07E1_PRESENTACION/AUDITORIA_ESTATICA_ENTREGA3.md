# Auditoría de la Entrega 3 — antes de compilar en Windows

## Verificaciones completadas en el entorno de preparación

- El código se construyó directamente a partir de `YEK_v0.0.9.0_ENTREGA2_LOGIC_MATH_ARRAYS_HOTFIX_H02.zip`.
- Solo se modificaron los dos archivos fuente `src/declarative.rs` y `src/interpreter/mod.rs`. La batería histórica de pruebas no se editó.
- Se añadieron `tests/declarativo_etapa3_tests.rs`, ejemplos `.yek`, documentación y scripts de verificación.
- El lexer Rust de Pygments no detectó símbolos de error y el análisis de delimitadores confirmó paréntesis, corchetes y llaves equilibrados en los archivos nuevos/modificados.
- Un oráculo independiente de grafos verificó las rutas de ejemplo y sus costos: A→C→D→F cuesta 6; Depósito→Mercado→Hospital→Universidad→Aeropuerto cuesta 15.
- Un cálculo independiente de combinaciones confirmó el óptimo del ejemplo matemático: mínimo (4,16), máximo (15,5).

## Verificaciones pendientes

**No se dispone de `cargo` ni `rustc` en el entorno de generación; la conexión externa tampoco permite instalarlos.** Por ello: compilación, `cargo test`, ejecución de los ejemplos, prueba de regresión histórica y test de carga final quedan **sin ejecutar**. La validación está automatizada en `VERIFICAR_ENTREGA3_FINAL.cmd` y `VERIFICAR_ESTRES_ENTREGA3.cmd`.

No se debe llamar «estable» ni reemplazar la versión H02 hasta obtener los resultados reales de Windows.
