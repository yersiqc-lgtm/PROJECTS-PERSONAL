# YEK H04C — Corrección general de expresiones contiguas en texto activo

**Base:** YEK v0.0.9.2 H04B. **Alcance:** `src/parser/mod.rs`.

## Motivo

En H04B, el analizador de cadenas activas seleccionaba únicamente el último
operando posterior a `+`, `-`, etc. En consecuencia, `"i+1! c.value!"`
mostraba `i+1` como texto literal mientras evaluaba `c.value`.

## Regla establecida

- `"i+1!"`: evalúa la operación `i+1` con la gramática ordinaria de `~code`.
- `"i+1! c.value!"`: evalúa dos expresiones, separadas por un espacio literal.
- `"a[1][0]-4!"` y `"f(3)+1!"`: reconocen accesos/llamadas y operaciones.
- `"x +1!"`: **no** incluye `x` porque existe un espacio exterior.
- `"(x + 1)!"`: el espacio es válido dentro de una agrupación explícita.
- `"x+1?"`: error: `?` exige una variable destino, no una expresión aritmética.
- `"YEK\!"`: imprime un `!` literal. `"YEK!"` sigue intentando evaluar `YEK`.
- `"for!"` sigue siendo un error por palabra reservada.
- Los operadores, tipos, precedencia y efectos se validan con el **parser de Code**.
- La secuencia `!` contigua al texto sigue siendo activa; **no** se ha redefinido.

### Ejemplo principal

```yek
~code
a={"a":1,"b":2}
for(i,c in a)
    "i+1! c.value!"
```

Salida esperada:

```text
1 1
2 2
```

## Cambios técnicos

- `attached_operand`: analiza hasta la última frontera de texto que esté fuera
  de `()`, `[]` y `{}`; incluye operadores binarios contiguos en la expresión.
- Continúa llamando a `parse_embedded_expression` para la gramática real.
- El buffer de texto registra posiciones de origen, evitando borrar letras
  extra por los caracteres escapados que ocupan varios caracteres fuente.

**Sin cambios:** intérprete, semántica de ValuePack, referencias, `none`,
`vlen`, Map, Set, interfaz VS Code y API públicas.

## Verificación Windows

Desde la raíz del proyecto:

```powershell
cargo build
cargo test --test etapa4_h04c_cadenas_operadores_tests
cargo test --test etapa4_h04_semantica_global_tests
cargo test
```

Para ejecutar individualmente los casos `.yek`:

```powershell
py -3 EJEMPLOS_H04C_CADENAS_ACTIVAS\ejecutar_h04c.py
```

Informe en `EJEMPLOS_H04C_CADENAS_ACTIVAS/RESULTADOS_H04C/REPORTE_PARA_CHATGPT.txt`.

## Estado de validación

Integridad estructural, pruebas de inventario y revisión de fuente realizadas.
Cargo/Rust no están disponibles en este entorno: **compilación y ejecución real
pendientes de comprobar en Windows**. No dar por cerrada la Etapa 4 hasta
confirmar los test completos.
