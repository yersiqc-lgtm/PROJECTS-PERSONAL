# YEK H07 — Entrega unificada

**Base:** H06G verificada por el usuario. **Estado:** candidata sin compilar en este entorno.

Archivos principales:
- `src/interpreter/mod.rs`: introspección Unicode, iteración Text, Map y sincronización tolerante.
- `src/parser/mod.rs`: resultados múltiples en productores `for` inline.
- `tests/etapa7_h07_universal_tests.rs`: 44 regresiones nuevas.
- `tests/v008_2_tests.rs`, `tests/qa_realista_tests.rs`, `tests/qa_exhaustiva_fixtures_tests.rs`: reglas antiguas de longitud desigual adaptadas.
- `EJEMPLOS_H07_ITERACION_UNIVERSAL`: programas ejecutables, oráculos y comprobador Python.
- `EXTENSION_VS_CODE_H07`: VSIX v1.3.2 y fuentes editables.

## Verificación en Windows

```powershell
cargo build
cargo test --test etapa7_h07_universal_tests
cargo test
py -3 EJEMPLOS_H07_ITERACION_UNIVERSAL\ejecutar_h07.py --sin-build
```

No se ha modificado el esquema de los contratos `~in`, los rangos Unicode ni las reglas de ValuePack. La sintaxis `for((k,v!) in m)` es **distinta** de la histórica `for(i,e in m)`, que sigue ofreciendo índice y Entry de lectura. Los textos se iteran por **escalares Unicode**, igual que `.len`, no por grafemas `.vlen`.

## Advertencia sobre los laboratorios anteriores

La Etapa 7 original y algunos test de QA contenían expectativas de error cuando las fuentes sincronizadas tenían tamaños desiguales. Esa expectativa es deliberadamente incompatible con H07: los elementos faltantes pasan a ser `none` por valor, mientras que una referencia faltante produce un diagnóstico.

H07 aún requiere comprobación con Cargo. No dar por aprobada esta versión hasta superar las nuevas regresiones y `cargo test` completo.
